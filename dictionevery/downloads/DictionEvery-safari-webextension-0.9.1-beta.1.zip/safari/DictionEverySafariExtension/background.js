const chrome = globalThis.chrome || globalThis.browser;
const GOOGLE_TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single";
const ENGLISH_DICTIONARY_URL = "https://api.dictionaryapi.dev/api/v2/entries/en";
const WIKTAPI_BASE_URL = "https://api.wiktapi.dev/v1";
const FREE_DICTIONARY_API_BASE_URL = "https://freedictionaryapi.com/api/v1";
const WIKTIONARY_API_URL = "https://en.wiktionary.org/w/api.php";
const KOREAN_BASIC_DICT_SEARCH_URL = "https://krdict.korean.go.kr/api/search";
const KOREAN_BASIC_DICT_VIEW_URL = "https://krdict.korean.go.kr/api/view";
const KOREAN_BASIC_DICT_KEY_STORAGE = "deKoreanBasicDictionaryApiKey";
const KOREAN_BASIC_DICT_DEFAULT_KEY = "BD3B4D4841A53DC2023412CE8AB7EE30";
const OPEN_RUSSIAN_DICTIONARY_PATH = "assets/dictionaries/openrussian-ru-en.json";
const AI_CONFIG_STORAGE = "dictionEveryAiConfig";
const SYNC_SESSION_STORAGE = "dictionEverySyncSession";
const SYNC_CONFIG_STORAGE = "dictionEverySyncConfig";
const AI_PROVIDER_DEFAULTS = {
  gemini: {
    model: "gemini-2.5-flash-lite",
    label: "Gemini"
  },
  groq: {
    model: "llama-3.1-8b-instant",
    label: "Groq"
  },
  huggingface: {
    model: "meta-llama/Llama-3.1-8B-Instruct",
    label: "Hugging Face"
  },
  cloudflare: {
    model: "@cf/meta/llama-3.1-8b-instruct",
    label: "Cloudflare Workers AI"
  }
};
const SUPABASE_SYNC_CONFIG = {
  url: "",
  anonKey: "",
  table: "dictionevery_words"
};

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !message.type) {
    return false;
  }

  if (message.type === "DE_LOOKUP_WORD") {
    lookupWord(message.word, message.targetLang, message.sourceLang, {
      searchMode: message.searchMode
    })
      .then((payload) => sendResponse({ ok: true, payload }))
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error && error.message ? error.message : "Lookup failed"
        });
      });

    return true;
  }

  if (message.type === "DE_AI_CONFIG") {
    handleAiConfigMessage(message.action, message.payload)
      .then((payload) => sendResponse({ ok: true, payload }))
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error && error.message ? error.message : "AI setup failed"
        });
      });

    return true;
  }

  if (message.type === "DE_SYNC") {
    handleSyncMessage(message.action, message.payload)
      .then((payload) => sendResponse({ ok: true, payload }))
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error && error.message ? error.message : "Sync failed"
        });
      });

    return true;
  }

  return false;
});

async function handleSyncMessage(action, payload = {}) {
  const config = await syncConfig();

  if (action === "status") {
    return {
      configured: isSyncConfigured(config),
      config: publicSyncConfig(config),
      redirectUrl: googleRedirectUrl(),
      session: publicSyncSession(await getStoredSyncSession())
    };
  }

  if (action === "save-config") {
    const incomingConfig = payload.config || payload;
    const nextConfig = normalizeSyncConfig({
      url: incomingConfig.url,
      anonKey: incomingConfig.anonKey || (payload.keepAnonKey ? config.anonKey : ""),
      table: incomingConfig.table
    });
    if (!isSyncConfigured(nextConfig)) {
      throw new Error("Enter a valid Supabase project URL and public anon key");
    }
    await setStoredSyncConfig(nextConfig);
    await setStoredSyncSession(null);
    return {
      configured: true,
      config: publicSyncConfig(nextConfig),
      redirectUrl: googleRedirectUrl(),
      session: null
    };
  }

  if (action === "clear-config") {
    await setStoredSyncConfig(null);
    await setStoredSyncSession(null);
    const clearedConfig = normalizeSyncConfig({});
    return {
      configured: false,
      config: publicSyncConfig(clearedConfig),
      redirectUrl: googleRedirectUrl(),
      session: null
    };
  }

  if (action === "test-config") {
    const incomingConfig = payload.config || payload;
    const testConfig = normalizeSyncConfig({
      url: incomingConfig.url || config.url,
      anonKey: incomingConfig.anonKey || (payload.keepAnonKey ? config.anonKey : ""),
      table: incomingConfig.table || config.table
    });
    if (!isSyncConfigured(testConfig)) {
      throw new Error("Enter a valid Supabase project URL and public anon key");
    }
    await testSupabaseConnection(testConfig);
    const configChanged =
      config.url !== testConfig.url ||
      config.anonKey !== testConfig.anonKey ||
      config.table !== testConfig.table;
    await setStoredSyncConfig(testConfig);
    if (configChanged) {
      await setStoredSyncSession(null);
    }
    return {
      configured: true,
      config: publicSyncConfig(testConfig),
      redirectUrl: googleRedirectUrl(),
      session: publicSyncSession(configChanged ? null : await getStoredSyncSession())
    };
  }

  if (!isSyncConfigured(config)) {
    throw new Error("Supabase sync is not configured");
  }

  if (action === "sign-up") {
    const session = await signUpWithEmail(payload.email, payload.password, config);
    return { session: publicSyncSession(session) };
  }

  if (action === "sign-in") {
    const session = await signInWithEmail(payload.email, payload.password, config);
    return { session: publicSyncSession(session) };
  }

  if (action === "google-sign-in") {
    const session = await signInWithGoogle(config);
    return { session: publicSyncSession(session) };
  }

  if (action === "sign-out") {
    await setStoredSyncSession(null);
    return { session: null };
  }

  if (action === "upload") {
    const session = await ensureSyncSession(config);
    const uploaded = await uploadSyncRows(payload.rows || [], session, config);
    return { uploaded, session: publicSyncSession(session) };
  }

  if (action === "download") {
    const session = await ensureSyncSession(config);
    const rows = await downloadSyncRows(session, config);
    return { rows, session: publicSyncSession(session) };
  }

  throw new Error("Unknown sync action");
}

async function handleAiConfigMessage(action, payload = {}) {
  const current = await aiConfig();

  if (action === "status") {
    return { config: publicAiConfig(current) };
  }

  if (action === "save") {
    const incoming = payload.config || payload;
    const next = normalizeAiConfig({
      ...current,
      ...incoming,
      apiKey: incoming.apiKey || (payload.keepApiKey ? current.apiKey : "")
    });
    await setStoredAiConfig(next);
    return { config: publicAiConfig(next) };
  }

  if (action === "clear") {
    await setStoredAiConfig(null);
    return { config: publicAiConfig(normalizeAiConfig({})) };
  }

  if (action === "test") {
    const incoming = payload.config || payload;
    const testConfig = normalizeAiConfig({
      ...current,
      ...incoming,
      apiKey: incoming.apiKey || (payload.keepApiKey ? current.apiKey : "")
    });
    await assertUsableAiConfig(testConfig);
    await testAiOrganizer(testConfig);
    await setStoredAiConfig(testConfig);
    return { config: publicAiConfig(testConfig), tested: true };
  }

  throw new Error("Unknown AI action");
}

async function aiConfig() {
  const stored = await getStoredAiConfig();
  return normalizeAiConfig(stored || {});
}

function normalizeAiConfig(config) {
  const provider = Object.prototype.hasOwnProperty.call(AI_PROVIDER_DEFAULTS, config?.provider)
    ? config.provider
    : "gemini";
  const mode = ["off", "quality", "always"].includes(config?.mode) ? config.mode : "off";
  return {
    mode,
    provider,
    apiKey: String(config?.apiKey || "").trim(),
    model: String(config?.model || AI_PROVIDER_DEFAULTS[provider].model).trim() || AI_PROVIDER_DEFAULTS[provider].model,
    accountId: String(config?.accountId || "").trim()
  };
}

function publicAiConfig(config) {
  const normalized = normalizeAiConfig(config || {});
  return {
    mode: normalized.mode,
    provider: normalized.provider,
    model: normalized.model,
    accountId: normalized.accountId,
    hasApiKey: Boolean(normalized.apiKey),
    apiKeyPreview: normalized.apiKey ? `${normalized.apiKey.slice(0, 6)}...${normalized.apiKey.slice(-4)}` : "",
    providerLabel: AI_PROVIDER_DEFAULTS[normalized.provider]?.label || normalized.provider
  };
}

function getStoredAiConfig() {
  return storageGet(AI_CONFIG_STORAGE).then((config) => config || null);
}

function setStoredAiConfig(config) {
  return storageSet(AI_CONFIG_STORAGE, config || null);
}

function shouldUseAiOrganizer(config, searchMode) {
  const normalized = normalizeAiConfig(config || {});
  if (normalized.mode === "off") {
    return false;
  }
  if (normalized.mode === "quality" && searchMode !== "precise") {
    return false;
  }
  return Boolean(normalized.apiKey);
}

async function assertUsableAiConfig(config) {
  const normalized = normalizeAiConfig(config || {});
  if (normalized.mode === "off") {
    throw new Error("Turn on AI sorting first");
  }
  if (!normalized.apiKey) {
    throw new Error("Enter an API key");
  }
  if (normalized.provider === "cloudflare" && !normalized.accountId) {
    throw new Error("Enter a Cloudflare account ID");
  }
  return normalized;
}

async function testAiOrganizer(config) {
  const payload = {
    word: "student",
    sourceLang: "en",
    targetLang: "ko",
    sources: [
      { id: "a", label: "Dictionary A", definitions: ["학생 — person who studies"], examples: [] },
      { id: "b", label: "Dictionary B", definitions: ["학습자 — learner"], examples: [] }
    ]
  };
  const result = await requestAiOrganization(payload, config);
  if (!result || !Array.isArray(result.sourceOrder)) {
    throw new Error("AI response was not valid JSON");
  }
  return true;
}

async function syncConfig() {
  const stored = await getStoredSyncConfig();
  return normalizeSyncConfig({ ...SUPABASE_SYNC_CONFIG, ...(stored || {}) });
}

function normalizeSyncConfig(config) {
  return {
    url: String(config?.url || "").trim().replace(/\/+$/, ""),
    anonKey: String(config?.anonKey || "").trim(),
    table: String(config?.table || "dictionevery_words").trim() || "dictionevery_words"
  };
}

function isSyncConfigured(config) {
  return Boolean(config.url && config.anonKey && config.table);
}

function syncAuthHeaders(config, accessToken) {
  return {
    apikey: config.anonKey,
    Authorization: `Bearer ${accessToken || config.anonKey}`,
    "Content-Type": "application/json"
  };
}

async function signUpWithEmail(email, password, config) {
  const response = await supabaseFetch("/auth/v1/signup", {
    method: "POST",
    headers: syncAuthHeaders(config),
    body: JSON.stringify({
      email: String(email || "").trim(),
      password: String(password || "")
    })
  }, false, config);
  const session = authPayloadToSession(response);
  if (session) {
    await setStoredSyncSession(session);
  }
  return session || { user: response.user || null };
}

async function signInWithEmail(email, password, config) {
  const response = await supabaseFetch("/auth/v1/token?grant_type=password", {
    method: "POST",
    headers: syncAuthHeaders(config),
    body: JSON.stringify({
      email: String(email || "").trim(),
      password: String(password || "")
    })
  }, false, config);
  const session = authPayloadToSession(response);
  if (!session) {
    throw new Error("Could not create a session");
  }
  await setStoredSyncSession(session);
  return session;
}

async function signInWithGoogle(config) {
  if (!chrome?.identity?.launchWebAuthFlow || !chrome.identity.getRedirectURL) {
    throw new Error("Google sign-in is not available in this browser");
  }

  const redirectUrl = chrome.identity.getRedirectURL("supabase");
  const authUrl = new URL(`${config.url}/auth/v1/authorize`);
  authUrl.searchParams.set("provider", "google");
  authUrl.searchParams.set("redirect_to", redirectUrl);

  const callbackUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow(
      { url: authUrl.toString(), interactive: true },
      (url) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message));
          return;
        }
        if (!url) {
          reject(new Error("Google sign-in was cancelled"));
          return;
        }
        resolve(url);
      }
    );
  });

  const session = await oauthCallbackToSession(callbackUrl, config);
  await setStoredSyncSession(session);
  return session;
}

async function oauthCallbackToSession(callbackUrl, config) {
  const url = new URL(callbackUrl);
  const params = new URLSearchParams(url.hash.startsWith("#") ? url.hash.slice(1) : url.hash);
  url.searchParams.forEach((value, key) => {
    if (!params.has(key)) {
      params.set(key, value);
    }
  });

  const accessToken = params.get("access_token");
  const refreshToken = params.get("refresh_token");
  if (!accessToken || !refreshToken) {
    throw new Error(params.get("error_description") || params.get("error") || "Google sign-in failed");
  }

  const expiresAt = normalizeExpiresAt(params.get("expires_at")) ||
    Date.now() + Number(params.get("expires_in") || 3600) * 1000;
  const user = await fetchSupabaseUser(accessToken, config);

  return {
    accessToken,
    refreshToken,
    expiresAt,
    user
  };
}

async function ensureSyncSession(config) {
  const session = await getStoredSyncSession();
  if (!session?.refreshToken) {
    throw new Error("Please sign in before syncing");
  }

  const expiresAt = Number(session.expiresAt || 0);
  if (expiresAt && expiresAt - Date.now() > 60000 && session.accessToken) {
    return session;
  }

  const refreshed = await refreshSyncSession(session.refreshToken, config);
  await setStoredSyncSession(refreshed);
  return refreshed;
}

async function refreshSyncSession(refreshToken, config) {
  const response = await supabaseFetch("/auth/v1/token?grant_type=refresh_token", {
    method: "POST",
    headers: syncAuthHeaders(config),
    body: JSON.stringify({ refresh_token: refreshToken })
  }, false, config);
  const session = authPayloadToSession(response);
  if (!session) {
    throw new Error("Could not refresh session");
  }
  return session;
}

async function fetchSupabaseUser(accessToken, config) {
  const user = await supabaseFetch("/auth/v1/user", {
    method: "GET",
    headers: syncAuthHeaders(config, accessToken)
  }, false, config);
  return {
    id: user.id || user.user?.id || "",
    email: user.email || user.user?.email || ""
  };
}

function authPayloadToSession(payload) {
  const accessToken = payload?.access_token || payload?.session?.access_token;
  const refreshToken = payload?.refresh_token || payload?.session?.refresh_token;
  if (!accessToken || !refreshToken) {
    return null;
  }

  const user = payload.user || payload.session?.user || {};
  const expiresAt = normalizeExpiresAt(payload.expires_at || payload.session?.expires_at) ||
    Date.now() + Number(payload.expires_in || payload.session?.expires_in || 3600) * 1000;

  return {
    accessToken,
    refreshToken,
    expiresAt,
    user: {
      id: user.id || "",
      email: user.email || ""
    }
  };
}

function normalizeExpiresAt(value) {
  const number = Number(value || 0);
  if (!number) {
    return 0;
  }
  return number < 10000000000 ? number * 1000 : number;
}

async function uploadSyncRows(rows, session, config) {
  const cleanRows = rows
    .filter((row) => row && row.syncKey && row.payload)
    .map((row) => ({
      user_id: session.user.id,
      sync_key: String(row.syncKey),
      updated_ms: Number(row.updatedMs || row.payload.updatedAt || Date.now()),
      payload: row.payload
    }));

  if (!cleanRows.length) {
    return 0;
  }

  const query = new URLSearchParams({ on_conflict: "user_id,sync_key" });
  await supabaseFetch(`/rest/v1/${encodeURIComponent(config.table)}?${query.toString()}`, {
    method: "POST",
    headers: {
      ...syncAuthHeaders(config, session.accessToken),
      Prefer: "resolution=merge-duplicates,return=minimal"
    },
    body: JSON.stringify(cleanRows)
  }, true, config);
  return cleanRows.length;
}

async function downloadSyncRows(session, config) {
  const query = new URLSearchParams({
    select: "sync_key,updated_ms,payload",
    user_id: `eq.${session.user.id}`,
    order: "updated_ms.desc"
  });
  const rows = await supabaseFetch(`/rest/v1/${encodeURIComponent(config.table)}?${query.toString()}`, {
    method: "GET",
    headers: syncAuthHeaders(config, session.accessToken)
  }, false, config);
  return Array.isArray(rows) ? rows : [];
}

async function testSupabaseConnection(config) {
  await supabaseFetch("/auth/v1/settings", {
    method: "GET",
    headers: syncAuthHeaders(config)
  }, false, config);
  return true;
}

function publicSyncSession(session) {
  if (!session?.user?.id) {
    return null;
  }
  return {
    user: {
      id: session.user.id,
      email: session.user.email || ""
    },
    expiresAt: Number(session.expiresAt || 0)
  };
}

function publicSyncConfig(config) {
  return {
    url: config.url || "",
    table: config.table || "dictionevery_words",
    hasAnonKey: Boolean(config.anonKey),
    anonKeyPreview: config.anonKey ? `${config.anonKey.slice(0, 8)}...${config.anonKey.slice(-4)}` : ""
  };
}

function googleRedirectUrl() {
  if (!chrome?.identity?.getRedirectURL) {
    return "";
  }
  return chrome.identity.getRedirectURL("supabase");
}

function getStoredSyncConfig() {
  return storageGet(SYNC_CONFIG_STORAGE).then((config) => config || null);
}

function setStoredSyncConfig(config) {
  return storageSet(SYNC_CONFIG_STORAGE, config || null);
}

function getStoredSyncSession() {
  return storageGet(SYNC_SESSION_STORAGE).then((session) => session || null);
}

function setStoredSyncSession(session) {
  return storageSet(SYNC_SESSION_STORAGE, session || null);
}

function storageGet(key) {
  if (!chrome?.storage?.local) {
    return Promise.resolve(null);
  }

  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => resolve(result?.[key] || null));
  });
}

function storageSet(key, value) {
  if (!chrome?.storage?.local) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    if (value === null) {
      chrome.storage.local.remove([key], resolve);
    } else {
      chrome.storage.local.set({ [key]: value }, resolve);
    }
  });
}

async function supabaseFetch(path, options = {}, allowEmpty = false, configOverride = null) {
  const config = configOverride || await syncConfig();
  const response = await fetch(`${config.url}${path}`, options);
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (_error) {
      data = { message: text };
    }
  }

  if (!response.ok) {
    const message = data?.msg || data?.message || data?.error_description || data?.error || `Supabase request failed: ${response.status}`;
    throw new Error(message);
  }

  return allowEmpty ? data : data || {};
}

async function lookupWord(rawWord, targetLang = "ko", sourceLang = "auto", options = {}) {
  const word = cleanWord(rawWord);

  if (!word) {
    throw new Error("No word to search");
  }

  const sourceCode = googleLangCode(sourceLang);
  const targetCode = googleLangCode(targetLang);
  const searchMode = options.searchMode === "precise" ? "precise" : "fast";
  const limits = dictionarySearchLimits(searchMode);
  const isEnglishSource = looksEnglish(word) || sourceCode === "en";
  const isRussianSource = sourceCode === "ru" || containsCyrillic(word);
  const isPersianSource = sourceCode === "fa" || containsPersianArabic(word);
  const wiktionarySourceCode = isEnglishSource
    ? "en"
    : isRussianSource
      ? "ru"
      : isPersianSource
        ? "fa"
        : sourceCode;
  const shouldFetchWiktApi = isEnglishSource && targetCode !== "en" && ["ko", "ru", "fa"].includes(targetCode);
  const shouldFetchWiktionary =
    (isEnglishSource && searchMode === "precise") ||
    (isRussianSource && targetCode === "en" && searchMode === "precise") ||
    (isPersianSource && targetCode === "en") ||
    (searchMode === "precise" && targetCode === "en" && wiktionarySourceCode !== "auto");
  const shouldFetchOpenRussian = isRussianSource && targetCode === "en";
  const shouldFetchStructuredDictionary =
    (isPersianSource && targetCode === "en") ||
    (searchMode === "precise" && targetCode === "en" && ["fa", "ru"].includes(wiktionarySourceCode));
  const [translateData, dictionaryData, wiktApiDataResult, structuredDictionaryDataResult, wiktionaryDataResult, openRussianDataResult] = await Promise.allSettled([
    fetchGoogleTranslate(word, targetCode, sourceCode),
    isEnglishSource ? fetchEnglishDictionary(word) : Promise.resolve(null),
    shouldFetchWiktApi ? fetchWiktApiTranslations(word, targetCode) : Promise.resolve(null),
    shouldFetchStructuredDictionary ? fetchStructuredDictionaryEntries(word, wiktionarySourceCode) : Promise.resolve(null),
    shouldFetchWiktionary ? fetchWiktionaryData(word, targetCode, wiktionarySourceCode) : Promise.resolve({ entries: [], translations: [] }),
    shouldFetchOpenRussian ? fetchOpenRussianDictionary(word, limits) : Promise.resolve(null)
  ]);

  const translatePayload =
    translateData.status === "fulfilled" ? translateData.value : null;
  const dictionaryPayload =
    dictionaryData.status === "fulfilled" ? dictionaryData.value : null;
  const wiktApiPayload =
    wiktApiDataResult.status === "fulfilled" ? wiktApiDataResult.value : null;
  const structuredDictionaryPayload =
    structuredDictionaryDataResult.status === "fulfilled" ? structuredDictionaryDataResult.value : null;
  const wiktionaryData =
    wiktionaryDataResult.status === "fulfilled" ? wiktionaryDataResult.value : { entries: [], translations: [] };
  const openRussianResult =
    openRussianDataResult.status === "fulfilled" ? openRussianDataResult.value : null;

  const phonetic =
    dictionaryPayload?.phonetic ||
    dictionaryPayload?.phonetics?.find((item) => item.text)?.text ||
    "";

  const definitions = [];
  const examples = [];
  const translatedText = parseTranslateText(translatePayload);
  const translateDefinitions = translatePayload ? parseTranslateDefinitions(translatePayload) : [];
  const dictionaryEntries = extractEnglishDictionaryEntries(dictionaryPayload).slice(0, limits.sourceEntries);
  const wiktionaryEntries = (wiktionaryData.entries || []).slice(0, limits.sourceEntries);
  const wiktApiTranslations = parseWiktApiTranslationTerms(wiktApiPayload, targetCode).slice(0, limits.targetCandidates);
  const wiktionaryTranslations = (wiktionaryData.translations || []).slice(0, limits.targetCandidates);
  const koreanLookupSeed = targetCode === "ko"
    ? uniqueStrings([...wiktApiTranslations, ...wiktionaryTranslations]).find((term) => containsHangul(term)) || ""
    : "";
  const koreanBasicResult = targetCode === "ko" && (searchMode === "precise" || koreanLookupSeed)
    ? await fetchKoreanBasicDictionaryResult(word, koreanLookupSeed, sourceCode)
    : null;
  const sourceResults = [];

  if (targetCode === "en") {
    addSourceResult(sourceResults, openRussianResult);
    addSourceResult(sourceResults, rawEntrySource(dictionaryEntries, "english-dictionary", "Free Dictionary"));
    addSourceResult(sourceResults, structuredDictionarySource(structuredDictionaryPayload, wiktionarySourceCode, limits));
    if (searchMode === "precise" || !isEnglishSource) {
      const wiktionaryLabel = wiktionarySourceCode === "ru"
        ? "Wiktionary Russian-English"
        : wiktionarySourceCode === "fa"
          ? "Wiktionary Persian-English"
          : "Wiktionary Definitions";
      addSourceResult(sourceResults, rawEntrySource(wiktionaryEntries, "wiktionary-definitions", wiktionaryLabel));
    }
  }

  if (wiktApiTranslations.length) {
    addSourceResult(sourceResults, {
      id: "wiktapi-translations",
      label: "WiktApi Translations",
      definitions: formatWiktApiDefinitions(wiktApiPayload, targetCode, limits),
      examples: []
    });
  }

  if (wiktionaryTranslations.length) {
    addSourceResult(sourceResults, {
      id: "wiktionary-translations",
      label: "Wiktionary Translations",
      definitions: wiktionaryTranslations,
      examples: []
    });
  }

  if (koreanBasicResult) {
    addSourceResult(sourceResults, {
      id: "krdict",
      label: "Korean Basic Dictionary",
      definitions: koreanBasicResult.definitions,
      examples: koreanBasicResult.examples
    });
  }

  if (isEnglishSource && targetCode !== "en") {
    const candidates = dictionaryTargetCandidates(wiktApiTranslations, wiktionaryTranslations, koreanBasicResult, limits);
    if (candidates.length) {
      const candidateSources = dictionaryCandidateSources(wiktApiTranslations, wiktionaryTranslations, koreanBasicResult);
      addSourceResult(sourceResults, buildDictionaryCrossCheckSource({
        id: "english-dictionary",
        label: "Free Dictionary Cross-check",
        entries: dictionaryEntries,
        candidates,
        candidateSources,
        targetCode
      }));
      if (searchMode === "precise") {
        addSourceResult(sourceResults, buildDictionaryCrossCheckSource({
          id: "wiktionary-definitions",
          label: "Wiktionary Definition Cross-check",
          entries: wiktionaryEntries,
          candidates,
          candidateSources,
          targetCode
        }));
      }
    }
  }

  let sortedSourceResults = sortSourceResults(sourceResults, targetCode)
    .map((source) => ({
      ...source,
      definitions: uniqueStrings(source.definitions).slice(0, limits.definitions),
      examples: uniqueStrings(source.examples).slice(0, limits.examples)
    }))
    .filter((source) => source.definitions.length || source.examples.length);

  if (!sortedSourceResults.length && translatePayload) {
    sortedSourceResults = sortSourceResults([{
      id: "google-translate",
      label: "Google Translate",
      definitions: uniqueStrings([translatedText, ...translateDefinitions]),
      examples: []
    }], targetCode);
  }

  const storedAiConfig = await aiConfig();
  if (shouldUseAiOrganizer(storedAiConfig, searchMode)) {
    sortedSourceResults = await organizeSourceResultsWithAi({
      word,
      sourceLang: sourceCode,
      targetLang: targetCode,
      sources: sortedSourceResults
    }, storedAiConfig, limits);
  }

  sortedSourceResults.forEach((source) => {
    definitions.push(...source.definitions);
    examples.push(...source.examples);
  });

  return {
    word,
    targetLang: targetCode,
    phonetic,
    definitions: uniqueStrings(definitions).slice(0, limits.definitions + 4),
    examples: uniqueStrings(examples).slice(0, limits.examples),
    source: sortedSourceResults.map((source) => source.id).join(" + ") || "manual",
    sourceResults: sortedSourceResults
  };
}

function extractEnglishDictionaryEntries(dictionaryPayload) {
  const entries = [];

  if (!dictionaryPayload?.meanings) {
    return entries;
  }

  dictionaryPayload.meanings.slice(0, 3).forEach((meaning) => {
    const part = meaning.partOfSpeech || "";
    meaning.definitions.slice(0, 3).forEach((entry) => {
      entries.push({
        part,
        definition: entry.definition || "",
        example: entry.example || ""
      });
    });
  });

  return entries;
}

function dictionarySearchLimits(mode) {
  if (mode === "precise") {
    return {
      sourceEntries: 8,
      targetCandidates: 8,
      definitions: 10,
      examples: 5
    };
  }

  return {
    sourceEntries: 4,
    targetCandidates: 4,
    definitions: 6,
    examples: 2
  };
}

function rawEntrySource(entries, id, label) {
  return {
    id,
    label,
    definitions: entries
      .filter((entry) => entry.definition)
      .map((entry) => formatDefinition(entry.part, entry.definition)),
    examples: entries.map((entry) => entry.example).filter(Boolean)
  };
}

function dictionaryTargetCandidates(wiktApiTranslations, wiktionaryTranslations, koreanBasicResult, limits) {
  return uniqueStrings([
    ...(wiktApiTranslations || []),
    ...(wiktionaryTranslations || []),
    koreanBasicResult?.word || ""
  ]).slice(0, limits.targetCandidates);
}

function dictionaryCandidateSources(wiktApiTranslations, wiktionaryTranslations, koreanBasicResult) {
  return [
    wiktApiTranslations?.length ? "WiktApi translations" : "",
    wiktionaryTranslations?.length ? "Wiktionary translations" : "",
    koreanBasicResult ? "Korean Basic Dictionary" : ""
  ].filter(Boolean);
}

function buildDictionaryCrossCheckSource({ id, label, entries, candidates, candidateSources, targetCode }) {
  if (!Array.isArray(entries) || !entries.length || !Array.isArray(candidates) || !candidates.length) {
    return null;
  }

  const sourceParts = uniqueStrings(entries.map((entry) => entry.part).filter(Boolean));
  const support = uniqueStrings([label.replace(/\s*Cross-check$/i, ""), ...candidateSources]);
  const confidence = Math.min(5, Math.max(2, support.length + (sourceParts.length ? 1 : 0)));
  const suffix = [
    `${confidence}/5`,
    support.join(" + "),
    sourceParts.length ? sourceParts.join(", ") : ""
  ].filter(Boolean).join(" · ");

  return {
    id,
    label: `${label} → ${targetLanguageName(targetCode)}`,
    definitions: candidates.map((candidate) => `${candidate} — ${suffix}`),
    examples: []
  };
}

function sortSourceResults(sourceResults) {
  const priority = {
    openrussian: 6,
    "freedictionaryapi-fa": 8,
    freedictionaryapi: 9,
    krdict: 10,
    "wiktapi-translations": 15,
    "wiktionary-translations": 20,
    "english-dictionary": 30,
    "wiktionary-definitions": 40,
    "google-translate": 90
  };

  return sourceResults
    .filter(Boolean)
    .slice()
    .sort((a, b) => (priority[a.id] || 50) - (priority[b.id] || 50));
}

async function organizeSourceResultsWithAi(payload, config, limits) {
  if (!payload.sources?.length) {
    return payload.sources || [];
  }

  try {
    const aiResult = await requestAiOrganization({
      word: payload.word,
      sourceLang: payload.sourceLang,
      targetLang: payload.targetLang,
      sources: payload.sources.map((source) => ({
        id: source.id,
        label: source.label,
        definitions: source.definitions.slice(0, limits.definitions),
        examples: source.examples.slice(0, limits.examples)
      }))
    }, config);
    return applyAiOrganization(payload.sources, aiResult);
  } catch (_error) {
    return payload.sources;
  }
}

async function requestAiOrganization(payload, config) {
  const normalized = await assertUsableAiConfig(config);
  const systemPrompt = [
    "You sort dictionary lookup results for a language learning browser extension.",
    "Do not create definitions, translations, examples, or source ids.",
    "Return compact JSON only with this shape:",
    "{\"sourceOrder\":[\"source-id\"],\"definitionOrder\":{\"source-id\":[0,1]},\"exampleOrder\":{\"source-id\":[0,1]}}",
    "Only use source ids and indexes that exist in the provided payload.",
    "Prefer direct bilingual dictionaries, exact target-language entries, repeated consensus, useful learner definitions, then machine translation fallbacks."
  ].join(" ");
  const userPrompt = JSON.stringify(payload);
  const text = await callAiProvider(normalized, [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt }
  ]);
  return parseAiJson(text);
}

function applyAiOrganization(sources, aiResult) {
  const sourceMap = new Map(sources.map((source) => [source.id, source]));
  const orderedIds = Array.isArray(aiResult?.sourceOrder)
    ? aiResult.sourceOrder.filter((id) => sourceMap.has(id))
    : [];
  const remainingIds = sources.map((source) => source.id).filter((id) => !orderedIds.includes(id));
  const nextSources = [...orderedIds, ...remainingIds].map((id) => {
    const source = sourceMap.get(id);
    return {
      ...source,
      definitions: reorderByIndexes(source.definitions, aiResult?.definitionOrder?.[id]),
      examples: reorderByIndexes(source.examples, aiResult?.exampleOrder?.[id])
    };
  });
  return nextSources;
}

function reorderByIndexes(values, indexes) {
  if (!Array.isArray(values) || !Array.isArray(indexes)) {
    return values || [];
  }
  const used = new Set();
  const ordered = indexes
    .map((index) => Number(index))
    .filter((index) => Number.isInteger(index) && index >= 0 && index < values.length && !used.has(index) && used.add(index))
    .map((index) => values[index]);
  values.forEach((value, index) => {
    if (!used.has(index)) {
      ordered.push(value);
    }
  });
  return ordered;
}

async function callAiProvider(config, messages) {
  if (config.provider === "gemini") {
    return callGemini(config, messages);
  }
  if (config.provider === "groq") {
    return callOpenAiCompatible("https://api.groq.com/openai/v1/chat/completions", config, messages);
  }
  if (config.provider === "huggingface") {
    return callOpenAiCompatible("https://router.huggingface.co/v1/chat/completions", config, messages);
  }
  if (config.provider === "cloudflare") {
    return callCloudflareAi(config, messages);
  }
  throw new Error("Unknown AI provider");
}

async function callGemini(config, messages) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.model)}:generateContent?key=${encodeURIComponent(config.apiKey)}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{
        role: "user",
        parts: [{ text: messages.map((message) => `${message.role}: ${message.content}`).join("\n\n") }]
      }],
      generationConfig: {
        temperature: 0,
        maxOutputTokens: 512,
        responseMimeType: "application/json"
      }
    })
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(aiErrorMessage(data, response.status));
  }
  return data?.candidates?.[0]?.content?.parts?.map((part) => part.text).join("") || "";
}

async function callOpenAiCompatible(endpoint, config, messages) {
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: config.model,
      messages,
      temperature: 0,
      max_tokens: 512
    })
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(aiErrorMessage(data, response.status));
  }
  return data?.choices?.[0]?.message?.content || "";
}

async function callCloudflareAi(config, messages) {
  const endpoint = `https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(config.accountId)}/ai/run/${config.model}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messages,
      temperature: 0,
      max_tokens: 512
    })
  });
  const data = await response.json();
  if (!response.ok || data?.success === false) {
    throw new Error(aiErrorMessage(data, response.status));
  }
  return data?.result?.response || data?.result?.text || "";
}

function parseAiJson(text) {
  const source = String(text || "").trim();
  if (!source) {
    throw new Error("Empty AI response");
  }
  try {
    return JSON.parse(source);
  } catch (_error) {
    const match = source.match(/\{[\s\S]*\}/);
    if (match) {
      return JSON.parse(match[0]);
    }
    throw new Error("AI response was not JSON");
  }
}

function aiErrorMessage(data, status) {
  return data?.error?.message ||
    data?.errors?.[0]?.message ||
    data?.message ||
    `AI request failed: ${status}`;
}

function targetLanguageName(langCode) {
  const code = googleLangCode(langCode);
  if (code === "ko") return "Korean";
  if (code === "ru") return "Russian";
  if (code === "fa") return "Persian";
  if (code === "tr") return "Turkish";
  if (code === "ja") return "Japanese";
  if (code === "zh-CN") return "Chinese";
  if (code === "en") return "English";
  return code || "target";
}

function addSourceResult(results, source) {
  if (!source) {
    return;
  }
  const definitions = uniqueStrings(source.definitions || []);
  const examples = uniqueStrings(source.examples || []);
  if (!definitions.length && !examples.length) {
    return;
  }
  results.push({
    id: source.id,
    label: source.label,
    definitions,
    examples
  });
}

function formatDefinition(part, definition) {
  return `${part ? `[${part}] ` : ""}${definition}`.trim();
}

async function fetchGoogleTranslate(word, targetLang, sourceLang = "auto") {
  const url = new URL(GOOGLE_TRANSLATE_URL);
  url.searchParams.set("client", "gtx");
  url.searchParams.set("sl", googleLangCode(sourceLang) || "auto");
  url.searchParams.set("tl", googleLangCode(targetLang));
  ["t", "bd", "ex"].forEach((dataType) => {
    url.searchParams.append("dt", dataType);
  });
  url.searchParams.set("dj", "1");
  url.searchParams.set("q", word);

  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Translate request failed: ${response.status}`);
  }

  return response.json();
}

function googleLangCode(langCode) {
  if (!langCode || langCode === "auto") {
    return "auto";
  }
  return langCode;
}

async function fetchEnglishDictionary(word) {
  const response = await fetch(`${ENGLISH_DICTIONARY_URL}/${encodeURIComponent(word)}`);
  if (!response.ok) {
    return null;
  }

  const data = await response.json();
  return Array.isArray(data) ? data[0] : data;
}

async function fetchStructuredDictionaryEntries(word, languageCode) {
  const code = googleLangCode(languageCode);
  if (!code || code === "auto") {
    return null;
  }

  const url = `${FREE_DICTIONARY_API_BASE_URL}/entries/${encodeURIComponent(code)}/${encodeURIComponent(word)}?translations=true`;
  const response = await fetch(url);
  if (!response.ok) {
    return null;
  }

  return response.json();
}

function structuredDictionarySource(payload, sourceLang, limits) {
  const entries = Array.isArray(payload?.entries) ? payload.entries : [];
  if (!entries.length) {
    return null;
  }

  const sourceCode = googleLangCode(sourceLang);
  const label = sourceCode === "fa"
    ? "FreeDictionaryAPI Persian-English"
    : sourceCode === "ru"
      ? "FreeDictionaryAPI Russian-English"
      : "FreeDictionaryAPI";
  const definitions = [];
  const examples = [];

  entries.slice(0, limits.sourceEntries).forEach((entry) => {
    const part = entry.partOfSpeech || "";
    const pronunciation = (entry.pronunciations || [])
      .map((item) => item.text)
      .filter(Boolean)[0] || "";
    const forms = (entry.forms || [])
      .filter((form) => form.word && Array.isArray(form.tags) && form.tags.includes("romanization"))
      .map((form) => form.word)
      .slice(0, 2);
    collectStructuredSenses(entry.senses || [], part, pronunciation, forms, definitions, examples, limits);
  });

  return {
    id: sourceCode === "fa" ? "freedictionaryapi-fa" : "freedictionaryapi",
    label,
    definitions: uniqueStrings(definitions).slice(0, limits.definitions),
    examples: uniqueStrings(examples).slice(0, limits.examples)
  };
}

function collectStructuredSenses(senses, part, pronunciation, forms, definitions, examples, limits) {
  senses.slice(0, limits.sourceEntries).forEach((sense) => {
    if (sense.definition) {
      const meta = uniqueStrings([
        part ? `[${part}]` : "",
        pronunciation,
        ...forms
      ]).join(" · ");
      definitions.push(`${meta ? `${meta} ` : ""}${sense.definition}`.trim());
    }
    if (Array.isArray(sense.examples)) {
      examples.push(...sense.examples);
    }
    if (Array.isArray(sense.subsenses) && sense.subsenses.length) {
      collectStructuredSenses(sense.subsenses, part, pronunciation, forms, definitions, examples, limits);
    }
  });
}

async function fetchWiktApiTranslations(word, targetLang) {
  const targetCode = googleLangCode(targetLang);
  if (!["ko", "ru", "fa"].includes(targetCode)) {
    return null;
  }

  const response = await fetch(`${WIKTAPI_BASE_URL}/en/word/${encodeURIComponent(word)}/translations`);
  if (!response.ok) {
    return null;
  }

  return response.json();
}

function parseWiktApiTranslationTerms(payload, targetLang) {
  const targetCode = googleLangCode(targetLang);
  const terms = [];

  flattenWiktApiTranslations(payload).forEach((item) => {
    if (wiktApiItemLanguageCode(item) === targetCode && item.word) {
      terms.push(item.word);
    }
  });

  return uniqueStrings(terms);
}

function formatWiktApiDefinitions(payload, targetLang, limits) {
  const targetCode = googleLangCode(targetLang);
  const definitions = [];

  flattenWiktApiTranslations(payload).forEach((item) => {
    if (wiktApiItemLanguageCode(item) !== targetCode || !item.word) {
      return;
    }
    const meta = uniqueStrings([
      item.sense || "",
      Array.isArray(item.tags) ? item.tags.join(", ") : "",
      item.roman ? `roman: ${item.roman}` : ""
    ]).join(" · ");
    definitions.push(meta ? `${item.word} — ${meta}` : item.word);
  });

  return uniqueStrings(definitions).slice(0, limits.definitions);
}

function flattenWiktApiTranslations(payload) {
  const groups = Array.isArray(payload?.translations) ? payload.translations : [];
  const items = [];
  groups.forEach((group) => {
    if (group?.word) {
      items.push(group);
    }
    if (Array.isArray(group?.translations)) {
      group.translations.forEach((item) => items.push(item));
    }
  });
  return items;
}

function wiktApiItemLanguageCode(item) {
  return googleLangCode(item?.code || item?.lang_code || "");
}

let openRussianDictionaryPromise = null;

async function fetchOpenRussianDictionary(word, limits) {
  const dictionary = await loadOpenRussianDictionary();
  const entries = openRussianLookupEntries(dictionary, word).slice(0, limits.definitions);
  if (!entries.length) {
    return null;
  }

  return {
    id: "openrussian",
    label: "OpenRussian",
    definitions: entries.map((entry) => {
      const [base, accented, translation, part] = entry;
      const headword = accented || base;
      const partLabel = part ? `[${part}] ` : "";
      return `${partLabel}${headword} — ${translation}`;
    }),
    examples: []
  };
}

async function loadOpenRussianDictionary() {
  if (!openRussianDictionaryPromise) {
    const dictionaryUrl = typeof chrome !== "undefined" && chrome.runtime?.getURL
      ? chrome.runtime.getURL(OPEN_RUSSIAN_DICTIONARY_PATH)
      : OPEN_RUSSIAN_DICTIONARY_PATH;
    openRussianDictionaryPromise = fetch(dictionaryUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`OpenRussian dictionary failed: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        const entries = data?.entries || {};
        const foldedEntries = {};
        Object.entries(entries).forEach(([key, value]) => {
          const foldedKey = foldRussianYo(key);
          if (!foldedEntries[foldedKey]) {
            foldedEntries[foldedKey] = value;
          }
        });
        return { entries, foldedEntries };
      });
  }

  return openRussianDictionaryPromise;
}

function openRussianLookupEntries(dictionary, word) {
  const keys = russianLookupKeys(word);
  const values = [];
  keys.forEach((key) => {
    values.push(...(dictionary.entries[key] || []));
    values.push(...(dictionary.foldedEntries[foldRussianYo(key)] || []));
  });
  return uniqueEntryTuples(values);
}

function russianLookupKeys(word) {
  const normalized = normalizeRussianLookupText(word);
  const stripped = normalized.replace(/[^\u0400-\u04ff\s-]/g, "").trim();
  return uniqueStrings([normalized, stripped, foldRussianYo(normalized), foldRussianYo(stripped)]);
}

function normalizeRussianLookupText(value) {
  return String(value || "")
    .replace(/['\u0301]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function foldRussianYo(value) {
  return String(value || "").replace(/ё/g, "е");
}

function uniqueEntryTuples(entries) {
  const seen = new Set();
  return (entries || []).filter((entry) => {
    const key = Array.isArray(entry) ? entry.join("\u0000").toLowerCase() : "";
    if (!key || seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

async function fetchWiktionaryData(word, targetLang = "", sourceLang = "en") {
  const url = new URL(WIKTIONARY_API_URL);
  url.searchParams.set("action", "parse");
  url.searchParams.set("format", "json");
  url.searchParams.set("origin", "*");
  url.searchParams.set("prop", "wikitext");
  url.searchParams.set("page", word);

  const response = await fetch(url.toString());
  if (!response.ok) {
    return { entries: [], translations: [] };
  }

  const data = await response.json();
  const wikitext = data?.parse?.wikitext?.["*"] || "";
  return {
    entries: parseWiktionaryEntries(wikitext, sourceLang),
    translations: parseWiktionaryTranslations(wikitext, targetLang, sourceLang)
  };
}

async function fetchKoreanBasicDictionaryResult(rawWord, translatedText, sourceLang) {
  const key = await getKoreanBasicDictionaryApiKey();
  const query = koreanBasicLookupQuery(rawWord, translatedText, sourceLang);
  if (!key || !query) {
    return null;
  }

  const searchXml = await fetchKoreanBasicDictionarySearch(query, key);
  const searchEntries = parseKoreanBasicSearch(searchXml);
  const entry =
    searchEntries.find((item) => normalizeKoreanText(item.word) === normalizeKoreanText(query)) ||
    searchEntries[0];

  if (!entry) {
    return null;
  }

  let viewData = null;
  if (entry.targetCode) {
    try {
      const viewXml = await fetchKoreanBasicDictionaryView(entry.targetCode, key);
      viewData = parseKoreanBasicView(viewXml);
    } catch (_error) {
      viewData = null;
    }
  }

  const word = viewData?.word || entry.word || query;
  const pos = viewData?.pos || entry.pos || "";
  const definitions = uniqueStrings([
    ...(viewData?.definitions || []),
    entry.definition
  ]).slice(0, 4);
  const examples = uniqueStrings(viewData?.examples || []).slice(0, 5);

  if (!definitions.length && !examples.length) {
    return null;
  }

  return {
    word,
    definitions: definitions.map((definition) => formatKoreanBasicDefinition(word, pos, definition)),
    examples
  };
}

async function getKoreanBasicDictionaryApiKey() {
  if (typeof globalThis !== "undefined" && globalThis.DE_KRDICT_API_KEY_FOR_TEST) {
    return globalThis.DE_KRDICT_API_KEY_FOR_TEST;
  }
  if (!chrome?.storage?.local) {
    return "";
  }

  return new Promise((resolve) => {
    chrome.storage.local.get([KOREAN_BASIC_DICT_KEY_STORAGE], (result) => {
      resolve(String(result?.[KOREAN_BASIC_DICT_KEY_STORAGE] || KOREAN_BASIC_DICT_DEFAULT_KEY).trim());
    });
  });
}

async function fetchKoreanBasicDictionarySearch(query, key) {
  const url = new URL(KOREAN_BASIC_DICT_SEARCH_URL);
  url.searchParams.set("key", key);
  url.searchParams.set("q", query);
  url.searchParams.set("advanced", "y");
  url.searchParams.set("target", "1");
  url.searchParams.set("method", "exact");
  url.searchParams.set("part", "word");
  url.searchParams.set("sort", "popular");
  url.searchParams.set("num", "10");

  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Korean Basic Dictionary search failed: ${response.status}`);
  }

  return response.text();
}

async function fetchKoreanBasicDictionaryView(targetCode, key) {
  const url = new URL(KOREAN_BASIC_DICT_VIEW_URL);
  url.searchParams.set("key", key);
  url.searchParams.set("method", "target_code");
  url.searchParams.set("q", targetCode);
  url.searchParams.set("translated", "n");

  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Korean Basic Dictionary view failed: ${response.status}`);
  }

  return response.text();
}

function parseTranslateText(data) {
  if (!data?.sentences) {
    return "";
  }

  return data.sentences
    .map((sentence) => sentence.trans)
    .filter(Boolean)
    .join(" ")
    .trim();
}

function parseTranslateDefinitions(data) {
  const definitions = [];

  if (Array.isArray(data?.dict)) {
    data.dict.forEach((group) => {
      const part = group.pos ? `[${group.pos}]` : "";
      if (Array.isArray(group.terms)) {
        group.terms.slice(0, 8).forEach((term) => {
          definitions.push(`${part} ${term}`.trim());
        });
      }
      if (Array.isArray(group.entry)) {
        group.entry.slice(0, 8).forEach((entry) => {
          if (entry.reverse_translation?.length) {
            definitions.push(
              `${part} ${entry.word} - ${entry.reverse_translation.slice(0, 3).join(", ")}`
                .trim()
            );
          } else if (entry.word) {
            definitions.push(`${part} ${entry.word}`.trim());
          }
        });
      }
    });
  }

  return definitions;
}

function parseTranslateExamples(data) {
  const examples = [];
  const rawExamples = data?.examples?.example;

  if (Array.isArray(rawExamples)) {
    rawExamples.forEach((entry) => {
      if (entry.text) {
        examples.push(stripMarkup(entry.text));
      }
    });
  }

  return examples;
}

function parseWiktionaryEntries(wikitext, sourceLang = "en") {
  const languageSection = extractWikiHeadingSection(wikitext, wiktionaryLanguageHeading(sourceLang), 2);
  const entries = [];
  let part = "";
  let currentEntry = null;

  languageSection.split(/\r?\n/).forEach((line) => {
    const heading = line.match(/^===(.+)===$/);
    if (heading) {
      const nextPart = cleanWikiText(heading[1]);
      part = /^(noun|verb|adjective|adverb|pronoun|preposition|conjunction|interjection)$/i
        .test(nextPart)
        ? nextPart.toLowerCase()
        : "";
      return;
    }

    if (!part) {
      return;
    }

    if (/^#\s+/.test(line)) {
      const definition = cleanWikiText(line.replace(/^#\s+/, ""));
      if (definition) {
        currentEntry = { part, definition, example: "" };
        entries.push(currentEntry);
      }
      return;
    }

    if (currentEntry && /^#:\s+/.test(line) && !currentEntry.example) {
      const rawExample = line.replace(/^#:\s+/, "");
      if (/\{\{(?:syn|ant|quote|rq|lb|hyponyms?|hypernyms?|senseid)\b/i.test(rawExample)) {
        return;
      }
      const example = cleanWikiText(rawExample);
      if (example && !/^(synonyms?|antonyms?|hyponyms?|hypernyms?)/i.test(example)) {
        currentEntry.example = example;
      }
    }
  });

  return entries.slice(0, 8);
}

function parseWiktionaryTranslations(wikitext, targetLang, sourceLang = "en") {
  if (googleLangCode(sourceLang) !== "en") {
    return [];
  }

  const targetCode = googleLangCode(targetLang);
  if (!["ko", "ru", "fa"].includes(targetCode)) {
    return [];
  }

  const englishSection = extractWikiHeadingSection(wikitext, "English", 2);
  const escapedCode = targetCode.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const translations = [];
  const templatePattern = new RegExp(`\\{\\{t(?:\\+|-simple)?\\|${escapedCode}\\|([^|}]+)(?:\\|[^}]*)?\\}\\}`, "gi");
  let match = templatePattern.exec(englishSection);
  while (match) {
    translations.push(cleanWikiText(match[1]));
    match = templatePattern.exec(englishSection);
  }

  const linePattern = targetCode === "ko"
    ? /^\*\s*(?:Korean|한국어)\s*:\s*(.+)$/gim
    : targetCode === "ru"
      ? /^\*\s*(?:Russian|русский)\s*:\s*(.+)$/gim
      : /^\*\s*(?:Persian|Farsi|فارسی)\s*:\s*(.+)$/gim;
  let lineMatch = linePattern.exec(englishSection);
  while (lineMatch) {
    const line = lineMatch[1] || "";
    const linkedWords = [...line.matchAll(/\[\[(?:[^|\]]+\|)?([^\]]+)\]\]/g)]
      .map((item) => cleanWikiText(item[1]));
    translations.push(...linkedWords);
    lineMatch = linePattern.exec(englishSection);
  }

  return uniqueStrings(translations).slice(0, 8);
}

function wiktionaryLanguageHeading(sourceLang) {
  const code = googleLangCode(sourceLang);
  if (code === "ru") return "Russian";
  if (code === "fa") return "Persian";
  if (code === "ko") return "Korean";
  if (code === "tr") return "Turkish";
  if (code === "ja") return "Japanese";
  if (code === "zh-CN") return "Chinese";
  return "English";
}

function extractWikiHeadingSection(wikitext, headingName, level) {
  const marks = "=".repeat(level);
  const escapedName = headingName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const startPattern = new RegExp(`^${marks}\\s*${escapedName}\\s*${marks}\\s*$`, "m");
  const startMatch = wikitext.match(startPattern);
  if (!startMatch || startMatch.index === undefined) {
    return "";
  }

  const start = startMatch.index + startMatch[0].length;
  const rest = wikitext.slice(start);
  const endPattern = new RegExp(`^${marks}[^=].*${marks}\\s*$`, "m");
  const endMatch = rest.match(endPattern);
  return endMatch && endMatch.index !== undefined ? rest.slice(0, endMatch.index) : rest;
}

function cleanWikiText(value) {
  return stripMarkup(String(value || "")
    .replace(/\{\{ux\|en\|([^{}|]+)(?:\|[^{}]*)?\}\}/gi, "$1")
    .replace(/\{\{quote-[^{}]*\}\}/gi, "")
    .replace(/\{\{[^{}|]+\|en\|([^{}|]+)(?:\|[^{}]*)?\}\}/gi, "$1")
    .replace(/\{\{[^{}]*\}\}/g, "")
    .replace(/\[\[(?:[^|\]]+\|)?([^\]]+)\]\]/g, "$1")
    .replace(/\[https?:\/\/[^\s\]]+\s*([^\]]*)\]/g, "$1")
    .replace(/'{2,}/g, "")
    .replace(/&quot;/g, "\"")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim());
}

function koreanBasicLookupQuery(rawWord, translatedText, sourceLang) {
  const sourceCode = googleLangCode(sourceLang);
  if (sourceCode === "ko" || containsHangul(rawWord)) {
    return koreanHeadwordCandidate(rawWord);
  }
  return koreanHeadwordCandidate(translatedText);
}

function koreanHeadwordCandidate(value) {
  const text = stripMarkup(value)
    .replace(/\([^)]*\)/g, " ")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/[;,\n/|]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const match = text.match(/[\uac00-\ud7af][\uac00-\ud7af\s-]{0,24}/);
  return match ? normalizeKoreanText(match[0]) : "";
}

function parseKoreanBasicSearch(xmlText) {
  return extractXmlBlocks(xmlText, "item").map((itemXml) => ({
    targetCode: firstXmlValue(itemXml, "target_code"),
    word: firstXmlValue(itemXml, "word"),
    pos: firstXmlValue(itemXml, "pos"),
    pronunciation: firstXmlValue(itemXml, "pronunciation"),
    definition: firstXmlValue(itemXml, "definition")
  })).filter((entry) => entry.word || entry.definition);
}

function parseKoreanBasicView(xmlText) {
  const wordInfo = firstXmlBlock(xmlText, "word_info") || xmlText;
  return {
    word: firstXmlValue(wordInfo, "word"),
    pos: firstXmlValue(wordInfo, "pos"),
    pronunciation: firstXmlValue(wordInfo, "pronunciation"),
    definitions: extractXmlValues(wordInfo, "definition"),
    examples: extractXmlValues(wordInfo, "example")
  };
}

function extractXmlBlocks(xmlText, tagName) {
  const blocks = [];
  const source = String(xmlText || "");
  const pattern = new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "gi");
  let match = pattern.exec(source);
  while (match) {
    blocks.push(match[1]);
    match = pattern.exec(source);
  }
  return blocks;
}

function firstXmlBlock(xmlText, tagName) {
  return extractXmlBlocks(xmlText, tagName)[0] || "";
}

function extractXmlValues(xmlText, tagName) {
  return extractXmlBlocks(xmlText, tagName).map((value) => decodeXmlText(value));
}

function firstXmlValue(xmlText, tagName) {
  return extractXmlValues(xmlText, tagName)[0] || "";
}

function decodeXmlText(value) {
  return stripMarkup(String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim());
}

function formatKoreanBasicDefinition(word, pos, definition) {
  const meta = [word, pos ? `[${pos}]` : ""].filter(Boolean).join(" ");
  return `${meta ? `${meta} ` : ""}${definition}`.trim();
}

function cleanWord(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "")
    .trim();
}

function stripMarkup(value) {
  return String(value || "")
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function uniqueStrings(values) {
  const seen = new Set();
  return values
    .map((value) => stripMarkup(value))
    .filter((value) => {
      if (!value || seen.has(value.toLowerCase())) {
        return false;
      }
      seen.add(value.toLowerCase());
      return true;
    });
}

function looksEnglish(word) {
  return /^[a-z][a-z\s'-]*$/i.test(word);
}

function containsHangul(value) {
  return /[\uac00-\ud7af]/.test(String(value || ""));
}

function containsCyrillic(value) {
  return /[\u0400-\u04ff]/.test(String(value || ""));
}

function containsPersianArabic(value) {
  return /[\u0600-\u06ff]/.test(String(value || ""));
}

function normalizeKoreanText(value) {
  return String(value || "")
    .replace(/[^\uac00-\ud7af\s-]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
