(() => {
  const chrome = globalThis.chrome || globalThis.browser;
  const HOST_ID = "diction-every-host";
  const STORAGE_KEY = "dictionState";
  const DEFAULT_PANEL_WIDTH = 390;
  const DEFAULT_PANEL_HEIGHT = 650;

  if (document.getElementById(HOST_ID)) {
    return;
  }

  const LANGUAGES = [
    { code: "ko", label: { ko: "한국어", en: "Korean", ru: "Корейский", fa: "کره‌ای", tr: "Korece" } },
    { code: "en", label: { ko: "영어", en: "English", ru: "Английский", fa: "انگلیسی", tr: "İngilizce" } },
    { code: "ru", label: { ko: "러시아어", en: "Russian", ru: "Русский", fa: "روسی", tr: "Rusça" } },
    { code: "fa", label: { ko: "페르시아어", en: "Persian", ru: "Персидский", fa: "فارسی", tr: "Farsça" } },
    { code: "tr", label: { ko: "튀르키예어", en: "Turkish", ru: "Турецкий", fa: "ترکی", tr: "Türkçe" } },
    { code: "ja", label: { ko: "일본어", en: "Japanese", ru: "Японский", fa: "ژاپنی", tr: "Japonca" } },
    { code: "zh-CN", label: { ko: "중국어", en: "Chinese", ru: "Китайский", fa: "چینی", tr: "Çince" } }
  ];

  const I18N = {
    ko: {
      appName: "DictionEvery",
      searchPlaceholder: "단어 검색...",
      menu: "메뉴",
      vocabulary: "단어장",
      test: "테스트",
      settings: "설정",
      meaningLanguage: "도착언어",
      meaningLanguages: "도착언어",
      sourceLanguage: "시작언어",
      chooseMeaningLanguages: "뜻을 표시할 언어",
      menuLanguage: "언어",
      changeLanguage: "언어 전환",
      interfaceLanguage: "인터페이스 언어",
      theme: "화면 모드",
      system: "시스템 설정",
      light: "밝게",
      dark: "어둡게",
      decks: "단어장",
      words: "단어",
      knownWords: "알고 있는 단어",
      emptyDecks: "아직 단어장이 비어 있습니다.",
      emptyWords: "저장된 단어가 없습니다.",
      emptyHomeTitle: "아직 저장된 단어가 없습니다.",
      emptyHomeBody: "웹페이지에서 단어를 선택하거나 검색창으로 첫 단어를 찾아 저장해보세요.",
      emptyDeckTitle: "이 단어장은 비어 있습니다.",
      searchToAddWords: "텍스트에서 단어를 선택하거나 위 검색창으로 단어를 추가하세요.",
      knownRatio: "습득률",
      reviewedWords: "복습한 단어",
      notEnoughWords: "테스트할 단어가 아직 없습니다.",
      dictionary: "사전",
      dictionarySources: "사전",
      meanings: "뜻",
      allSources: "전체",
      addVocabulary: "단어장에 추가",
      chooseDeck: "단어장 선택",
      newDeck: "+ 새 단어장 만들기",
      newDeckPlaceholder: "새 단어장 이름",
      save: "저장",
      saved: "저장되었습니다.",
      update: "수정",
      delete: "삭제",
      cancel: "취소",
      edit: "편집",
      loading: "뜻을 찾는 중...",
      manualDefinition: "뜻을 찾지 못했습니다. 직접 의미를 입력해주세요.",
      lookupFailed: "사전 결과를 가져오지 못했습니다. 직접 입력하거나 잠시 후 다시 시도하세요.",
      examples: "예문",
      notes: "메모",
      proficiency: "숙련도",
      chooseTest: "테스트 시작",
      cardTest: "카드",
      spellingTest: "철자 입력",
      choiceTest: "뜻 고르기",
      cardHint: "카드를 눌러 뜻을 확인하세요.",
      memorized: "알고 있음",
      notMemorized: "아직 모름",
      typeAnswer: "단어를 입력하세요",
      listenAndType: "스피커를 눌러 듣고 단어를 입력하세요.",
      correct: "정답",
      incorrect: "오답",
      reviewMeaning: "뜻을 확인하세요",
      submit: "확인",
      skip: "건너뛰기",
      next: "다음",
      finish: "완료",
      result: "테스트 완료",
      startTestHint: "단어장을 선택한 뒤 테스트를 시작하세요.",
      selectWord: "에서 찾기",
      noWord: "검색할 단어를 입력해주세요.",
      reset: "전체 데이터 초기화",
      resetConfirm: "저장된 단어장과 단어를 모두 삭제할까요?",
      openPanel: "패널 열기",
      closePanel: "패널 닫기",
      back: "뒤로가기",
      searchAction: "사전에서 찾기",
      settingsGeneral: "주요 설정",
      settingsLookup: "검색·학습",
      settingsAi: "선택 기능",
      settingsData: "데이터 관리",
      batchSize: "한 번에 테스트할 단어 수",
      dictionarySearchMode: "검색 우선순위",
      searchFast: "속도 우선",
      searchPrecise: "품질 우선",
      dictionarySearchHint: "속도 우선은 빠른 사전 결과를 먼저 보여주고, 품질 우선은 여러 사전을 더 넓게 대조합니다.",
      aiOrganizer: "AI 사전 정렬",
      aiOff: "사용 안 함",
      aiQualityOnly: "품질 우선에서만 사용",
      aiAlways: "항상 사용",
      aiOrganizerHint: "AI는 새 뜻을 만들지 않고 사전 결과의 순서와 중복 정리만 보조합니다.",
      aiProvider: "AI 제공자",
      aiApiKey: "API 키",
      aiApiKeyPlaceholder: "API 키 입력",
      aiKeepKey: "비워두면 저장된 키 유지",
      aiKeySaved: "API 키 저장됨",
      aiKeyNotSaved: "API 키가 저장되지 않았습니다.",
      aiModel: "모델",
      aiAccountId: "계정 ID",
      aiAccountIdPlaceholder: "Cloudflare 사용 시 필요",
      aiAccountHint: "Cloudflare Workers AI를 사용할 때만 계정 ID가 필요합니다.",
      aiTest: "AI 테스트",
      aiTesting: "AI 테스트 중...",
      aiTestOk: "AI 정렬 테스트 성공",
      aiTestFailed: "AI 정렬 테스트 실패",
      aiSaving: "AI 설정 저장 중...",
      aiConfigSaved: "AI 설정을 저장했습니다.",
      aiConfigCleared: "AI 설정을 초기화했습니다.",
      aiConfigFailed: "AI 설정을 저장하지 못했습니다.",
      integratedTest: "통합 테스트",
      testIntro: "각 단어마다 카드, 뜻 고르기, 철자 입력 중 두 방식이 임의로 배정됩니다.",
      savedMeaning: "저장된 뜻",
      term: "단어",
      sourceExamples: "예문",
      learned: "습득",
      listen: "듣기",
      share: "공유",
      exportVocabulary: "단어 내보내기",
      exportSubtitle: "현재 단어장을 다른 학습 플랫폼으로 옮깁니다.",
      ankiExport: "Anki용 TSV 다운로드",
      quizletExport: "Quizlet용 복사",
      lingqExport: "LingQ용 CSV 다운로드",
      exportReady: "내보내기 준비 완료",
      exportCopied: "복사되었습니다.",
      exportDownloaded: "파일을 다운로드했습니다.",
      exportEmpty: "내보낼 단어가 없습니다.",
      ankiGuideTitle: "Anki로 가져오기",
      quizletGuideTitle: "Quizlet으로 가져오기",
      lingqGuideTitle: "LingQ로 가져오기",
      ankiGuide1: "Anki Desktop을 열고 파일 가져오기를 선택하세요.",
      ankiGuide2: "방금 다운로드한 TSV 파일을 선택하고 앞면/뒷면 필드에 매핑하세요.",
      ankiGuide3: "모바일에서는 AnkiWeb 동기화로 같은 카드를 사용할 수 있습니다.",
      quizletGuide1: "Quizlet에서 새 세트 만들기를 여세요.",
      quizletGuide2: "가져오기 버튼을 누르고 복사된 내용을 붙여넣으세요.",
      quizletGuide3: "구분자는 탭, 행 구분은 줄바꿈으로 선택하면 됩니다.",
      lingqGuide1: "LingQ의 Vocabulary Import 화면을 여세요.",
      lingqGuide2: "방금 다운로드한 CSV 파일을 업로드하세요.",
      lingqGuide3: "term, phrase, meaninglanguage1, meaning1 필드를 확인한 뒤 가져오세요.",
      openQuizlet: "Quizlet 열기",
      openLingq: "LingQ 열기",
      sync: "동기화",
      syncTitle: "계정 동기화",
      syncSubtitle: "다른 기기와 단어장을 수동으로 주고받습니다.",
      email: "이메일",
      password: "비밀번호",
      signIn: "로그인",
      signUp: "회원가입",
      googleSignIn: "Google로 로그인",
      signOut: "로그아웃",
      syncUpload: "업로드",
      syncDownload: "다운로드",
      syncMerge: "병합",
      syncManualHint: "업로드는 현재 단어장을 올리고, 다운로드는 서버 데이터를 가져오며, 병합은 최신 수정 단어를 기준으로 합칩니다.",
      syncConfiguredMissing: "Supabase 주소와 공개 키를 설정하면 사용할 수 있습니다.",
      syncLoggedInAs: "로그인됨",
      syncLoggedOut: "로그인하지 않음",
      syncUploadDone: "업로드 완료",
      syncDownloadDone: "다운로드 완료",
      syncMergeDone: "병합 완료",
      syncLatestWins: "같은 단어는 마지막 수정 시간이 더 최신인 항목을 우선합니다.",
      syncBusy: "동기화 중...",
      syncNoWords: "동기화할 단어가 없습니다.",
      syncNeedsLogin: "먼저 로그인해주세요.",
      syncRemoteCount: "가져온 단어",
      syncLocalCount: "내 단어",
      syncSetupTitle: "Supabase 연결",
      supabaseUrl: "Supabase 프로젝트 URL",
      supabaseAnonKey: "Public anon key",
      supabaseTable: "테이블 이름",
      saveSyncConfig: "연결 저장",
      resetSyncConfig: "연결 초기화",
      syncConfigSaved: "연결 설정을 저장했습니다.",
      syncConfigHint: "Supabase SQL을 먼저 실행한 뒤 프로젝트 URL과 public anon key를 입력하세요.",
      syncConfigReady: "연결 설정됨",
      syncRedirectUrl: "Google 로그인 Redirect URL",
      syncTestConnection: "연결 테스트",
      syncConnectionOk: "연결을 확인했습니다.",
      syncConnectionFailed: "연결 확인 실패"
    },
    en: {
      appName: "DictionEvery",
      searchPlaceholder: "Search words...",
      menu: "Menu",
      vocabulary: "Vocabulary",
      test: "Test",
      settings: "Setting",
      meaningLanguage: "Target language",
      meaningLanguages: "Target languages",
      sourceLanguage: "Source language",
      chooseMeaningLanguages: "Meaning languages",
      menuLanguage: "Language",
      changeLanguage: "Change Language",
      interfaceLanguage: "Interface language",
      theme: "Theme",
      system: "System",
      light: "Light",
      dark: "Dark",
      decks: "Decks",
      words: "words",
      knownWords: "known words",
      emptyDecks: "Your vocabulary is empty.",
      emptyWords: "No saved words yet.",
      emptyHomeTitle: "No saved words yet.",
      emptyHomeBody: "Select a word on a page or search one above to save your first word.",
      emptyDeckTitle: "This deck is empty.",
      searchToAddWords: "Select words in text or use the search field above to add them.",
      knownRatio: "Known ratio",
      reviewedWords: "reviewed words",
      notEnoughWords: "No words available for a test yet.",
      dictionary: "Dictionary page",
      dictionarySources: "Dictionaries",
      meanings: "Meanings",
      allSources: "All",
      addVocabulary: "Add in Vocabulary",
      chooseDeck: "Choose deck",
      newDeck: "+ Create new deck",
      newDeckPlaceholder: "New deck name",
      save: "Save",
      saved: "Saved.",
      update: "Update",
      delete: "Delete",
      cancel: "Cancel",
      edit: "Edit",
      loading: "Looking up definitions...",
      manualDefinition: "No definition found. Add your own meaning.",
      lookupFailed: "Could not load dictionary results. Add a meaning manually or try again later.",
      examples: "Examples",
      notes: "Notes",
      proficiency: "Proficiency rate",
      chooseTest: "Choose Test Mode",
      cardTest: "Card Test",
      spellingTest: "Spelling Test",
      choiceTest: "Meaning Test",
      cardHint: "Tap the card to reveal meaning",
      memorized: "Memorized",
      notMemorized: "Not memorized",
      typeAnswer: "Type the word",
      listenAndType: "Tap the speaker and type the word.",
      correct: "Correct",
      incorrect: "Incorrect",
      reviewMeaning: "Review the meaning",
      submit: "Submit",
      skip: "Skip",
      next: "Next",
      finish: "Finish",
      result: "Test Completed",
      startTestHint: "Choose a deck first, then start a test.",
      selectWord: "Find in",
      noWord: "Enter a word to search.",
      reset: "Reset all data",
      resetConfirm: "Delete every saved deck and word?",
      openPanel: "Open panel",
      closePanel: "Close panel",
      back: "Back",
      searchAction: "Search dictionary",
      settingsGeneral: "Primary settings",
      settingsLookup: "Lookup & study",
      settingsAi: "Optional features",
      settingsData: "Data management",
      batchSize: "Words per test",
      dictionarySearchMode: "Search priority",
      searchFast: "Prioritize speed",
      searchPrecise: "Prioritize quality",
      dictionarySearchHint: "Speed shows the quickest dictionary results first. Quality compares more sources for stronger matches.",
      aiOrganizer: "AI dictionary sorting",
      aiOff: "Off",
      aiQualityOnly: "Use only for quality priority",
      aiAlways: "Always use",
      aiOrganizerHint: "AI does not create meanings. It only helps order and deduplicate dictionary results.",
      aiProvider: "AI provider",
      aiApiKey: "API key",
      aiApiKeyPlaceholder: "Enter API key",
      aiKeepKey: "Leave blank to keep saved key",
      aiKeySaved: "API key saved",
      aiKeyNotSaved: "No API key saved.",
      aiModel: "Model",
      aiAccountId: "Account ID",
      aiAccountIdPlaceholder: "Required for Cloudflare",
      aiAccountHint: "Account ID is only needed for Cloudflare Workers AI.",
      aiTest: "Test AI",
      aiTesting: "Testing AI...",
      aiTestOk: "AI sorting test succeeded",
      aiTestFailed: "AI sorting test failed",
      aiSaving: "Saving AI settings...",
      aiConfigSaved: "AI settings saved.",
      aiConfigCleared: "AI settings reset.",
      aiConfigFailed: "Could not save AI settings.",
      integratedTest: "Integrated Test",
      testIntro: "Each word is tested with two random modes from cards, meaning choices, and spelling.",
      savedMeaning: "Saved Meaning",
      term: "Term",
      sourceExamples: "Examples",
      learned: "learned",
      listen: "Listen",
      share: "Share",
      exportVocabulary: "Export vocabulary",
      exportSubtitle: "Move this deck to another learning platform.",
      ankiExport: "Download Anki TSV",
      quizletExport: "Copy for Quizlet",
      lingqExport: "Download LingQ CSV",
      exportReady: "Export ready",
      exportCopied: "Copied.",
      exportDownloaded: "File downloaded.",
      exportEmpty: "No words to export.",
      ankiGuideTitle: "Import to Anki",
      quizletGuideTitle: "Import to Quizlet",
      lingqGuideTitle: "Import to LingQ",
      ankiGuide1: "Open Anki Desktop and choose Import File.",
      ankiGuide2: "Select the downloaded TSV file and map the fields to Front and Back.",
      ankiGuide3: "Use AnkiWeb sync to study the same cards on mobile.",
      quizletGuide1: "Open Create a new set in Quizlet.",
      quizletGuide2: "Choose Import and paste the copied text.",
      quizletGuide3: "Use tab as the term separator and new line as the card separator.",
      lingqGuide1: "Open the Vocabulary Import screen in LingQ.",
      lingqGuide2: "Upload the downloaded CSV file.",
      lingqGuide3: "Check term, phrase, meaninglanguage1, and meaning1 before importing.",
      openQuizlet: "Open Quizlet",
      openLingq: "Open LingQ",
      sync: "Sync",
      syncTitle: "Account sync",
      syncSubtitle: "Manually move your vocabulary between devices.",
      email: "Email",
      password: "Password",
      signIn: "Sign in",
      signUp: "Create account",
      googleSignIn: "Sign in with Google",
      signOut: "Sign out",
      syncUpload: "Upload",
      syncDownload: "Download",
      syncMerge: "Merge",
      syncManualHint: "Upload sends local words, Download brings server words, and Merge keeps the newest edited word.",
      syncConfiguredMissing: "Add a Supabase URL and public anon key to enable sync.",
      syncLoggedInAs: "Signed in",
      syncLoggedOut: "Not signed in",
      syncUploadDone: "Upload complete",
      syncDownloadDone: "Download complete",
      syncMergeDone: "Merge complete",
      syncLatestWins: "When the same word exists twice, the latest updated item wins.",
      syncBusy: "Syncing...",
      syncNoWords: "No words to sync.",
      syncNeedsLogin: "Sign in first.",
      syncRemoteCount: "remote words",
      syncLocalCount: "local words",
      syncSetupTitle: "Supabase connection",
      supabaseUrl: "Supabase project URL",
      supabaseAnonKey: "Public anon key",
      supabaseTable: "Table name",
      saveSyncConfig: "Save connection",
      resetSyncConfig: "Reset connection",
      syncConfigSaved: "Connection settings saved.",
      syncConfigHint: "Run the Supabase SQL first, then enter the project URL and public anon key.",
      syncConfigReady: "Connection configured",
      syncRedirectUrl: "Google sign-in Redirect URL",
      syncTestConnection: "Test connection",
      syncConnectionOk: "Connection verified.",
      syncConnectionFailed: "Connection check failed"
    },
    ru: {
      appName: "DictionEvery",
      searchPlaceholder: "Поиск слова...",
      menu: "Меню",
      vocabulary: "Словарь",
      test: "Тест",
      settings: "Настройки",
      meaningLanguage: "Целевой язык",
      meaningLanguages: "Целевые языки",
      sourceLanguage: "Исходный язык",
      chooseMeaningLanguages: "Языки значений",
      menuLanguage: "Язык",
      changeLanguage: "Сменить язык",
      interfaceLanguage: "Язык интерфейса",
      theme: "Тема",
      system: "Как в системе",
      light: "Светлая",
      dark: "Тёмная",
      decks: "Списки слов",
      words: "слова",
      knownWords: "известные слова",
      emptyDecks: "Списки слов пока пусты.",
      emptyWords: "Сохранённых слов пока нет.",
      emptyHomeTitle: "Сохранённых слов пока нет.",
      emptyHomeBody: "Выделите слово на странице или найдите его сверху, чтобы сохранить первое слово.",
      emptyDeckTitle: "Этот список пуст.",
      searchToAddWords: "Выделите слово в тексте или воспользуйтесь поиском сверху.",
      knownRatio: "Доля знакомых",
      reviewedWords: "повторено",
      notEnoughWords: "Пока нет слов для теста.",
      dictionary: "Словарь",
      dictionarySources: "Словари",
      meanings: "Значения",
      allSources: "Все",
      addVocabulary: "Добавить в словарь",
      chooseDeck: "Выберите список",
      newDeck: "+ Новый список",
      newDeckPlaceholder: "Название списка",
      save: "Сохранить",
      saved: "Сохранено.",
      update: "Обновить",
      delete: "Удалить",
      cancel: "Отмена",
      edit: "Редактировать",
      loading: "Ищем значение...",
      manualDefinition: "Значение не найдено. Введите его вручную.",
      lookupFailed: "Не удалось загрузить словарные результаты. Введите значение вручную или попробуйте позже.",
      examples: "Примеры",
      notes: "Заметки",
      proficiency: "Уровень знания",
      chooseTest: "Начать тест",
      cardTest: "Карточка",
      spellingTest: "Правописание",
      choiceTest: "Выбор значения",
      cardHint: "Нажмите на карточку, чтобы увидеть значение.",
      memorized: "Знаю",
      notMemorized: "Ещё не знаю",
      typeAnswer: "Введите слово",
      listenAndType: "Нажмите на динамик и введите слово.",
      correct: "Верно",
      incorrect: "Неверно",
      reviewMeaning: "Посмотрите значение",
      submit: "Проверить",
      skip: "Пропустить",
      next: "Далее",
      finish: "Готово",
      result: "Тест завершён",
      startTestHint: "Сначала выберите список слов, затем начните тест.",
      selectWord: "Найти в",
      noWord: "Введите слово для поиска.",
      reset: "Сбросить все данные",
      resetConfirm: "Удалить все сохранённые списки и слова?",
      openPanel: "Открыть панель",
      closePanel: "Закрыть панель",
      back: "Назад",
      searchAction: "Искать в словаре",
      settingsGeneral: "Главные настройки",
      settingsLookup: "Поиск и обучение",
      settingsAi: "Дополнительные функции",
      settingsData: "Управление данными",
      batchSize: "Слов за один тест",
      dictionarySearchMode: "Приоритет поиска",
      searchFast: "Приоритет скорости",
      searchPrecise: "Приоритет качества",
      dictionarySearchHint: "Скорость показывает быстрые результаты первыми. Качество шире сверяет несколько словарей.",
      aiOrganizer: "AI-сортировка словаря",
      aiOff: "Не использовать",
      aiQualityOnly: "Только при приоритете качества",
      aiAlways: "Использовать всегда",
      aiOrganizerHint: "AI не создаёт значения, а только помогает упорядочить и убрать повторы в словарных результатах.",
      aiProvider: "AI-провайдер",
      aiApiKey: "API-ключ",
      aiApiKeyPlaceholder: "Введите API-ключ",
      aiKeepKey: "Оставьте пустым, чтобы сохранить текущий ключ",
      aiKeySaved: "API-ключ сохранён",
      aiKeyNotSaved: "API-ключ не сохранён.",
      aiModel: "Модель",
      aiAccountId: "Account ID",
      aiAccountIdPlaceholder: "Нужно для Cloudflare",
      aiAccountHint: "Account ID нужен только для Cloudflare Workers AI.",
      aiTest: "Проверить AI",
      aiTesting: "Проверка AI...",
      aiTestOk: "AI-сортировка работает",
      aiTestFailed: "Проверка AI не удалась",
      aiSaving: "Сохранение настроек AI...",
      aiConfigSaved: "Настройки AI сохранены.",
      aiConfigCleared: "Настройки AI сброшены.",
      aiConfigFailed: "Не удалось сохранить настройки AI.",
      integratedTest: "Общий тест",
      testIntro: "Для каждого слова выбираются два случайных режима: карточка, значение или правописание.",
      savedMeaning: "Сохранённое значение",
      term: "Слово",
      sourceExamples: "Примеры",
      learned: "выучено",
      listen: "Прослушать",
      share: "Поделиться",
      exportVocabulary: "Экспорт слов",
      exportSubtitle: "Перенесите этот список в другую учебную платформу.",
      ankiExport: "Скачать TSV для Anki",
      quizletExport: "Скопировать для Quizlet",
      lingqExport: "Скачать CSV для LingQ",
      exportReady: "Экспорт готов",
      exportCopied: "Скопировано.",
      exportDownloaded: "Файл скачан.",
      exportEmpty: "Нет слов для экспорта.",
      ankiGuideTitle: "Импорт в Anki",
      quizletGuideTitle: "Импорт в Quizlet",
      lingqGuideTitle: "Импорт в LingQ",
      ankiGuide1: "Откройте Anki Desktop и выберите импорт файла.",
      ankiGuide2: "Выберите скачанный TSV и сопоставьте поля Front и Back.",
      ankiGuide3: "Для мобильного обучения используйте синхронизацию AnkiWeb.",
      quizletGuide1: "Откройте создание нового набора в Quizlet.",
      quizletGuide2: "Нажмите Import и вставьте скопированный текст.",
      quizletGuide3: "Выберите табуляцию как разделитель терминов и новую строку как разделитель карточек.",
      lingqGuide1: "Откройте экран Vocabulary Import в LingQ.",
      lingqGuide2: "Загрузите скачанный CSV-файл.",
      lingqGuide3: "Проверьте поля term, phrase, meaninglanguage1 и meaning1 перед импортом.",
      openQuizlet: "Открыть Quizlet",
      openLingq: "Открыть LingQ",
      sync: "Синхронизация",
      syncTitle: "Синхронизация аккаунта",
      syncSubtitle: "Переносите словарь между устройствами вручную.",
      email: "Эл. почта",
      password: "Пароль",
      signIn: "Войти",
      signUp: "Создать аккаунт",
      googleSignIn: "Войти через Google",
      signOut: "Выйти",
      syncUpload: "Загрузить",
      syncDownload: "Скачать",
      syncMerge: "Объединить",
      syncManualHint: "Загрузка отправляет локальные слова, скачивание получает серверные, объединение оставляет самые новые изменения.",
      syncConfiguredMissing: "Добавьте URL Supabase и публичный anon key, чтобы включить синхронизацию.",
      syncLoggedInAs: "Выполнен вход",
      syncLoggedOut: "Вы не вошли",
      syncUploadDone: "Загрузка завершена",
      syncDownloadDone: "Скачивание завершено",
      syncMergeDone: "Объединение завершено",
      syncLatestWins: "Если слово совпадает, используется версия с более поздним временем изменения.",
      syncBusy: "Синхронизация...",
      syncNoWords: "Нет слов для синхронизации.",
      syncNeedsLogin: "Сначала войдите.",
      syncRemoteCount: "слов с сервера",
      syncLocalCount: "локальных слов",
      syncSetupTitle: "Подключение Supabase",
      supabaseUrl: "URL проекта Supabase",
      supabaseAnonKey: "Public anon key",
      supabaseTable: "Имя таблицы",
      saveSyncConfig: "Сохранить подключение",
      resetSyncConfig: "Сбросить подключение",
      syncConfigSaved: "Настройки подключения сохранены.",
      syncConfigHint: "Сначала выполните Supabase SQL, затем введите URL проекта и public anon key.",
      syncConfigReady: "Подключение настроено",
      syncRedirectUrl: "Redirect URL для входа через Google",
      syncTestConnection: "Проверить подключение",
      syncConnectionOk: "Подключение проверено.",
      syncConnectionFailed: "Проверка подключения не удалась"
    },
    tr: {
      appName: "DictionEvery",
      searchPlaceholder: "Kelime ara...",
      menu: "Menü",
      vocabulary: "Kelime defteri",
      test: "Test",
      settings: "Ayarlar",
      meaningLanguage: "Hedef dil",
      meaningLanguages: "Hedef diller",
      sourceLanguage: "Kaynak dil",
      chooseMeaningLanguages: "Anlamların gösterileceği diller",
      menuLanguage: "Dil",
      changeLanguage: "Dili değiştir",
      interfaceLanguage: "Arayüz dili",
      theme: "Görünüm modu",
      system: "Sistem ayarı",
      light: "Açık",
      dark: "Koyu",
      decks: "Kelime listeleri",
      words: "kelime",
      knownWords: "bilinen kelimeler",
      emptyDecks: "Henüz kelime listeniz yok.",
      emptyWords: "Kayıtlı kelime yok.",
      emptyHomeTitle: "Henüz kayıtlı kelime yok.",
      emptyHomeBody: "İlk kelimeyi kaydetmek için sayfada bir kelime seçin veya yukarıdan arayın.",
      emptyDeckTitle: "Bu liste boş.",
      searchToAddWords: "Metinde kelime seçin veya yukarıdaki arama alanından kelime ekleyin.",
      knownRatio: "Bilme oranı",
      reviewedWords: "tekrar edilen kelime",
      notEnoughWords: "Test için henüz kelime yok.",
      dictionary: "Sözlük",
      dictionarySources: "Sözlükler",
      meanings: "Anlamlar",
      allSources: "Tümü",
      addVocabulary: "Kelime defterine ekle",
      chooseDeck: "Liste seç",
      newDeck: "+ Yeni liste oluştur",
      newDeckPlaceholder: "Yeni liste adı",
      save: "Kaydet",
      saved: "Kaydedildi.",
      update: "Güncelle",
      delete: "Sil",
      cancel: "İptal",
      edit: "Düzenle",
      loading: "Anlam aranıyor...",
      manualDefinition: "Anlam bulunamadı. Anlamı elle girin.",
      lookupFailed: "Sözlük sonuçları yüklenemedi. Anlamı elle ekleyin veya daha sonra tekrar deneyin.",
      examples: "Örnekler",
      notes: "Notlar",
      proficiency: "Hakimiyet",
      chooseTest: "Testi başlat",
      cardTest: "Kart",
      spellingTest: "Yazım",
      choiceTest: "Anlam seçme",
      cardHint: "Anlamı görmek için karta dokunun.",
      memorized: "Biliyorum",
      notMemorized: "Henüz bilmiyorum",
      typeAnswer: "Kelimeyi yazın",
      listenAndType: "Hoparlöre dokunup kelimeyi yazın.",
      correct: "Doğru",
      incorrect: "Yanlış",
      reviewMeaning: "Anlamı gözden geçirin",
      submit: "Kontrol et",
      skip: "Atla",
      next: "Sonraki",
      finish: "Bitir",
      result: "Test tamamlandı",
      startTestHint: "Önce bir kelime listesi seçin, sonra testi başlatın.",
      selectWord: "Şurada ara",
      noWord: "Aramak için bir kelime girin.",
      reset: "Tüm verileri sıfırla",
      resetConfirm: "Kayıtlı tüm listeler ve kelimeler silinsin mi?",
      openPanel: "Paneli aç",
      closePanel: "Paneli kapat",
      back: "Geri",
      searchAction: "Sözlükte ara",
      settingsGeneral: "Temel ayarlar",
      settingsLookup: "Arama ve çalışma",
      settingsAi: "İsteğe bağlı özellikler",
      settingsData: "Veri yönetimi",
      batchSize: "Test başına kelime sayısı",
      dictionarySearchMode: "Arama önceliği",
      searchFast: "Hızı öncele",
      searchPrecise: "Kaliteyi öncele",
      dictionarySearchHint: "Hız en çabuk sözlük sonuçlarını önce gösterir. Kalite daha fazla kaynağı karşılaştırır.",
      aiOrganizer: "AI sözlük sıralama",
      aiOff: "Kapalı",
      aiQualityOnly: "Yalnızca kalite önceliğinde kullan",
      aiAlways: "Her zaman kullan",
      aiOrganizerHint: "AI yeni anlam üretmez; yalnızca sözlük sonuçlarını sıralar ve tekrarları düzenler.",
      aiProvider: "AI sağlayıcısı",
      aiApiKey: "API anahtarı",
      aiApiKeyPlaceholder: "API anahtarını girin",
      aiKeepKey: "Boş bırakırsanız kayıtlı anahtar korunur",
      aiKeySaved: "API anahtarı kayıtlı",
      aiKeyNotSaved: "API anahtarı kayıtlı değil.",
      aiModel: "Model",
      aiAccountId: "Hesap ID",
      aiAccountIdPlaceholder: "Cloudflare için gerekli",
      aiAccountHint: "Hesap ID yalnızca Cloudflare Workers AI için gerekir.",
      aiTest: "AI test et",
      aiTesting: "AI test ediliyor...",
      aiTestOk: "AI sıralama testi başarılı",
      aiTestFailed: "AI sıralama testi başarısız",
      aiSaving: "AI ayarları kaydediliyor...",
      aiConfigSaved: "AI ayarları kaydedildi.",
      aiConfigCleared: "AI ayarları sıfırlandı.",
      aiConfigFailed: "AI ayarları kaydedilemedi.",
      integratedTest: "Birleşik test",
      testIntro: "Her kelime için kart, anlam seçme ve yazım modlarından ikisi rastgele seçilir.",
      savedMeaning: "Kayıtlı anlam",
      term: "Kelime",
      sourceExamples: "Örnekler",
      learned: "öğrenildi",
      listen: "Dinle",
      share: "Paylaş",
      exportVocabulary: "Kelimeleri dışa aktar",
      exportSubtitle: "Bu listeyi başka bir öğrenme platformuna taşıyın.",
      ankiExport: "Anki için TSV indir",
      quizletExport: "Quizlet için kopyala",
      lingqExport: "LingQ için CSV indir",
      exportReady: "Dışa aktarma hazır",
      exportCopied: "Kopyalandı.",
      exportDownloaded: "Dosya indirildi.",
      exportEmpty: "Dışa aktarılacak kelime yok.",
      ankiGuideTitle: "Anki'ye aktarma",
      quizletGuideTitle: "Quizlet'e aktarma",
      lingqGuideTitle: "LingQ'ya aktarma",
      ankiGuide1: "Anki Desktop'ı açın ve dosya içe aktarmayı seçin.",
      ankiGuide2: "İndirilen TSV dosyasını seçip alanları Ön ve Arka olarak eşleştirin.",
      ankiGuide3: "Mobilde aynı kartları çalışmak için AnkiWeb eşitlemesini kullanabilirsiniz.",
      quizletGuide1: "Quizlet'te yeni set oluşturma ekranını açın.",
      quizletGuide2: "İçe aktar düğmesine basın ve kopyalanan metni yapıştırın.",
      quizletGuide3: "Terim ayırıcı olarak sekme, kart ayırıcı olarak yeni satır seçin.",
      lingqGuide1: "LingQ'da Vocabulary Import ekranını açın.",
      lingqGuide2: "İndirilen CSV dosyasını yükleyin.",
      lingqGuide3: "İçe aktarmadan önce term, phrase, meaninglanguage1 ve meaning1 alanlarını kontrol edin.",
      openQuizlet: "Quizlet'i aç",
      openLingq: "LingQ'yu aç",
      sync: "Eşitle",
      syncTitle: "Hesap eşitleme",
      syncSubtitle: "Kelime defterinizi cihazlar arasında elle taşıyın.",
      email: "E-posta",
      password: "Şifre",
      signIn: "Giriş yap",
      signUp: "Hesap oluştur",
      googleSignIn: "Google ile giriş yap",
      signOut: "Çıkış yap",
      syncUpload: "Yükle",
      syncDownload: "İndir",
      syncMerge: "Birleştir",
      syncManualHint: "Yükle yerel kelimeleri gönderir, İndir sunucudaki kelimeleri getirir, Birleştir en son düzenlenen kelimeyi korur.",
      syncConfiguredMissing: "Eşitlemeyi etkinleştirmek için Supabase URL'si ve public anon key ekleyin.",
      syncLoggedInAs: "Giriş yapıldı",
      syncLoggedOut: "Giriş yapılmadı",
      syncUploadDone: "Yükleme tamamlandı",
      syncDownloadDone: "İndirme tamamlandı",
      syncMergeDone: "Birleştirme tamamlandı",
      syncLatestWins: "Aynı kelime iki yerde varsa en son güncellenen kayıt kullanılır.",
      syncBusy: "Eşitleniyor...",
      syncNoWords: "Eşitlenecek kelime yok.",
      syncNeedsLogin: "Önce giriş yapın.",
      syncRemoteCount: "uzaktaki kelime",
      syncLocalCount: "yerel kelime",
      syncSetupTitle: "Supabase bağlantısı",
      supabaseUrl: "Supabase proje URL'si",
      supabaseAnonKey: "Public anon key",
      supabaseTable: "Tablo adı",
      saveSyncConfig: "Bağlantıyı kaydet",
      resetSyncConfig: "Bağlantıyı sıfırla",
      syncConfigSaved: "Bağlantı ayarları kaydedildi.",
      syncConfigHint: "Önce Supabase SQL'i çalıştırın, sonra proje URL'sini ve public anon key'i girin.",
      syncConfigReady: "Bağlantı ayarlandı",
      syncRedirectUrl: "Google girişi Redirect URL",
      syncTestConnection: "Bağlantıyı test et",
      syncConnectionOk: "Bağlantı doğrulandı.",
      syncConnectionFailed: "Bağlantı kontrolü başarısız"
    },
    fa: {
      appName: "DictionEvery",
      searchPlaceholder: "جست‌وجوی واژه...",
      menu: "منو",
      vocabulary: "واژه‌ها",
      test: "آزمون",
      settings: "تنظیمات",
      meaningLanguage: "زبان مقصد",
      meaningLanguages: "زبان‌های مقصد",
      sourceLanguage: "زبان مبدأ",
      chooseMeaningLanguages: "زبان‌های معنی",
      menuLanguage: "زبان",
      changeLanguage: "تغییر زبان",
      interfaceLanguage: "زبان رابط کاربری",
      theme: "حالت نمایش",
      system: "طبق تنظیمات سیستم",
      light: "روشن",
      dark: "تاریک",
      decks: "فهرست‌های واژه",
      words: "واژه",
      knownWords: "واژه‌های آشنا",
      emptyDecks: "هنوز فهرست واژه‌ای ندارید.",
      emptyWords: "هنوز واژه‌ای ذخیره نشده است.",
      emptyHomeTitle: "هنوز واژه‌ای ذخیره نشده است.",
      emptyHomeBody: "برای ذخیره نخستین واژه، در صفحه واژه‌ای را انتخاب کنید یا از جست‌وجوی بالا استفاده کنید.",
      emptyDeckTitle: "این فهرست خالی است.",
      searchToAddWords: "در متن واژه‌ای انتخاب کنید یا از جست‌وجوی بالا واژه اضافه کنید.",
      knownRatio: "نرخ آشنایی",
      reviewedWords: "واژه مرور شده",
      notEnoughWords: "هنوز واژه‌ای برای آزمون نیست.",
      dictionary: "واژه‌نامه",
      dictionarySources: "واژه‌نامه‌ها",
      meanings: "معانی",
      allSources: "همه",
      addVocabulary: "افزودن به واژه‌ها",
      chooseDeck: "انتخاب فهرست",
      newDeck: "+ فهرست تازه",
      newDeckPlaceholder: "نام فهرست",
      save: "ذخیره",
      saved: "ذخیره شد.",
      update: "به‌روزرسانی",
      delete: "حذف",
      cancel: "لغو",
      edit: "ویرایش",
      loading: "در حال یافتن معنی...",
      manualDefinition: "معنی پیدا نشد. معنی را دستی وارد کنید.",
      lookupFailed: "نتیجه واژه‌نامه دریافت نشد. معنی را دستی وارد کنید یا بعداً دوباره تلاش کنید.",
      examples: "نمونه‌ها",
      notes: "یادداشت‌ها",
      proficiency: "میزان تسلط",
      chooseTest: "شروع آزمون",
      cardTest: "کارت",
      spellingTest: "املای واژه",
      choiceTest: "انتخاب معنی",
      cardHint: "برای دیدن معنی، روی کارت بزنید.",
      memorized: "بلدم",
      notMemorized: "هنوز بلد نیستم",
      typeAnswer: "واژه را وارد کنید",
      listenAndType: "روی بلندگو بزنید و واژه را وارد کنید.",
      correct: "درست",
      incorrect: "نادرست",
      reviewMeaning: "معنی را مرور کنید",
      submit: "بررسی",
      skip: "رد کردن",
      next: "بعدی",
      finish: "پایان",
      result: "آزمون تمام شد",
      startTestHint: "ابتدا یک فهرست واژه انتخاب کنید، سپس آزمون را شروع کنید.",
      selectWord: "جست‌وجو در",
      noWord: "برای جست‌وجو یک واژه وارد کنید.",
      reset: "بازنشانی همه داده‌ها",
      resetConfirm: "همه فهرست‌ها و واژه‌های ذخیره‌شده حذف شوند؟",
      openPanel: "باز کردن پنل",
      closePanel: "بستن پنل",
      back: "بازگشت",
      searchAction: "جست‌وجو در واژه‌نامه",
      settingsGeneral: "تنظیمات اصلی",
      settingsLookup: "جست‌وجو و یادگیری",
      settingsAi: "قابلیت‌های اختیاری",
      settingsData: "مدیریت داده‌ها",
      batchSize: "تعداد واژه‌ها در هر آزمون",
      dictionarySearchMode: "اولویت جست‌وجو",
      searchFast: "اولویت با سرعت",
      searchPrecise: "اولویت با کیفیت",
      dictionarySearchHint: "حالت سرعت سریع‌ترین نتیجه‌ها را اول نشان می‌دهد. حالت کیفیت چند منبع را دقیق‌تر مقایسه می‌کند.",
      aiOrganizer: "مرتب‌سازی واژه‌نامه با AI",
      aiOff: "خاموش",
      aiQualityOnly: "فقط در حالت اولویت کیفیت",
      aiAlways: "همیشه فعال",
      aiOrganizerHint: "AI معنی تازه نمی‌سازد؛ فقط ترتیب نتیجه‌ها و موارد تکراری را مرتب می‌کند.",
      aiProvider: "ارائه‌دهنده AI",
      aiApiKey: "کلید API",
      aiApiKeyPlaceholder: "کلید API را وارد کنید",
      aiKeepKey: "اگر خالی بماند، کلید ذخیره‌شده حفظ می‌شود",
      aiKeySaved: "کلید API ذخیره شده است",
      aiKeyNotSaved: "کلید API ذخیره نشده است.",
      aiModel: "مدل",
      aiAccountId: "شناسه حساب",
      aiAccountIdPlaceholder: "برای Cloudflare لازم است",
      aiAccountHint: "شناسه حساب فقط برای Cloudflare Workers AI لازم است.",
      aiTest: "آزمایش AI",
      aiTesting: "در حال آزمایش AI...",
      aiTestOk: "آزمایش مرتب‌سازی AI موفق بود",
      aiTestFailed: "آزمایش مرتب‌سازی AI ناموفق بود",
      aiSaving: "در حال ذخیره تنظیمات AI...",
      aiConfigSaved: "تنظیمات AI ذخیره شد.",
      aiConfigCleared: "تنظیمات AI بازنشانی شد.",
      aiConfigFailed: "تنظیمات AI ذخیره نشد.",
      integratedTest: "آزمون یکپارچه",
      testIntro: "برای هر واژه دو حالت تصادفی از کارت، انتخاب معنی و املا انتخاب می‌شود.",
      savedMeaning: "معنی ذخیره‌شده",
      term: "واژه",
      sourceExamples: "نمونه‌ها",
      learned: "یادگرفته",
      listen: "پخش",
      share: "اشتراک‌گذاری",
      exportVocabulary: "خروجی واژه‌ها",
      exportSubtitle: "این فهرست واژه را به یک پلتفرم یادگیری دیگر منتقل کنید.",
      ankiExport: "دانلود TSV برای Anki",
      quizletExport: "کپی برای Quizlet",
      lingqExport: "دانلود CSV برای LingQ",
      exportReady: "خروجی آماده است",
      exportCopied: "کپی شد.",
      exportDownloaded: "فایل دانلود شد.",
      exportEmpty: "واژه‌ای برای خروجی گرفتن نیست.",
      ankiGuideTitle: "وارد کردن به Anki",
      quizletGuideTitle: "وارد کردن به Quizlet",
      lingqGuideTitle: "وارد کردن به LingQ",
      ankiGuide1: "Anki Desktop را باز کنید و Import File را انتخاب کنید.",
      ankiGuide2: "فایل TSV دانلودشده را انتخاب کنید و فیلدها را به Front و Back وصل کنید.",
      ankiGuide3: "برای موبایل از همگام‌سازی AnkiWeb استفاده کنید.",
      quizletGuide1: "در Quizlet ساختن مجموعه تازه را باز کنید.",
      quizletGuide2: "Import را بزنید و متن کپی‌شده را جای‌گذاری کنید.",
      quizletGuide3: "Tab را جداکننده واژه و خط جدید را جداکننده کارت انتخاب کنید.",
      lingqGuide1: "صفحه Vocabulary Import را در LingQ باز کنید.",
      lingqGuide2: "فایل CSV دانلودشده را بارگذاری کنید.",
      lingqGuide3: "پیش از وارد کردن، term، phrase، meaninglanguage1 و meaning1 را بررسی کنید.",
      openQuizlet: "باز کردن Quizlet",
      openLingq: "باز کردن LingQ",
      sync: "همگام‌سازی",
      syncTitle: "همگام‌سازی حساب",
      syncSubtitle: "واژه‌ها را به‌صورت دستی بین دستگاه‌ها جابه‌جا کنید.",
      email: "ایمیل",
      password: "رمز عبور",
      signIn: "ورود",
      signUp: "ساخت حساب",
      googleSignIn: "ورود با Google",
      signOut: "خروج",
      syncUpload: "بارگذاری",
      syncDownload: "دریافت",
      syncMerge: "ادغام",
      syncManualHint: "بارگذاری واژه‌های محلی را می‌فرستد، دریافت واژه‌های سرور را می‌آورد، و ادغام نسخه تازه‌تر را نگه می‌دارد.",
      syncConfiguredMissing: "برای فعال شدن همگام‌سازی، URL Supabase و anon key عمومی را وارد کنید.",
      syncLoggedInAs: "وارد شده",
      syncLoggedOut: "وارد نشده‌اید",
      syncUploadDone: "بارگذاری کامل شد",
      syncDownloadDone: "دریافت کامل شد",
      syncMergeDone: "ادغام کامل شد",
      syncLatestWins: "اگر واژه تکراری باشد، نسخه‌ای که تازه‌تر ویرایش شده نگه داشته می‌شود.",
      syncBusy: "در حال همگام‌سازی...",
      syncNoWords: "واژه‌ای برای همگام‌سازی نیست.",
      syncNeedsLogin: "ابتدا وارد شوید.",
      syncRemoteCount: "واژه از سرور",
      syncLocalCount: "واژه محلی",
      syncSetupTitle: "اتصال Supabase",
      supabaseUrl: "URL پروژه Supabase",
      supabaseAnonKey: "Public anon key",
      supabaseTable: "نام جدول",
      saveSyncConfig: "ذخیره اتصال",
      resetSyncConfig: "بازنشانی اتصال",
      syncConfigSaved: "تنظیمات اتصال ذخیره شد.",
      syncConfigHint: "ابتدا SQL مربوط به Supabase را اجرا کنید، سپس URL پروژه و public anon key را وارد کنید.",
      syncConfigReady: "اتصال تنظیم شده است",
      syncRedirectUrl: "Redirect URL برای ورود Google",
      syncTestConnection: "آزمون اتصال",
      syncConnectionOk: "اتصال تأیید شد.",
      syncConnectionFailed: "بررسی اتصال ناموفق بود"
    }
  };

  const ICONS = {
    book: '<svg class="de-logo-svg" viewBox="8 4 24 34" aria-hidden="true"><path d="M12 14.3105L26.9594 6C27.191 7.50762 26.5424 11.0367 22.0948 13.092C17.6472 15.1473 14.1551 14.6548 12 14.3105L12 22.4748L12 31.7359L26.9594 37L26.9594 18.1124L12 14.3105ZM12 22.4748L21.4189 25.3019"/></svg>',
    menu: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></svg>',
    search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>',
    home: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3.5 10.5 8.5-7 8.5 7"/><path d="M5.5 9.5V20h13V9.5"/><path d="M9.5 20v-6h5v6"/></svg>',
    plus: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.2 4.2L19 7"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12"/><path d="m18 6-12 12"/></svg>',
    back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg>',
    trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M9 7V5h6v2"/><path d="M7 7l1 13h8l1-13"/></svg>',
    cards: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="4" width="12" height="16" rx="2"/><path d="M9 8h4"/><path d="M9 12h6"/><path d="M18 7l1 11"/></svg>',
    keyboard: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="6" width="17" height="12" rx="2"/><path d="M7 10h.01"/><path d="M10 10h.01"/><path d="M13 10h.01"/><path d="M16 10h.01"/><path d="M7 14h10"/></svg>',
    list: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h12"/><path d="M8 12h12"/><path d="M8 18h12"/><path d="M4 6h.01"/><path d="M4 12h.01"/><path d="M4 18h.01"/></svg>',
    settings: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.4 1a7 7 0 0 0-2.1-1.2L14 3h-4l-.4 2.7a7 7 0 0 0-2.1 1.2l-2.4-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.4-1c.6.5 1.3.9 2.1 1.2L10 21h4l.4-2.7c.8-.3 1.5-.7 2.1-1.2l2.4 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2Z"/></svg>',
    speaker: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10v4h4l5 4V6l-5 4H4Z"/><path d="M16 9.5a4 4 0 0 1 0 5"/><path d="M18.5 7a7 7 0 0 1 0 10"/></svg>',
    sync: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 2.5a7.2 7.2 0 0 1 4 6.4A7.1 7.1 0 0 1 9.6 14.6"/><path d="M15.8 7.6H21V2.4"/><path d="M7 21.5a7.2 7.2 0 0 1-4-6.4A7.1 7.1 0 0 1 14.4 9.4"/><path d="M8.2 16.4H3v5.2"/></svg>'
  };

  const FLAG_SVGS = {
    ko: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#f2f2f2"/><g fill="#20242a"><g transform="translate(18 18) rotate(-33)"><rect x="-7" y="-5.6" width="14" height="1.8" rx=".4"/><rect x="-7" y="-.9" width="14" height="1.8" rx=".4"/><rect x="-7" y="3.8" width="14" height="1.8" rx=".4"/></g><g transform="translate(46 18) rotate(33)"><rect x="-7" y="-5.6" width="14" height="1.8" rx=".4"/><rect x="-7" y="3.8" width="14" height="1.8" rx=".4"/><rect x="-7" y="-.9" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="-.9" width="5.6" height="1.8" rx=".4"/></g><g transform="translate(18 46) rotate(33)"><rect x="-7" y="-.9" width="14" height="1.8" rx=".4"/><rect x="-7" y="-5.6" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="-5.6" width="5.6" height="1.8" rx=".4"/><rect x="-7" y="3.8" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="3.8" width="5.6" height="1.8" rx=".4"/></g><g transform="translate(46 46) rotate(-33)"><rect x="-7" y="-5.6" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="-5.6" width="5.6" height="1.8" rx=".4"/><rect x="-7" y="-.9" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="-.9" width="5.6" height="1.8" rx=".4"/><rect x="-7" y="3.8" width="5.6" height="1.8" rx=".4"/><rect x="1.4" y="3.8" width="5.6" height="1.8" rx=".4"/></g></g><g transform="translate(32 32) rotate(-33)"><path fill="#d63f47" d="M0-11a11 11 0 0 1 0 22 5.5 5.5 0 0 0 0-11 5.5 5.5 0 0 1 0-11z"/><path fill="#285fb7" d="M0 11a11 11 0 0 1 0-22 5.5 5.5 0 0 0 0 11 5.5 5.5 0 0 1 0 11z"/></g></svg>',
    en: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" fill="#f2f2f2"/><g fill="#d90034"><rect y="0" width="64" height="5"/><rect y="10" width="64" height="5"/><rect y="20" width="64" height="5"/><rect y="30" width="64" height="5"/><rect y="40" width="64" height="5"/><rect y="50" width="64" height="5"/><rect y="60" width="64" height="5"/></g><rect width="33" height="35" fill="#2759a5"/><g fill="#f2f2f2"><circle cx="5" cy="5" r="1.15"/><circle cx="12" cy="5" r="1.15"/><circle cx="19" cy="5" r="1.15"/><circle cx="26" cy="5" r="1.15"/><circle cx="8.5" cy="10" r="1.15"/><circle cx="15.5" cy="10" r="1.15"/><circle cx="22.5" cy="10" r="1.15"/><circle cx="29.5" cy="10" r="1.15"/><circle cx="5" cy="15" r="1.15"/><circle cx="12" cy="15" r="1.15"/><circle cx="19" cy="15" r="1.15"/><circle cx="26" cy="15" r="1.15"/><circle cx="8.5" cy="20" r="1.15"/><circle cx="15.5" cy="20" r="1.15"/><circle cx="22.5" cy="20" r="1.15"/><circle cx="29.5" cy="20" r="1.15"/><circle cx="5" cy="25" r="1.15"/><circle cx="12" cy="25" r="1.15"/><circle cx="19" cy="25" r="1.15"/><circle cx="26" cy="25" r="1.15"/><circle cx="8.5" cy="30" r="1.15"/><circle cx="15.5" cy="30" r="1.15"/><circle cx="22.5" cy="30" r="1.15"/><circle cx="29.5" cy="30" r="1.15"/></g></svg>',
    ja: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#f2f2f2"/><circle cx="32" cy="32" r="13" fill="#d90034"/></svg>',
    "zh-CN": '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#dd001f"/><g fill="#ffda44"><path d="M18 13.5l2.4 7.3h7.7l-6.2 4.5 2.4 7.3-6.3-4.5-6.2 4.5 2.4-7.3-6.2-4.5h7.7z"/><path d="M37 10l.9 2.8h2.9l-2.3 1.7.9 2.8-2.4-1.7-2.3 1.7.9-2.8-2.3-1.7h2.9z"/><path d="M45 19l.9 2.8h2.9l-2.3 1.7.9 2.8-2.4-1.7-2.3 1.7.9-2.8-2.3-1.7h2.9z"/><path d="M45 31l.9 2.8h2.9l-2.3 1.7.9 2.8-2.4-1.7-2.3 1.7.9-2.8-2.3-1.7h2.9z"/><path d="M37 40l.9 2.8h2.9l-2.3 1.7.9 2.8-2.4-1.7-2.3 1.7.9-2.8-2.3-1.7h2.9z"/></g></svg>',
    ru: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#f2f2f2"/><rect y="21.33" width="64" height="21.34" fill="#1554b7"/><rect y="42.66" width="64" height="21.34" fill="#d90034"/></svg>',
    tr: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#e00022"/><circle cx="27" cy="32" r="14" fill="#f2f2f2"/><circle cx="33" cy="32" r="11.5" fill="#e00022"/><path fill="#f2f2f2" d="M45.5 22.5l2.3 7.1h7.5l-6.1 4.4 2.3 7.1-6-4.4-6.1 4.4 2.3-7.1-6-4.4h7.5z"/></svg>',
    fa: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="32" fill="#f2f2f2"/><rect width="64" height="21.34" fill="#239f40"/><rect y="42.66" width="64" height="21.34" fill="#da0000"/><g fill="#f2f2f2" opacity=".7"><rect x="4" y="19.4" width="4" height="1.7"/><rect x="12" y="19.4" width="4" height="1.7"/><rect x="20" y="19.4" width="4" height="1.7"/><rect x="28" y="19.4" width="4" height="1.7"/><rect x="36" y="19.4" width="4" height="1.7"/><rect x="44" y="19.4" width="4" height="1.7"/><rect x="52" y="19.4" width="4" height="1.7"/><rect x="4" y="42.9" width="4" height="1.7"/><rect x="12" y="42.9" width="4" height="1.7"/><rect x="20" y="42.9" width="4" height="1.7"/><rect x="28" y="42.9" width="4" height="1.7"/><rect x="36" y="42.9" width="4" height="1.7"/><rect x="44" y="42.9" width="4" height="1.7"/><rect x="52" y="42.9" width="4" height="1.7"/></g><g fill="#da0000"><path d="M32 19c-3.3 4-6.5 6.5-6.5 11.2 0 5.7 4.4 10 6.5 14.2 2.1-4.2 6.5-8.5 6.5-14.2C38.5 25.5 35.3 23 32 19z"/><rect x="30.5" y="25" width="3" height="19" rx="1.5"/><path d="M20 32c4-8.2 9.5-8.4 12-14-1.3 9.3-5.1 13.8-12 14z"/><path d="M44 32c-4-8.2-9.5-8.4-12-14 1.3 9.3 5.1 13.8 12 14z"/><circle cx="32" cy="19" r="1.8"/></g></svg>'
  };

  const FLAG_PNGS = {
    ko: "assets/flags/ko.png",
    fa: "assets/flags/fa.png"
  };

  const DEFAULT_STATE = {
    version: 6,
    uiLang: "ko",
    sourceLang: "en",
    targetLang: "en",
    targetLangs: ["ko"],
    currentMeaningLang: "ko",
    theme: "system",
    dictionarySearchMode: "fast",
    testBatchSize: 10,
    currentDictLang: "en",
    decks: [{ id: "deck_default_en", name: "Vocabulary", lang: "en" }],
    vocab: [],
    recent: [],
    layout: {}
  };

  const runtime = {
    selectedWord: "",
    activeView: "home",
    currentDeckId: null,
    lookup: null,
    lookupToken: 0,
    test: null,
    editingWordId: null,
    languageMenuOpen: false,
    meaningLanguageMenuOpen: false,
    menuOpen: false,
    panelOpen: false,
    previousView: "home",
    resizing: null,
    dragging: null,
    suppressNextClick: false,
    exportGuide: null,
    sync: {
      configured: false,
      config: null,
      redirectUrl: "",
      session: null,
      busy: false,
      status: ""
    },
    ai: {
      config: {
        mode: "off",
        provider: "gemini",
        model: "gemini-2.5-flash-lite",
        accountId: "",
        hasApiKey: false,
        apiKeyPreview: ""
      },
      busy: false,
      status: ""
    }
  };

  let state = clone(DEFAULT_STATE);

  const host = document.createElement("div");
  host.id = HOST_ID;
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });

  shadow.innerHTML = `
    <style>
      :host {
        --de-primary: #40556b;
        --de-primary-strong: #314456;
        --de-primary-soft: #e8edf2;
        --de-bg: #f4f5f6;
        --de-panel: #ffffff;
        --de-text: #202329;
        --de-muted: #69727d;
        --de-border: #d8dde3;
        --de-line: #e9edf1;
        --de-danger: #c44d4d;
        --de-good: #4f7f64;
        --de-shadow: 0 16px 45px rgba(20, 27, 34, 0.22);
        color-scheme: light;
      }

      :host(.de-dark) {
        --de-primary: #4d6580;
        --de-primary-strong: #2e3e50;
        --de-primary-soft: #232d37;
        --de-bg: #151a20;
        --de-panel: #1d232a;
        --de-text: #edf1f5;
        --de-muted: #a7b0ba;
        --de-border: #33404c;
        --de-line: #2a333d;
        --de-danger: #dc6c6c;
        --de-good: #7fb58c;
        --de-shadow: 0 16px 45px rgba(0, 0, 0, 0.42);
        color-scheme: dark;
      }

      * {
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        letter-spacing: 0;
      }

      svg {
        display: block;
        width: 20px;
        height: 20px;
        fill: none;
        stroke: currentColor;
        stroke-linecap: round;
        stroke-linejoin: round;
        stroke-width: 1.8;
      }

      .de-logo-svg {
        width: 100%;
        height: 100%;
        fill: initial;
        stroke: initial;
      }

      .de-logo-svg path {
        fill: none;
        stroke: currentColor;
        stroke-width: 2.35;
        stroke-linecap: round;
        stroke-linejoin: round;
      }

      button,
      input,
      select,
      textarea {
        font: inherit;
      }

      button {
        cursor: pointer;
      }

      [dir="auto"] {
        unicode-bidi: plaintext;
      }

      .de-fab {
        position: fixed;
        right: max(22px, env(safe-area-inset-right));
        bottom: max(22px, env(safe-area-inset-bottom));
        z-index: 2147483644;
        width: 58px;
        height: 58px;
        border: 0;
        border-radius: 50%;
        background: var(--de-primary);
        color: #fff;
        display: grid;
        place-items: center;
        box-shadow: 0 9px 24px rgba(20, 27, 34, 0.24);
        touch-action: none;
        user-select: none;
      }

      .de-fab.is-positioned {
        right: auto;
        bottom: auto;
      }

      .de-fab.is-dragging {
        cursor: grabbing;
      }

      .de-fab svg {
        width: 38px;
        height: 38px;
      }

      .de-fab:hover {
        background: var(--de-primary-strong);
      }

      .de-fab.is-hidden {
        display: none;
      }

      .de-tooltip {
        position: fixed;
        left: 24px;
        top: 24px;
        z-index: 2147483645;
        width: max-content;
        max-width: calc(100vw - 24px);
        min-width: 0;
        min-height: 40px;
        border: 1px solid var(--de-border);
        border-radius: 20px;
        background: color-mix(in srgb, var(--de-panel) 92%, transparent);
        color: var(--de-text);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
        backdrop-filter: blur(14px);
        align-items: center;
        gap: 8px;
        padding: 6px 10px;
        display: none;
        font-size: 14px;
        font-weight: 700;
        white-space: nowrap;
      }

      .de-tooltip.is-visible {
        display: inline-flex;
      }

      :host(.de-dark) .de-tooltip {
        border-color: color-mix(in srgb, var(--de-border) 78%, var(--de-text));
        background: color-mix(in srgb, var(--de-panel) 96%, var(--de-primary-soft));
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.42);
      }

      #de-tooltip-content {
        display: inline-flex;
        min-width: 0;
        align-items: center;
        gap: 8px;
        white-space: nowrap;
      }

      #de-tooltip-content > span:not(.de-tooltip-mark) {
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .de-tooltip-mark {
        width: 28px;
        height: 28px;
        flex: 0 0 28px;
        border-radius: 50%;
        background: var(--de-primary);
        color: #fff;
        display: grid;
        place-items: center;
      }

      .de-tooltip-mark svg {
        width: 22px;
        height: 22px;
      }

      .de-panel {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 2147483646;
        width: min(390px, calc(100vw - 28px));
        height: min(650px, calc(100vh - 28px));
        min-width: min(195px, calc(100vw - 28px));
        min-height: min(325px, calc(100vh - 28px));
        max-width: min(780px, calc(100vw - 28px));
        max-height: min(1300px, calc(100vh - 28px));
        border: 0;
        border-radius: 18px;
        background: var(--de-panel);
        color: var(--de-text);
        overflow: hidden;
        resize: none;
        display: none;
        flex-direction: column;
        box-shadow: var(--de-shadow), inset 0 0 0 1px var(--de-border);
      }

      .de-panel.is-sized {
        right: auto;
        bottom: auto;
      }

      .de-panel.is-dragging {
        cursor: grabbing;
      }

      :host(.de-rtl) .de-panel {
        font-family: "Vazirmatn", "Noto Sans Arabic", "Noto Sans", "Segoe UI", Tahoma, Arial, sans-serif;
      }

      :host(.de-rtl) .de-top,
      :host(.de-rtl) .de-menu,
      :host(.de-rtl) .de-main,
      :host(.de-rtl) .de-bottom,
      :host(.de-rtl) .de-modal,
      :host(.de-rtl) .de-tooltip {
        direction: rtl;
      }

      :host(.de-rtl) .de-panel *,
      :host(.de-rtl) .de-tooltip,
      :host(.de-rtl) .de-fab {
        font-family: "Vazirmatn", "Noto Sans Arabic", "Noto Sans", "Segoe UI", Tahoma, Arial, sans-serif;
      }

      :host(.de-rtl) .de-title,
      :host(.de-rtl) .de-sub,
      :host(.de-rtl) .de-label,
      :host(.de-rtl) .de-card,
      :host(.de-rtl) .de-language-card,
      :host(.de-rtl) .de-language-option,
      :host(.de-rtl) .de-suggestion,
      :host(.de-rtl) .de-dict-status,
      :host(.de-rtl) .de-examples,
      :host(.de-rtl) .de-sync-status,
      :host(.de-rtl) .de-info-note {
        text-align: right;
      }

      :host(.de-rtl) .de-search button {
        left: 5px;
        right: auto;
      }

      :host(.de-rtl) .de-search input {
        padding-left: 46px;
        padding-right: 16px;
        text-align: right;
      }

      :host(.de-rtl) .de-input,
      :host(.de-rtl) .de-textarea,
      :host(.de-rtl) .de-select {
        text-align: right;
      }

      :host(.de-rtl) .de-input[dir="auto"],
      :host(.de-rtl) .de-textarea[dir="auto"] {
        unicode-bidi: plaintext;
        text-align: start;
      }

      :host(.de-rtl) #de-bottom-left:not(.is-close) svg {
        transform: scaleX(-1);
      }

      .de-panel.is-open {
        display: flex;
      }

      .de-resize-handle {
        position: absolute;
        z-index: 50;
        background: transparent;
        touch-action: none;
      }

      .de-resize-n,
      .de-resize-s {
        left: 18px;
        right: 18px;
        height: 10px;
        cursor: ns-resize;
      }

      .de-resize-n {
        top: 0;
      }

      .de-resize-s {
        bottom: 0;
      }

      .de-resize-e,
      .de-resize-w {
        top: 18px;
        bottom: 18px;
        width: 10px;
        cursor: ew-resize;
      }

      .de-resize-e {
        right: 0;
      }

      .de-resize-w {
        left: 0;
      }

      .de-resize-ne,
      .de-resize-nw,
      .de-resize-se,
      .de-resize-sw {
        width: 18px;
        height: 18px;
      }

      .de-resize-ne,
      .de-resize-sw {
        cursor: nesw-resize;
      }

      .de-resize-nw,
      .de-resize-se {
        cursor: nwse-resize;
      }

      .de-resize-ne {
        top: 0;
        right: 0;
      }

      .de-resize-nw {
        top: 0;
        left: 0;
      }

      .de-resize-se {
        right: 0;
        bottom: 0;
      }

      .de-resize-sw {
        left: 0;
        bottom: 0;
      }

      .de-resize-se::after {
        content: "";
        position: absolute;
        right: 5px;
        bottom: 5px;
        width: 7px;
        height: 7px;
        border-right: 1.5px solid color-mix(in srgb, var(--de-muted) 70%, transparent);
        border-bottom: 1.5px solid color-mix(in srgb, var(--de-muted) 70%, transparent);
        opacity: 0.7;
      }

      .de-top {
        background: var(--de-primary);
        color: #fff;
        padding: 14px 18px 18px;
        border-radius: 18px 18px 0 0;
        flex: 0 0 auto;
        margin: 0;
        box-shadow: 0 8px 18px rgba(35, 79, 74, 0.16);
        cursor: grab;
        user-select: none;
        touch-action: none;
      }

      .de-panel.is-dragging .de-top {
        cursor: grabbing;
      }

      .de-top input,
      .de-top button {
        user-select: auto;
        touch-action: auto;
      }

      .de-header {
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
      }

      .de-brand {
        display: flex;
        align-items: center;
        gap: 9px;
        border: 0;
        color: inherit;
        background: transparent;
        padding: 4px 0;
        font-weight: 700;
        font-size: 15px;
      }

      .de-brand svg {
        width: 34px;
        height: 34px;
      }

      .de-icon-button {
        width: 38px;
        height: 38px;
        border: 0;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.12);
        color: currentColor;
        display: grid;
        place-items: center;
      }

      .de-icon-button:hover {
        background: rgba(255, 255, 255, 0.2);
      }

      .de-search {
        position: relative;
      }

      .de-search input {
        width: 100%;
        height: 42px;
        border: 0;
        outline: 0;
        border-radius: 21px;
        background: rgba(255, 255, 255, 0.94);
        color: #1c2127;
        padding: 0 46px 0 16px;
        font-size: 14px;
      }

      :host(.de-dark) .de-search input {
        border: 1px solid rgba(255, 255, 255, 0.14);
        background: rgba(21, 26, 32, 0.78);
        color: var(--de-text);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
      }

      :host(.de-dark) .de-search input::placeholder {
        color: color-mix(in srgb, var(--de-muted) 78%, transparent);
      }

      .de-search button {
        position: absolute;
        right: 5px;
        top: 5px;
        width: 32px;
        height: 32px;
        border: 0;
        border-radius: 50%;
        background: transparent;
        color: #59636e;
        display: grid;
        place-items: center;
      }

      :host(.de-dark) .de-search button {
        color: var(--de-muted);
      }

      :host(.de-dark) .de-search button:hover {
        background: rgba(255, 255, 255, 0.07);
        color: var(--de-text);
      }

      .de-suggestions {
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        right: 0;
        z-index: 5;
        max-height: 180px;
        display: none;
        overflow: auto;
        border: 1px solid var(--de-border);
        border-radius: 10px;
        background: var(--de-panel);
        color: var(--de-text);
        box-shadow: 0 10px 26px rgba(0, 0, 0, 0.15);
      }

      .de-suggestions.is-visible {
        display: block;
      }

      .de-suggestion {
        width: 100%;
        border: 0;
        border-bottom: 1px solid var(--de-line);
        background: transparent;
        color: inherit;
        text-align: left;
        padding: 10px 13px;
      }

      .de-suggestion:hover {
        background: var(--de-primary-soft);
      }

      .de-suggestion-word {
        display: block;
        font-size: 14px;
        font-weight: 700;
      }

      .de-suggestion-def {
        display: block;
        margin-top: 3px;
        color: var(--de-muted);
        font-size: 12px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .de-menu {
        position: absolute;
        inset: 8px 8px 8px auto;
        z-index: 20;
        width: min(304px, 88%);
        display: none;
        flex-direction: column;
        border: 1px solid var(--de-border);
        border-radius: 18px;
        overflow: hidden;
        background: color-mix(in srgb, var(--de-primary-soft) 78%, var(--de-panel));
        color: var(--de-text);
        box-shadow: -10px 10px 30px rgba(25, 41, 39, 0.18);
      }

      .de-menu.is-open {
        display: flex;
      }

      .de-menu-head {
        height: 92px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 22px;
        border-bottom: 1px solid color-mix(in srgb, var(--de-primary-strong) 55%, transparent);
        background: var(--de-primary);
        color: #fff;
        font-size: 22px;
        font-weight: 700;
      }

      .de-menu-body {
        padding: 6px 0 8px;
        flex: 0 0 auto;
      }

      .de-menu-item {
        width: 100%;
        flex: 0 0 50px;
        min-height: 50px;
        border: 0;
        border-bottom: 1px solid var(--de-border);
        background: transparent;
        color: inherit;
        display: grid;
        grid-template-columns: 28px minmax(0, 1fr);
        align-items: center;
        justify-content: start;
        gap: 12px;
        padding: 0 24px;
        font-size: 15px;
        font-weight: 600;
        text-align: left;
        transition: background 120ms ease;
      }

      .de-menu-item svg {
        width: 23px;
        height: 23px;
        justify-self: center;
      }

      .de-menu-item span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      :host(.de-rtl) .de-menu-item {
        text-align: right;
      }

      .de-menu-item:hover {
        background: color-mix(in srgb, var(--de-primary-soft) 70%, var(--de-panel));
      }

      .de-menu-field {
        position: relative;
        z-index: 2;
        padding: 16px 20px 20px;
        border-bottom: 1px solid var(--de-border);
        background: color-mix(in srgb, var(--de-primary-soft) 52%, var(--de-panel));
      }

      .de-language-card {
        width: 100%;
        border: 0;
        border-radius: 12px;
        background: var(--de-panel);
        color: var(--de-text);
        display: grid;
        grid-template-columns: 42px minmax(0, 1fr) auto;
        align-items: center;
        gap: 11px;
        padding: 12px;
        text-align: left;
      }

      .de-language-card strong {
        display: block;
        font-size: 16px;
        line-height: 1.1;
      }

      .de-language-card span {
        display: block;
        margin-top: 4px;
        color: var(--de-muted);
        font-size: 12px;
      }

      .de-language-options {
        display: none;
        margin-top: 10px;
        border: 1px solid var(--de-border);
        border-radius: 12px;
        overflow: hidden;
        background: var(--de-panel);
      }

      .de-language-options.is-open {
        display: block;
      }

      .de-menu-field .de-language-options {
        position: absolute;
        left: 20px;
        right: 20px;
        top: calc(100% - 10px);
        z-index: 4;
        max-height: 236px;
        margin-top: 0;
        overflow: auto;
        box-shadow: 0 14px 28px rgba(20, 27, 34, 0.2);
      }

      .de-settings-language {
        position: relative;
        z-index: 6;
      }

      .de-home-language {
        position: relative;
        z-index: 8;
        margin-bottom: 14px;
      }

      .de-home-language .de-language-options {
        max-height: 248px;
        overflow: auto;
        box-shadow: 0 14px 28px rgba(20, 27, 34, 0.2);
      }

      .de-settings-language .de-language-card {
        grid-template-columns: minmax(0, 1fr) auto;
      }

      .de-settings-language .de-language-options {
        position: absolute;
        left: 0;
        right: 0;
        top: calc(100% + 8px);
        z-index: 7;
        max-height: 248px;
        overflow: auto;
        box-shadow: 0 14px 28px rgba(20, 27, 34, 0.2);
      }

      .de-meaning-summary {
        display: inline-flex;
        min-width: 0;
        align-items: center;
        flex: 0 0 auto;
        gap: 0;
        margin-top: 0 !important;
        color: inherit !important;
      }

      .de-meaning-summary .de-flag {
        display: inline-block !important;
        width: 24px;
        height: 24px;
        margin-right: -7px;
        margin-top: 0 !important;
        box-shadow: 0 0 0 2px var(--de-panel);
      }

      .de-meaning-content {
        display: grid !important;
        min-width: 0;
        gap: 4px;
        margin-top: 0 !important;
      }

      .de-meaning-line {
        display: flex !important;
        min-width: 0;
        align-items: center;
        gap: 8px;
        margin-top: 0 !important;
        color: var(--de-text) !important;
      }

      .de-meaning-line strong {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .de-meaning-help {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .de-meaning-more {
        display: grid !important;
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        place-items: center;
        margin-left: 2px;
        margin-top: 0 !important;
        border-radius: 50%;
        background: var(--de-primary-soft);
        color: var(--de-muted) !important;
        font-size: 12px !important;
        font-weight: 800;
        line-height: 1;
      }

      :host(.de-rtl) .de-meaning-summary .de-flag {
        margin-right: 0;
        margin-left: -7px;
      }

      :host(.de-rtl) .de-meaning-more {
        margin-left: 0;
        margin-right: 2px;
      }

      .de-dict-language-bar {
        display: grid;
        gap: 7px;
      }

      .de-dict-language-tabs {
        display: flex;
        gap: 7px;
        overflow-x: auto;
        padding-bottom: 2px;
      }

      .de-dict-lang-tab {
        min-height: 36px;
        border: 1px solid var(--de-border);
        border-radius: 10px;
        background: var(--de-bg);
        color: var(--de-text);
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 0 11px;
        white-space: nowrap;
        font-size: 13px;
        font-weight: 720;
      }

      .de-dict-lang-tab.is-active {
        border-color: var(--de-primary);
        background: var(--de-primary-soft);
        color: var(--de-primary-strong);
      }

      :host(.de-dark) .de-dict-lang-tab.is-active {
        color: var(--de-text);
      }

      .de-language-option {
        width: 100%;
        border: 0;
        border-bottom: 1px solid var(--de-line);
        background: transparent;
        color: var(--de-text);
        display: grid;
        grid-template-columns: 30px minmax(0, 1fr) auto;
        align-items: center;
        gap: 9px;
        padding: 10px 12px;
        text-align: left;
      }

      .de-language-option:last-child {
        border-bottom: 0;
      }

      .de-language-option.is-active {
        background: var(--de-primary-soft);
        font-weight: 750;
      }

      .de-flag {
        position: relative;
        display: inline-block;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        flex: 0 0 auto;
        overflow: hidden;
        border: 0;
        box-shadow: none;
        background: transparent !important;
      }

      .de-flag-small {
        width: 22px;
        height: 22px;
      }

      .de-flag svg,
      .de-flag img {
        width: 100%;
        height: 100%;
        display: block;
      }

      .de-flag svg {
        fill: initial;
        stroke: initial;
      }

      .de-flag img {
        object-fit: contain;
      }

      .de-flag::before,
      .de-flag::after {
        content: none !important;
      }

      .de-flag-ko {
        background: #f7f7f7 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' fill='%23f7f7f7'/%3E%3Cg fill='%231f2329'%3E%3Cg transform='translate(18 18) rotate(-33)'%3E%3Crect x='-6.5' y='-5' width='13' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='-.8' width='13' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='3.4' width='13' height='1.6' rx='.45'/%3E%3C/g%3E%3Cg transform='translate(42 18) rotate(33)'%3E%3Crect x='-6.5' y='-5' width='13' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='-.8' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='-.8' width='5' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='3.4' width='13' height='1.6' rx='.45'/%3E%3C/g%3E%3Cg transform='translate(18 42) rotate(33)'%3E%3Crect x='-6.5' y='-5' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='-5' width='5' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='-.8' width='13' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='3.4' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='3.4' width='5' height='1.6' rx='.45'/%3E%3C/g%3E%3Cg transform='translate(42 42) rotate(-33)'%3E%3Crect x='-6.5' y='-5' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='-5' width='5' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='-.8' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='-.8' width='5' height='1.6' rx='.45'/%3E%3Crect x='-6.5' y='3.4' width='5' height='1.6' rx='.45'/%3E%3Crect x='1.5' y='3.4' width='5' height='1.6' rx='.45'/%3E%3C/g%3E%3C/g%3E%3Cg transform='translate(30 30) rotate(-33)'%3E%3Cpath fill='%23cd2e3a' d='M0-10a10 10 0 0 1 0 20 5 5 0 0 0 0-10 5 5 0 0 1 0-10z'/%3E%3Cpath fill='%230047a0' d='M0 10a10 10 0 0 1 0-20 5 5 0 0 0 0 10 5 5 0 0 1 0 10z'/%3E%3C/g%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-ko::before {
        content: none;
      }

      .de-flag-ko::after {
        content: none;
      }

      .de-flag-en {
        background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' fill='white'/%3E%3Cg fill='%23bf3f47'%3E%3Crect y='0' width='60' height='4.62'/%3E%3Crect y='9.23' width='60' height='4.62'/%3E%3Crect y='18.46' width='60' height='4.62'/%3E%3Crect y='27.69' width='60' height='4.62'/%3E%3Crect y='36.92' width='60' height='4.62'/%3E%3Crect y='46.15' width='60' height='4.62'/%3E%3Crect y='55.38' width='60' height='4.62'/%3E%3C/g%3E%3Crect width='28.8' height='32.3' fill='%232f4f8f'/%3E%3Cg fill='white'%3E%3Ccircle cx='4' cy='4' r='1.1'/%3E%3Ccircle cx='10' cy='4' r='1.1'/%3E%3Ccircle cx='16' cy='4' r='1.1'/%3E%3Ccircle cx='22' cy='4' r='1.1'/%3E%3Ccircle cx='7' cy='9' r='1.1'/%3E%3Ccircle cx='13' cy='9' r='1.1'/%3E%3Ccircle cx='19' cy='9' r='1.1'/%3E%3Ccircle cx='25' cy='9' r='1.1'/%3E%3Ccircle cx='4' cy='14' r='1.1'/%3E%3Ccircle cx='10' cy='14' r='1.1'/%3E%3Ccircle cx='16' cy='14' r='1.1'/%3E%3Ccircle cx='22' cy='14' r='1.1'/%3E%3Ccircle cx='7' cy='19' r='1.1'/%3E%3Ccircle cx='13' cy='19' r='1.1'/%3E%3Ccircle cx='19' cy='19' r='1.1'/%3E%3Ccircle cx='25' cy='19' r='1.1'/%3E%3Ccircle cx='4' cy='24' r='1.1'/%3E%3Ccircle cx='10' cy='24' r='1.1'/%3E%3Ccircle cx='16' cy='24' r='1.1'/%3E%3Ccircle cx='22' cy='24' r='1.1'/%3E%3Ccircle cx='7' cy='29' r='1.1'/%3E%3Ccircle cx='13' cy='29' r='1.1'/%3E%3Ccircle cx='19' cy='29' r='1.1'/%3E%3Ccircle cx='25' cy='29' r='1.1'/%3E%3C/g%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-en::before {
        content: none;
      }

      .de-flag-en::after {
        content: none;
      }

      .de-flag-ja {
        background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' fill='white'/%3E%3Ccircle cx='30' cy='30' r='12.5' fill='%23d64a4a'/%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-ja::before {
        content: none;
      }

      .de-flag-ja::after {
        content: none;
      }

      .de-flag-zh-CN {
        background: #d94132 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' fill='%23d94132'/%3E%3Cdefs%3E%3Cpath id='s' d='M0-1 .224-.309 .951-.309 .363 .118 .588 .809 0 .382 -.588 .809 -.363 .118 -.951-.309 -.224-.309Z'/%3E%3C/defs%3E%3Cg fill='%23f5d142'%3E%3Cuse href='%23s' transform='translate(14 20) scale(7.4)'/%3E%3Cuse href='%23s' transform='translate(28 13) rotate(23) scale(2.5)'/%3E%3Cuse href='%23s' transform='translate(34 18) rotate(46) scale(2.5)'/%3E%3Cuse href='%23s' transform='translate(34 25) rotate(69) scale(2.5)'/%3E%3Cuse href='%23s' transform='translate(28 31) rotate(92) scale(2.5)'/%3E%3C/g%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-zh-CN::before {
        content: none;
      }

      .de-flag-zh-CN::after {
        content: none;
      }

      .de-flag-ru {
        background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='20' fill='%23f7f7f7'/%3E%3Crect y='20' width='60' height='20' fill='%234f79c7'/%3E%3Crect y='40' width='60' height='20' fill='%23d64a4a'/%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-ru::before {
        content: none;
      }

      .de-flag-ru::after {
        content: none;
      }

      .de-flag-tr {
        background: #d8433e url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' fill='%23d8433e'/%3E%3Ccircle cx='25' cy='30' r='12' fill='white'/%3E%3Ccircle cx='30' cy='30' r='10' fill='%23d8433e'/%3E%3Cpath fill='white' d='M42 23.2l1.7 5.1h5.4l-4.4 3.2 1.7 5.2-4.4-3.2-4.4 3.2 1.7-5.2-4.4-3.2h5.4z'/%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-tr::before {
        content: none;
      }

      .de-flag-tr::after {
        content: none;
      }

      .de-flag-fa {
        background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='20' fill='%23239f40'/%3E%3Crect y='20' width='60' height='20' fill='white'/%3E%3Crect y='40' width='60' height='20' fill='%23da0000'/%3E%3Cg fill='white' opacity='.62'%3E%3Crect x='4' y='18' width='4' height='2'/%3E%3Crect x='12' y='18' width='4' height='2'/%3E%3Crect x='20' y='18' width='4' height='2'/%3E%3Crect x='28' y='18' width='4' height='2'/%3E%3Crect x='36' y='18' width='4' height='2'/%3E%3Crect x='44' y='18' width='4' height='2'/%3E%3Crect x='52' y='18' width='4' height='2'/%3E%3Crect x='4' y='40' width='4' height='2'/%3E%3Crect x='12' y='40' width='4' height='2'/%3E%3Crect x='20' y='40' width='4' height='2'/%3E%3Crect x='28' y='40' width='4' height='2'/%3E%3Crect x='36' y='40' width='4' height='2'/%3E%3Crect x='44' y='40' width='4' height='2'/%3E%3Crect x='52' y='40' width='4' height='2'/%3E%3C/g%3E%3Cg fill='%23da0000'%3E%3Cpath d='M30 18c-2.7 3.2-5.6 5.2-5.6 9.3 0 4.8 3.7 8.5 5.6 12.1 1.9-3.6 5.6-7.3 5.6-12.1 0-4.1-2.9-6.1-5.6-9.3z'/%3E%3Crect x='28.7' y='23' width='2.6' height='17' rx='1.3'/%3E%3Cpath d='M20.5 30c3.4-7 8.1-7.2 9.5-12-1 7.7-4 11.8-9.5 12z'/%3E%3Cpath d='M39.5 30c-3.4-7-8.1-7.2-9.5-12 1 7.7 4 11.8 9.5 12z'/%3E%3Ccircle cx='30' cy='18' r='1.7'/%3E%3C/g%3E%3C/svg%3E") center / cover no-repeat;
      }

      .de-flag-fa::before {
        content: none;
      }

      .de-flag-fa::after {
        content: none;
      }

      .de-label {
        display: block;
        margin-bottom: 5px;
        color: var(--de-muted);
        font-size: 12px;
        font-weight: 700;
      }

      .de-setting-note {
        display: block;
        margin-top: 5px;
        color: var(--de-muted);
        font-size: 11px;
        line-height: 1.35;
      }

      .de-select,
      .de-input,
      .de-textarea {
        width: 100%;
        border: 1px solid var(--de-border);
        border-radius: 10px;
        background: var(--de-panel);
        color: var(--de-text);
        outline: 0;
      }

      .de-select,
      .de-input {
        min-height: 42px;
        padding: 0 11px;
      }

      .de-textarea {
        min-height: 176px;
        resize: none;
        padding: 13px;
        line-height: 1.55;
      }

      .de-main {
        flex: 1;
        min-height: 0;
        position: relative;
        background: var(--de-panel);
      }

      .de-view {
        display: none;
        height: 100%;
        overflow: auto;
        padding: 20px;
      }

      .de-view.is-active {
        display: block;
      }

      .de-view.de-test-view {
        background: color-mix(in srgb, var(--de-primary-soft) 62%, var(--de-panel));
        color: var(--de-text);
      }

      :host(.de-dark) .de-view.de-test-view {
        background: #18211f;
        color: var(--de-text);
      }

      .de-title-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 16px;
      }

      .de-title {
        margin: 0;
        font-size: 22px;
        font-weight: 750;
        line-height: 1.25;
      }

      .de-title-actions {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 8px;
        flex-wrap: wrap;
      }

      .de-sub {
        color: var(--de-muted);
        font-size: 13px;
        line-height: 1.45;
      }

      .de-grid {
        display: grid;
        gap: 10px;
      }

      .de-settings-stack {
        display: grid;
        gap: 16px;
      }

      .de-settings-section {
        display: grid;
        gap: 10px;
        padding-top: 14px;
        border-top: 1px solid var(--de-line);
      }

      .de-settings-section:first-child {
        padding-top: 0;
        border-top: 0;
      }

      .de-settings-section-title {
        margin: 0;
        color: var(--de-text);
        font-size: 13px;
        font-weight: 800;
        line-height: 1.25;
      }

      .de-settings-fields {
        display: grid;
        gap: 10px;
      }

      .de-settings-priority {
        display: grid;
        gap: 10px;
      }

      .de-settings-secondary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(132px, 1fr));
        gap: 10px;
      }

      .de-settings-pair {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(132px, 1fr));
        gap: 10px;
      }

      .de-settings-actions {
        justify-content: flex-start;
        margin-top: 2px;
      }

      .de-hidden-setting {
        display: none;
      }

      .de-card {
        width: 100%;
        border: 1px solid var(--de-border);
        border-radius: 10px;
        background: var(--de-bg);
        color: var(--de-text);
        padding: 14px;
        text-align: left;
      }

      .de-card:hover {
        border-color: var(--de-primary);
        box-shadow: 0 8px 22px rgba(25, 41, 39, 0.08);
      }

      .de-card,
      .de-language-card,
      .de-primary-button,
      .de-secondary-button,
      .de-danger-button,
      .de-select,
      .de-input,
      .de-textarea,
      .de-bottom button {
        transition: border-color 120ms ease, background 120ms ease, box-shadow 120ms ease, transform 120ms ease;
      }

      .de-card:focus-visible,
      .de-language-card:focus-visible,
      .de-primary-button:focus-visible,
      .de-secondary-button:focus-visible,
      .de-danger-button:focus-visible,
      .de-icon-button:focus-visible,
      .de-round-button:focus-visible,
      .de-speak-button:focus-visible,
      .de-input:focus-visible,
      .de-select:focus-visible,
      .de-textarea:focus-visible {
        outline: 2px solid color-mix(in srgb, var(--de-primary) 72%, #fff);
        outline-offset: 2px;
      }

      .de-card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
      }

      .de-card-title {
        min-width: 0;
        overflow-wrap: anywhere;
        font-size: 16px;
        font-weight: 750;
      }

      .de-card-meta {
        flex: 0 0 auto;
        color: var(--de-muted);
        font-size: 12px;
      }

      .de-card-progress {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-top: 12px;
        color: var(--de-muted);
        font-size: 12px;
        font-weight: 700;
      }

      .de-progress {
        display: block;
        height: 6px;
        margin-top: 7px;
        overflow: hidden;
        border-radius: 999px;
        background: var(--de-line);
      }

      .de-progress-fill {
        display: block;
        width: var(--de-progress, 0%);
        height: 100%;
        border-radius: inherit;
        background: var(--de-primary);
      }

      .de-progress-panel {
        border: 1px solid var(--de-border);
        border-radius: 10px;
        padding: 12px;
        margin: 0 0 14px;
        background: var(--de-bg);
      }

      .de-progress-panel-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        color: var(--de-muted);
        font-size: 12px;
        font-weight: 760;
      }

      .de-empty-state {
        display: grid;
        justify-items: center;
        gap: 10px;
        border: 1px dashed var(--de-border);
        border-radius: 12px;
        padding: 18px 16px;
        margin-bottom: 14px;
        background: color-mix(in srgb, var(--de-bg) 84%, var(--de-panel));
        text-align: center;
      }

      .de-empty-icon {
        width: 52px;
        height: 52px;
        border-radius: 16px;
        display: grid;
        place-items: center;
        background: var(--de-primary-soft);
        color: var(--de-primary);
      }

      .de-empty-icon svg {
        width: 34px;
        height: 34px;
      }

      .de-empty-state strong {
        display: block;
        font-size: 15px;
        line-height: 1.35;
      }

      .de-empty-state p {
        max-width: 280px;
        margin: 5px auto 0;
        color: var(--de-muted);
        font-size: 12px;
        line-height: 1.5;
      }

      :host(.de-rtl) .de-empty-state {
        text-align: center;
      }

      .de-stat-row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin: 0 0 16px;
      }

      .de-stat {
        border: 1px solid var(--de-border);
        border-radius: 10px;
        padding: 10px 8px;
        background: var(--de-bg);
        text-align: center;
      }

      .de-stat strong {
        display: block;
        font-size: 20px;
        line-height: 1;
      }

      .de-stat span {
        display: block;
        margin-top: 6px;
        color: var(--de-muted);
        font-size: 11px;
        font-weight: 700;
      }

      .de-dict-word {
        margin: 0 0 4px;
        overflow-wrap: anywhere;
        font-size: 28px;
        font-weight: 760;
        line-height: 1.2;
      }

      .de-dict-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
      }

      .de-speak-button {
        width: 38px;
        height: 38px;
        flex: 0 0 38px;
        border: 1px solid var(--de-border);
        border-radius: 12px;
        background: var(--de-panel);
        color: var(--de-text);
        display: grid;
        place-items: center;
      }

      .de-speak-button:hover {
        background: var(--de-primary-soft);
      }

      .de-speak-button svg {
        width: 20px;
        height: 20px;
      }

      .de-speak-button.is-test {
        margin: 0 auto 18px;
        width: 58px;
        height: 58px;
        border-radius: 18px;
      }

      .de-speak-button.is-test svg {
        width: 25px;
        height: 25px;
      }

      .de-dict-status {
        min-height: 19px;
        margin-bottom: 12px;
        color: var(--de-muted);
        font-size: 13px;
      }

      .de-dict-form {
        display: grid;
        gap: 10px;
      }

      .de-dict-actions {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 46px;
        gap: 9px;
        align-items: end;
      }

      .de-round-button {
        width: 46px;
        height: 46px;
        border: 0;
        border-radius: 50%;
        background: var(--de-primary);
        color: #fff;
        display: grid;
        place-items: center;
      }

      .de-primary-button,
      .de-secondary-button,
      .de-danger-button {
        min-height: 40px;
        border-radius: 10px;
        padding: 0 14px;
        font-size: 13px;
        font-weight: 760;
      }

      .de-primary-button {
        border: 0;
        background: var(--de-primary);
        color: #fff;
      }

      .de-secondary-button {
        border: 1px solid var(--de-border);
        background: transparent;
        color: var(--de-text);
      }

      .de-danger-button {
        border: 0;
        background: var(--de-danger);
        color: #fff;
      }

      .de-examples {
        margin-top: 12px;
        padding: 12px;
        border: 1px solid var(--de-line);
        border-radius: 8px;
        background: var(--de-bg);
      }

      .de-examples h4 {
        margin: 0 0 8px;
        font-size: 12px;
        color: var(--de-muted);
      }

      .de-examples p {
        margin: 0 0 7px;
        font-size: 12px;
        line-height: 1.45;
      }

      .de-guide-list {
        margin: 0;
        padding-left: 20px;
        color: var(--de-muted);
        font-size: 13px;
        line-height: 1.55;
      }

      :host(.de-rtl) .de-guide-list {
        padding-right: 20px;
        padding-left: 0;
      }

      .de-guide-list li {
        margin-bottom: 8px;
      }

      .de-info-note {
        color: var(--de-muted);
        font-size: 12px;
        line-height: 1.5;
      }

      .de-sync-status {
        border: 1px solid var(--de-line);
        border-radius: 10px;
        background: var(--de-bg);
        padding: 11px 12px;
        color: var(--de-muted);
        font-size: 12px;
        line-height: 1.45;
      }

      .de-sync-status strong {
        display: block;
        margin-bottom: 4px;
        color: var(--de-text);
        font-size: 14px;
      }

      .de-sync-actions {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 8px;
      }

      .de-primary-button:disabled,
      .de-secondary-button:disabled,
      .de-danger-button:disabled {
        cursor: not-allowed;
        opacity: 0.5;
      }

      .de-word-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 11px;
        align-items: start;
      }

      .de-word-def {
        margin-top: 5px;
        color: var(--de-muted);
        font-size: 12px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }

      .de-level {
        width: 31px;
        height: 31px;
        border-radius: 50%;
        border: 1px solid var(--de-border);
        background: var(--de-panel);
        color: var(--de-muted);
        display: grid;
        place-items: center;
        font-size: 12px;
        font-weight: 800;
      }

      .de-level.is-filled {
        border-color: var(--de-primary);
        background: var(--de-primary);
        color: #fff;
      }

      .de-word-detail-head {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 12px;
        align-items: start;
      }

      .de-level-row {
        display: grid;
        grid-template-columns: repeat(5, 42px);
        justify-content: center;
        gap: 8px;
      }

      .de-level-grid {
        display: grid;
        grid-template-columns: repeat(5, 42px);
        justify-content: center;
        gap: 8px;
        margin-top: 18px;
      }

      .de-level-option {
        height: 42px;
        border: 1px solid #a8a8a8;
        border-radius: 50%;
        background: transparent;
        color: inherit;
        font-weight: 760;
      }

      .de-level-option.is-active {
        background: #505050;
        border-color: #505050;
        color: #fff;
      }

      .de-test-header {
        display: grid;
        grid-template-columns: 40px minmax(0, 1fr) 40px;
        align-items: center;
        gap: 8px;
        margin-bottom: 20px;
      }

      .de-test-icon {
        width: 38px;
        height: 38px;
        border: 0;
        border-radius: 11px;
        background: #d0d0d0;
        color: #303030;
        display: grid;
        place-items: center;
      }

      .de-test-icon svg.de-logo-svg {
        width: 31px;
        height: 31px;
      }

      :host(.de-dark) .de-test-icon {
        background: #3d454f;
        color: #fff;
      }

      .de-test-progress {
        text-align: center;
        color: inherit;
        font-size: 13px;
        font-weight: 700;
        opacity: 0.65;
      }

      .de-test-center {
        min-height: 420px;
        display: flex;
        flex-direction: column;
        justify-content: center;
      }

      .de-test-word {
        margin: 0 0 12px;
        text-align: center;
        overflow-wrap: anywhere;
        font-size: 25px;
        font-weight: 760;
        line-height: 1.25;
      }

      .de-test-hint {
        margin: 0 0 20px;
        text-align: center;
        font-size: 13px;
        line-height: 1.45;
        opacity: 0.7;
      }

      .de-test-divider {
        height: 1px;
        background: #ababab;
        margin: 26px 0;
      }

      .de-choice {
        width: 100%;
        min-height: 52px;
        margin-bottom: 10px;
        border: 1px solid #ababab;
        border-radius: 20px;
        background: transparent;
        color: inherit;
        padding: 12px 15px;
        text-align: left;
        line-height: 1.35;
      }

      .de-choice:hover {
        background: rgba(80, 80, 80, 0.08);
      }

      .de-spell-input {
        width: 100%;
        height: 52px;
        border: 1px solid #ababab;
        border-radius: 16px;
        background: transparent;
        color: inherit;
        outline: 0;
        padding: 0 14px;
        text-align: center;
        font-size: 18px;
      }

      .de-action-row {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 18px;
        flex-wrap: wrap;
      }

      .de-test-button {
        min-height: 42px;
        border: 1px solid #ababab;
        border-radius: 15px;
        background: transparent;
        color: inherit;
        padding: 0 16px;
        font-weight: 750;
      }

      .de-ox-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 18px;
      }

      .de-ox-button {
        height: 52px;
        border: 1px solid #ababab;
        border-radius: 8px;
        background: transparent;
        color: inherit;
        font-size: 15px;
        font-weight: 800;
      }

      .de-bottom {
        height: 64px;
        flex: 0 0 auto;
        background: var(--de-primary);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 22px 12px;
        border-radius: 0 0 18px 18px;
        margin: 0;
        box-shadow: 0 -8px 18px rgba(35, 79, 74, 0.12);
      }

      :host(.de-dark) .de-bottom {
        background: var(--de-primary);
      }

      .de-bottom.is-hidden {
        display: none;
      }

      .de-bottom button {
        width: 50px;
        height: 38px;
        border: 0;
        border-radius: 13px;
        background: rgba(255, 255, 255, 0.94);
        color: var(--de-primary);
        display: grid;
        place-items: center;
      }

      :host(.de-dark) .de-bottom button {
        border: 1px solid var(--de-border);
        background: var(--de-primary-soft);
        color: var(--de-text);
      }

      :host(.de-dark) .de-bottom button:hover {
        border-color: color-mix(in srgb, var(--de-muted) 70%, var(--de-border));
        background: color-mix(in srgb, var(--de-primary-soft) 72%, var(--de-text));
      }

      .de-bottom button.is-close {
        border-radius: 13px;
      }

      .de-modal {
        position: absolute;
        inset: 0;
        z-index: 30;
        display: none;
        align-items: center;
        justify-content: center;
        padding: 18px;
        background: rgba(0, 0, 0, 0.52);
      }

      .de-modal.is-open {
        display: flex;
      }

      .de-modal-box {
        width: 100%;
        max-height: 92%;
        overflow: auto;
        border-radius: 12px;
        background: var(--de-panel);
        color: var(--de-text);
        padding: 18px;
      }

      .de-modal-actions {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 8px;
        margin-top: 12px;
      }

      .de-toast {
        position: absolute;
        left: 20px;
        right: 20px;
        bottom: 78px;
        z-index: 40;
        display: none;
        border-radius: 10px;
        background: #1f252b;
        color: #fff;
        padding: 11px 13px;
        text-align: center;
        font-size: 13px;
        font-weight: 700;
      }

      .de-toast.is-visible {
        display: block;
      }

      .de-hidden {
        display: none !important;
      }

      @media (max-width: 480px) {
        .de-panel {
          right: 10px;
          bottom: 10px;
          width: calc(100vw - 20px);
          height: calc(100vh - 20px);
        }

        .de-panel.is-sized {
          right: auto;
          bottom: auto;
        }

        .de-view {
          padding: 18px;
        }
      }
    </style>

    <button class="de-fab" id="de-fab" data-action="toggle-panel" aria-label="Open DictionEvery">${ICONS.book}</button>
    <button class="de-tooltip" id="de-tooltip" data-action="tooltip-search" type="button">
      <span id="de-tooltip-content"></span>
    </button>

    <section class="de-panel" id="de-panel" aria-label="DictionEvery">
      <div class="de-top" id="de-top">
        <div class="de-header">
          <button class="de-brand" data-action="go-home" type="button">${ICONS.book}<span id="de-brand-label">DictionEvery</span></button>
          <button class="de-icon-button" data-action="toggle-menu" type="button" aria-label="Menu">${ICONS.menu}</button>
        </div>
        <form class="de-search" id="de-search-form">
          <input id="de-search-input" type="search" autocomplete="off" spellcheck="false" dir="auto" />
          <button type="submit" aria-label="Search">${ICONS.search}</button>
          <div class="de-suggestions" id="de-suggestions"></div>
        </form>
      </div>

      <aside class="de-menu" id="de-menu">
        <div class="de-menu-head">
          <span id="de-menu-title">Menu</span>
          <button class="de-icon-button" data-action="toggle-menu" type="button" aria-label="Close menu">${ICONS.close}</button>
        </div>
        <div class="de-menu-field">
          <div class="de-label" id="de-menu-meaning-label"></div>
          <button class="de-language-card" id="de-menu-language-card" data-action="toggle-language-list" type="button"></button>
          <div class="de-language-options" id="de-menu-language-options"></div>
        </div>
        <div class="de-menu-body">
          <button class="de-menu-item" data-action="go-home" type="button">${ICONS.list}<span data-i18n="vocabulary"></span></button>
          <button class="de-menu-item" data-action="menu-test" type="button">${ICONS.cards}<span data-i18n="test"></span></button>
          <button class="de-menu-item" data-action="go-export" type="button">${ICONS.plus}<span data-i18n="share"></span></button>
          <button class="de-menu-item" data-action="go-sync" type="button">${ICONS.sync}<span data-i18n="sync"></span></button>
          <button class="de-menu-item" data-action="go-settings" type="button">${ICONS.settings}<span data-i18n="settings"></span></button>
        </div>
      </aside>

      <main class="de-main">
        <section class="de-view is-active" id="de-view-home"></section>
        <section class="de-view" id="de-view-dictionary"></section>
        <section class="de-view" id="de-view-deck"></section>
        <section class="de-view" id="de-view-export"></section>
        <section class="de-view" id="de-view-export-guide"></section>
        <section class="de-view" id="de-view-sync"></section>
        <section class="de-view de-test-view" id="de-view-test-setup"></section>
        <section class="de-view de-test-view" id="de-view-test-run"></section>
        <section class="de-view de-test-view" id="de-view-proficiency"></section>
        <section class="de-view de-test-view" id="de-view-test-result"></section>
        <section class="de-view" id="de-view-settings"></section>
        <div class="de-modal" id="de-edit-modal"></div>
        <div class="de-toast" id="de-toast"></div>
      </main>

      <nav class="de-bottom" id="de-bottom">
        <button id="de-bottom-left" data-action="bottom-left" type="button" aria-label="Close">${ICONS.close}</button>
        <button data-action="go-home" type="button" aria-label="Home">${ICONS.home}</button>
        <button data-action="quick-save" type="button" aria-label="Add">${ICONS.plus}</button>
      </nav>
      <span class="de-resize-handle de-resize-n" data-resize="n" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-s" data-resize="s" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-e" data-resize="e" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-w" data-resize="w" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-ne" data-resize="ne" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-nw" data-resize="nw" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-se" data-resize="se" aria-hidden="true"></span>
      <span class="de-resize-handle de-resize-sw" data-resize="sw" aria-hidden="true"></span>
    </section>
  `;

  const $ = (selector) => shadow.querySelector(selector);
  const $$ = (selector) => Array.from(shadow.querySelectorAll(selector));

  init();

  async function init() {
    state = normalizeState(await loadState());
    ensureDeckForCurrentLanguage();
    applyTheme();
    fillLanguageSelects();
    attachEvents();
    attachSelectionEvents();
    listenForPopup();
    await loadSyncStatus();
    await loadAiConfigStatus();
    renderAll();
    applySavedLayout();
  }

  function attachEvents() {
    shadow.addEventListener("click", handleShadowClick);
    shadow.addEventListener("change", handleShadowChange);
    shadow.addEventListener("input", handleShadowInput);
    shadow.addEventListener("pointerdown", handleResizeStart);
    shadow.addEventListener("pointerdown", handleDragStart);
    window.addEventListener("pointermove", handleResizeMove, true);
    window.addEventListener("pointermove", handleDragMove, true);
    window.addEventListener("pointerup", handleResizeEnd, true);
    window.addEventListener("pointerup", handleDragEnd, true);
    window.addEventListener("resize", handleViewportResize);

    $("#de-search-form").addEventListener("submit", (event) => {
      event.preventDefault();
      searchFromInput();
    });
  }

  function attachSelectionEvents() {
    document.addEventListener("mouseup", handleSelection, true);
    document.addEventListener("keyup", handleSelection, true);
    document.addEventListener("mousedown", (event) => {
      if (!event.composedPath().includes(host)) {
        hideTooltip();
      }
    }, true);
    document.addEventListener("scroll", hideTooltip, true);
  }

  function listenForPopup() {
    if (!hasChromeRuntime()) {
      return;
    }

    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!message || !message.type) {
        return false;
      }

      if (message.type === "DE_TOGGLE_PANEL") {
        togglePanel();
        sendResponse({ ok: true });
        return true;
      }

      if (message.type === "DE_OPEN_PANEL") {
        openPanel();
        sendResponse({ ok: true });
        return true;
      }

      if (message.type === "DE_SEARCH_WORD") {
        openPanel();
        searchWord(message.word);
        sendResponse({ ok: true });
        return true;
      }

      return false;
    });
  }

  function handleShadowClick(event) {
    const trigger = event.target.closest("[data-action]");
    if (!trigger) {
      return;
    }

    if (runtime.suppressNextClick) {
      runtime.suppressNextClick = false;
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    const action = trigger.dataset.action;

    if (action === "toggle-panel") togglePanel();
    if (action === "close-panel") closePanel();
    if (action === "bottom-left") handleBottomLeft();
    if (action === "toggle-menu") toggleMenu();
    if (action === "toggle-language-list") toggleLanguageList();
    if (action === "set-target-language") {
      setSourceLanguage(trigger.dataset.lang);
    }
    if (action === "toggle-meaning-list") {
      toggleMeaningLanguageList();
    }
    if (action === "toggle-meaning-language") {
      toggleMeaningLanguage(trigger.dataset.lang);
    }
    if (action === "set-lookup-language") {
      setLookupLanguage(trigger.dataset.lang);
    }
    if (action === "set-lookup-source") {
      setLookupSource(trigger.dataset.source);
    }
    if (action === "speak-lookup") {
      speakLookupWord();
    }
    if (action === "speak-test-word") {
      speakCurrentTestWord();
    }
    if (action === "go-home") goHome();
    if (action === "go-settings") {
      runtime.menuOpen = false;
      setView("settings");
    }
    if (action === "go-export") {
      runtime.menuOpen = false;
      setView("export");
    }
    if (action === "go-sync") {
      runtime.menuOpen = false;
      loadSyncStatus();
      setView("sync");
    }
    if (action === "export-anki") {
      exportCurrentDeck("anki");
    }
    if (action === "export-quizlet") {
      exportCurrentDeck("quizlet");
    }
    if (action === "export-lingq") {
      exportCurrentDeck("lingq");
    }
    if (action === "open-export-link") {
      openExportLink(trigger.dataset.url);
    }
    if (action === "sync-save-config") {
      saveSyncConfig();
    }
    if (action === "sync-test-config") {
      testSyncConfig();
    }
    if (action === "sync-clear-config") {
      clearSyncConfig();
    }
    if (action === "sync-sign-in") {
      signInSync();
    }
    if (action === "sync-sign-up") {
      signUpSync();
    }
    if (action === "sync-google") {
      googleSignInSync();
    }
    if (action === "sync-sign-out") {
      signOutSync();
    }
    if (action === "sync-upload") {
      uploadSync();
    }
    if (action === "sync-download") {
      downloadSync();
    }
    if (action === "sync-merge") {
      mergeSync();
    }
    if (action === "ai-save-config") {
      saveAiConfig();
    }
    if (action === "ai-test-config") {
      testAiConfig();
    }
    if (action === "ai-clear-config") {
      clearAiConfig();
    }
    if (action === "menu-test") goTestFromMenu();
    if (action === "tooltip-search") {
      const word = runtime.selectedWord;
      hideTooltip();
      openPanel();
      searchWord(word);
    }
    if (action === "focus-search") {
      focusSearchInput();
    }
    if (action === "suggest-search") {
      const word = trigger.dataset.word || "";
      $("#de-search-input").value = word;
      hideSuggestions();
      searchWord(word);
    }
    if (action === "open-deck") {
      openDeck(trigger.dataset.deckId);
    }
    if (action === "open-word") {
      openEditModal(trigger.dataset.wordId);
    }
    if (action === "save-word") {
      saveCurrentWord();
    }
    if (action === "quick-save") {
      saveCurrentWord();
    }
    if (action === "start-test") {
      startTest();
    }
    if (action === "select-test") startTest();
    if (action === "answer-choice") {
      answerCurrentQuestion(trigger.dataset.correct === "true");
    }
    if (action === "spell-submit") {
      submitSpellingAnswer();
    }
    if (action === "spell-skip") {
      answerCurrentQuestion(false);
    }
    if (action === "reveal-card") {
      revealCard();
    }
    if (action === "card-answer") {
      answerCurrentQuestion(trigger.dataset.correct === "true");
    }
    if (action === "set-rate") {
      setPendingRate(Number(trigger.dataset.rate));
    }
    if (action === "set-edit-rate") {
      setEditRate(trigger);
    }
    if (action === "next-question") {
      goNextQuestion();
    }
    if (action === "finish-test") {
      finishTest();
    }
    if (action === "save-edit") {
      saveEditModal();
    }
    if (action === "delete-edit") {
      deleteEditWord();
    }
    if (action === "close-edit") {
      closeEditModal();
    }
    if (action === "reset-data") {
      resetData();
    }
  }

  function handleShadowChange(event) {
    const target = event.target;

    if (target.id === "de-settings-ui-lang") {
      state.uiLang = target.value;
      saveAndRender();
    }

    if (target.id === "de-settings-theme") {
      state.theme = target.value;
      applyTheme();
      saveAndRender();
    }

    if (target.id === "de-settings-batch-size") {
      state.testBatchSize = Number(target.value);
      saveAndRender();
    }

    if (target.id === "de-settings-dictionary-mode") {
      state.dictionarySearchMode = target.value === "precise" ? "precise" : "fast";
      saveAndRender();
    }

    if (target.id === "de-ai-provider") {
      const accountRow = $(".de-ai-account-row");
      if (accountRow) {
        accountRow.classList.toggle("de-hidden-setting", target.value !== "cloudflare");
      }
    }

    if (target.id === "de-dict-deck") {
      const input = $("#de-new-deck-name");
      if (target.value === "NEW_DECK") {
        input.classList.remove("de-hidden");
        input.focus();
      } else {
        input.classList.add("de-hidden");
      }
    }
  }

  function handleShadowInput(event) {
    if (event.target.id === "de-search-input") {
      renderSuggestions(event.target.value);
    }

    if (event.target.id === "de-spell-input" && event.inputType === "insertLineBreak") {
      submitSpellingAnswer();
    }
  }

  function handleSelection(event) {
    if (event.type === "keyup" && !["Shift", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
      return;
    }

    if (event.composedPath && event.composedPath().includes(host)) {
      return;
    }

    const active = document.activeElement;
    if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.isContentEditable)) {
      return;
    }

    window.setTimeout(() => {
      const selection = window.getSelection();
      const selectedText = cleanSelectedText(selection ? selection.toString() : "");

      if (!selection || selection.rangeCount === 0 || selectedText.length < 1 || selectedText.length > 70) {
        hideTooltip();
        return;
      }

      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) {
        hideTooltip();
        return;
      }

      runtime.selectedWord = selectedText;
      const tooltip = $("#de-tooltip");
      const left = Math.max(12, Math.min(window.innerWidth - 154, rect.left + rect.width / 2 - 67));
      const top = Math.max(12, rect.top - 58);
      tooltip.style.left = `${left}px`;
      tooltip.style.top = `${top}px`;
      tooltip.classList.add("is-visible");
    }, 20);
  }

  function togglePanel() {
    if (runtime.panelOpen) {
      closePanel();
    } else {
      openPanel();
    }
  }

  function openPanel() {
    const fabAnchor = getFabAnchorRect();
    runtime.panelOpen = true;
    const panel = $("#de-panel");
    panel.classList.add("is-open");
    $("#de-fab").classList.add("is-hidden");
    positionPanelForOpen(fabAnchor);
    renderAll();
  }

  function closePanel() {
    runtime.panelOpen = false;
    runtime.menuOpen = false;
    runtime.languageMenuOpen = false;
    runtime.meaningLanguageMenuOpen = false;
    runtime.resizing = null;
    runtime.dragging = null;
    $("#de-panel").classList.remove("is-open");
    resetPanelInlineGeometry();
    $("#de-fab").classList.remove("is-hidden");
    applySavedFabPosition();
    hideSuggestions();
    hideTooltip();
  }

  function ensureLayoutState() {
    if (!state.layout || typeof state.layout !== "object") {
      state.layout = {};
    }
    return state.layout;
  }

  function getFabAnchorRect() {
    const saved = ensureLayoutState().fab;
    if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
      return { left: saved.left, top: saved.top, width: 58, height: 58 };
    }

    const rect = $("#de-fab").getBoundingClientRect();
    return {
      left: rect.left,
      top: rect.top,
      width: rect.width || 58,
      height: rect.height || 58
    };
  }

  function getFabLimits(width = 58, height = 58) {
    const margin = 8;
    return {
      margin,
      maxLeft: Math.max(margin, (window.innerWidth || width) - margin - width),
      maxTop: Math.max(margin, (window.innerHeight || height) - margin - height)
    };
  }

  function setFabPosition(left, top, options = {}) {
    const fab = $("#de-fab");
    const rect = fab.getBoundingClientRect();
    const width = rect.width || 58;
    const height = rect.height || 58;
    const limits = getFabLimits(width, height);
    const nextLeft = clampValue(left, limits.margin, limits.maxLeft);
    const nextTop = clampValue(top, limits.margin, limits.maxTop);

    fab.classList.add("is-positioned");
    fab.style.left = `${Math.round(nextLeft)}px`;
    fab.style.top = `${Math.round(nextTop)}px`;
    if (options.persist) {
      const layout = ensureLayoutState();
      layout.fab = { left: Math.round(nextLeft), top: Math.round(nextTop) };
      if (options.clearPanel) {
        delete layout.panel;
      }
      saveState();
    }
  }

  function applySavedFabPosition() {
    const fab = $("#de-fab");
    const saved = ensureLayoutState().fab;
    if (!saved || !Number.isFinite(saved.left) || !Number.isFinite(saved.top)) {
      return;
    }
    setFabPosition(saved.left, saved.top);
  }

  function applySavedLayout() {
    applySavedFabPosition();
  }

  function resetPanelInlineGeometry() {
    const panel = $("#de-panel");
    panel.classList.remove("is-sized", "is-dragging");
    panel.style.left = "";
    panel.style.top = "";
    panel.style.width = "";
    panel.style.height = "";
  }

  function getPanelLimits() {
    const margin = 10;
    const viewportWidth = Math.max(220, window.innerWidth || 390);
    const viewportHeight = Math.max(360, window.innerHeight || 650);
    const maxWidth = Math.max(160, Math.min(780, viewportWidth - margin * 2));
    const maxHeight = Math.max(260, Math.min(1300, viewportHeight - margin * 2));

    return {
      margin,
      minWidth: Math.min(195, maxWidth),
      minHeight: Math.min(325, maxHeight),
      maxWidth,
      maxHeight
    };
  }

  function clampValue(value, min, max) {
    const safeMax = Math.max(min, max);
    return Math.min(Math.max(value, min), safeMax);
  }

  function setPanelRect(left, top, width, height, options = {}) {
    const panel = $("#de-panel");
    const limits = getPanelLimits();
    const nextWidth = clampValue(width, limits.minWidth, limits.maxWidth);
    const nextHeight = clampValue(height, limits.minHeight, limits.maxHeight);
    const maxLeft = Math.max(limits.margin, (window.innerWidth || nextWidth) - limits.margin - nextWidth);
    const maxTop = Math.max(limits.margin, (window.innerHeight || nextHeight) - limits.margin - nextHeight);
    const nextLeft = clampValue(left, limits.margin, maxLeft);
    const nextTop = clampValue(top, limits.margin, maxTop);

    panel.classList.add("is-sized");
    panel.style.left = `${Math.round(nextLeft)}px`;
    panel.style.top = `${Math.round(nextTop)}px`;
    panel.style.width = `${Math.round(nextWidth)}px`;
    panel.style.height = `${Math.round(nextHeight)}px`;
    if (options.persist) {
      const layout = ensureLayoutState();
      layout.panel = {
        left: Math.round(nextLeft),
        top: Math.round(nextTop)
      };
      saveState();
    }
  }

  function positionPanelForOpen(fabAnchor) {
    const saved = ensureLayoutState().panel;
    const panel = $("#de-panel");
    const width = DEFAULT_PANEL_WIDTH;
    const height = DEFAULT_PANEL_HEIGHT;

    if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
      setPanelRect(saved.left, saved.top, width, height);
      return;
    }

    if (ensureLayoutState().fab && fabAnchor) {
      setPanelRect(
        fabAnchor.left + fabAnchor.width - width,
        fabAnchor.top + fabAnchor.height - height,
        width,
        height
      );
      return;
    }

    ensurePanelGeometry();
  }

  function ensurePanelGeometry() {
    const panel = $("#de-panel");
    if (!panel || !panel.classList.contains("is-open")) {
      return;
    }

    const rect = panel.getBoundingClientRect();
    setPanelRect(rect.left, rect.top, rect.width, rect.height);
  }

  function clampPanelToViewport() {
    const panel = $("#de-panel");
    if (!panel || !panel.classList.contains("is-open")) {
      return;
    }

    const rect = panel.getBoundingClientRect();
    setPanelRect(rect.left, rect.top, rect.width, rect.height);
  }

  function clampFabToViewport() {
    const saved = ensureLayoutState().fab;
    if (!saved || !Number.isFinite(saved.left) || !Number.isFinite(saved.top)) {
      return;
    }
    setFabPosition(saved.left, saved.top, { persist: true });
  }

  function handleViewportResize() {
    clampPanelToViewport();
    clampFabToViewport();
  }

  function persistCurrentPanelRect() {
    const panel = $("#de-panel");
    if (!panel || !panel.classList.contains("is-open")) {
      return;
    }

    const rect = panel.getBoundingClientRect();
    setPanelRect(rect.left, rect.top, rect.width, rect.height, { persist: true });
  }

  function handleResizeStart(event) {
    const handle = event.target.closest("[data-resize]");
    if (!handle || !runtime.panelOpen) {
      return;
    }

    ensurePanelGeometry();
    const rect = $("#de-panel").getBoundingClientRect();
    runtime.resizing = {
      direction: handle.dataset.resize,
      startX: event.clientX,
      startY: event.clientY,
      left: rect.left,
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom
    };
    event.preventDefault();
    event.stopPropagation();
    handle.setPointerCapture?.(event.pointerId);
  }

  function handleResizeMove(event) {
    if (!runtime.resizing) {
      return;
    }

    const limits = getPanelLimits();
    const resize = runtime.resizing;
    const direction = resize.direction;
    const dx = event.clientX - resize.startX;
    const dy = event.clientY - resize.startY;
    let left = resize.left;
    let top = resize.top;
    let right = resize.right;
    let bottom = resize.bottom;

    if (direction.includes("e")) {
      right = clampValue(resize.right + dx, left + limits.minWidth, Math.min((window.innerWidth || right) - limits.margin, left + limits.maxWidth));
    }

    if (direction.includes("w")) {
      left = clampValue(resize.left + dx, Math.max(limits.margin, right - limits.maxWidth), right - limits.minWidth);
    }

    if (direction.includes("s")) {
      bottom = clampValue(resize.bottom + dy, top + limits.minHeight, Math.min((window.innerHeight || bottom) - limits.margin, top + limits.maxHeight));
    }

    if (direction.includes("n")) {
      top = clampValue(resize.top + dy, Math.max(limits.margin, bottom - limits.maxHeight), bottom - limits.minHeight);
    }

    setPanelRect(left, top, right - left, bottom - top);
    event.preventDefault();
  }

  function handleResizeEnd() {
    if (runtime.resizing) {
      persistCurrentPanelRect();
    }
    runtime.resizing = null;
  }

  function handleDragStart(event) {
    if (runtime.resizing || event.target.closest("[data-resize]")) {
      return;
    }

    const fab = event.target.closest("#de-fab");
    if (fab) {
      const rect = fab.getBoundingClientRect();
      runtime.dragging = {
        type: "fab",
        startX: event.clientX,
        startY: event.clientY,
        left: rect.left,
        top: rect.top,
        width: rect.width || 58,
        height: rect.height || 58,
        currentLeft: rect.left,
        currentTop: rect.top,
        moved: false
      };
      fab.setPointerCapture?.(event.pointerId);
      event.preventDefault();
      return;
    }

    const panelTop = event.target.closest("#de-top");
    if (!panelTop || !runtime.panelOpen || isPanelDragBlocked(event.target)) {
      return;
    }

    const rect = $("#de-panel").getBoundingClientRect();
    runtime.dragging = {
      type: "panel",
      startX: event.clientX,
      startY: event.clientY,
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
      currentLeft: rect.left,
      currentTop: rect.top,
      moved: false
    };
    panelTop.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  }

  function isPanelDragBlocked(target) {
    return Boolean(target.closest("input, textarea, select, button, a, [data-action]"));
  }

  function handleDragMove(event) {
    const drag = runtime.dragging;
    if (!drag) {
      return;
    }

    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (!drag.moved && Math.hypot(dx, dy) < 5) {
      return;
    }

    drag.moved = true;
    drag.currentLeft = drag.left + dx;
    drag.currentTop = drag.top + dy;

    if (drag.type === "fab") {
      $("#de-fab").classList.add("is-dragging");
      setFabPosition(drag.currentLeft, drag.currentTop);
    } else {
      $("#de-panel").classList.add("is-dragging");
      setPanelRect(drag.currentLeft, drag.currentTop, drag.width, drag.height);
    }

    event.preventDefault();
  }

  function handleDragEnd() {
    const drag = runtime.dragging;
    if (!drag) {
      return;
    }

    $("#de-fab").classList.remove("is-dragging");
    $("#de-panel").classList.remove("is-dragging");

    if (drag.moved) {
      if (drag.type === "fab") {
        setFabPosition(drag.currentLeft, drag.currentTop, { persist: true, clearPanel: true });
      } else {
        setPanelRect(drag.currentLeft, drag.currentTop, drag.width, drag.height, { persist: true });
      }
      runtime.suppressNextClick = true;
      window.setTimeout(() => {
        runtime.suppressNextClick = false;
      }, 80);
    }

    runtime.dragging = null;
  }

  function handleBottomLeft() {
    if (runtime.activeView === "home") {
      closePanel();
      return;
    }
    navigateBack();
  }

  function navigateBack() {
    if (["test-setup", "test-run", "proficiency", "test-result"].includes(runtime.activeView)) {
      finishTest();
      return;
    }
    if (runtime.activeView === "deck") {
      setView("home");
      return;
    }
    if (runtime.activeView === "export-guide") {
      setView("export");
      return;
    }
    if (runtime.activeView === "export") {
      setView(runtime.currentDeckId ? "deck" : "home");
      return;
    }
    if (runtime.activeView === "sync") {
      setView("home");
      return;
    }
    if (runtime.activeView === "dictionary" || runtime.activeView === "settings") {
      setView(runtime.previousView && runtime.previousView !== runtime.activeView ? runtime.previousView : "home");
      return;
    }
    setView("home");
  }

  function toggleMenu() {
    const willOpen = !runtime.menuOpen;
    runtime.menuOpen = willOpen;
    if (willOpen) {
      runtime.languageMenuOpen = false;
    }
    renderMenu();
    renderHome();
  }

  function toggleLanguageList() {
    runtime.languageMenuOpen = !runtime.languageMenuOpen;
    renderMenu();
    renderHome();
    renderSettings();
  }

  function toggleMeaningLanguageList() {
    runtime.meaningLanguageMenuOpen = !runtime.meaningLanguageMenuOpen;
    renderSettings();
  }

  function setSourceLanguage(langCode, options = {}) {
    if (!LANGUAGES.some((lang) => lang.code === langCode)) {
      return;
    }
    state.sourceLang = langCode;
    state.targetLang = langCode;
    state.currentDictLang = langCode;
    runtime.languageMenuOpen = false;
    ensureDeckForCurrentLanguage();
    if (options.render === false) {
      saveState();
      return;
    }
    saveAndRender();
  }

  function toggleMeaningLanguage(langCode) {
    if (!LANGUAGES.some((lang) => lang.code === langCode)) {
      return;
    }

    const current = getMeaningLanguages();
    const exists = current.includes(langCode);
    const next = exists
      ? current.filter((code) => code !== langCode)
      : [...current, langCode];

    state.targetLangs = normalizeLanguageCodes(next.length ? next : current);
    if (!state.targetLangs.includes(state.currentMeaningLang)) {
      state.currentMeaningLang = state.targetLangs[0];
    }
    if (runtime.lookup && !state.targetLangs.includes(runtime.lookup.activeMeaningLang)) {
      runtime.lookup.activeMeaningLang = state.currentMeaningLang;
    }
    saveAndRender();
  }

  function setLookupLanguage(langCode) {
    if (!getMeaningLanguages().includes(langCode)) {
      return;
    }

    state.currentMeaningLang = langCode;
    if (runtime.lookup) {
      runtime.lookup.activeMeaningLang = langCode;
      renderDictionary();
      if (!runtime.lookup.results?.[langCode]) {
        loadLookupForLanguage(langCode);
      }
    }
    saveState();
  }

  function setLookupSource(sourceId) {
    const meaningLang = runtime.lookup?.activeMeaningLang || activeMeaningLang();
    const result = runtime.lookup?.results?.[meaningLang];
    if (!result || result.loading) {
      return;
    }

    const available = ["all", ...(result.sources || []).map((source) => source.id)];
    if (!available.includes(sourceId)) {
      return;
    }
    result.activeSourceId = sourceId || "all";
    renderDictionary();
  }

  function goHome() {
    runtime.menuOpen = false;
    setView("home");
  }

  function goTestFromMenu() {
    runtime.menuOpen = false;
    const deck = getDecksForCurrentLanguage().find((item) => getWordsByDeck(item.id).length > 0);
    if (!deck) {
      toast(t("startTestHint"));
      setView("home");
      return;
    }
    runtime.currentDeckId = deck.id;
    startTest();
  }

  function setView(viewName) {
    if (runtime.activeView !== viewName) {
      runtime.previousView = runtime.activeView;
    }
    runtime.activeView = viewName;
    const hideChrome = ["test-setup", "test-run", "proficiency", "test-result"].includes(viewName);
    $("#de-top").classList.toggle("de-hidden", hideChrome);
    $("#de-bottom").classList.toggle("is-hidden", hideChrome);
    $$(".de-view").forEach((view) => view.classList.remove("is-active"));
    const active = $(`#de-view-${viewName}`);
    if (active) {
      active.classList.add("is-active");
    }
    renderAll();
  }

  function searchFromInput() {
    const input = $("#de-search-input");
    const word = cleanSelectedText(input.value);
    hideSuggestions();

    if (!word) {
      toast(t("noWord"));
      return;
    }

    searchWord(word);
  }

  function focusSearchInput() {
    runtime.menuOpen = false;
    runtime.languageMenuOpen = false;
    renderMenu();
    renderHome();
    const input = $("#de-search-input");
    input?.focus();
    input?.select();
  }

  async function searchWord(rawWord) {
    const word = cleanSelectedText(rawWord);
    if (!word) {
      toast(t("noWord"));
      return;
    }

    const token = Date.now();
    const detectedSourceLang = detectWordLanguage(word);
    if (detectedSourceLang !== sourceLang()) {
      setSourceLanguage(detectedSourceLang, { render: false });
    }
    const activeMeaningLang = chooseInitialMeaningLanguage(detectedSourceLang);
    state.currentMeaningLang = activeMeaningLang;
    saveState();
    runtime.lookupToken = token;
    runtime.lookup = {
      word,
      sourceLang: detectedSourceLang,
      activeMeaningLang,
      results: {}
    };
    speakText(word, detectedSourceLang);
    addRecent(word);
    $("#de-search-input").value = word;
    setView("dictionary");
    await loadLookupForLanguage(activeMeaningLang, token);
  }

  async function loadLookupForLanguage(langCode, existingToken = runtime.lookupToken) {
    if (!runtime.lookup?.word || !getMeaningLanguages().includes(langCode)) {
      return;
    }

    runtime.lookup.results = runtime.lookup.results || {};
    runtime.lookup.results[langCode] = {
      phonetic: "",
      definition: "",
      examples: [],
      sources: [],
      activeSourceId: "all",
      status: t("loading"),
      loading: true
    };
    renderDictionary();

    try {
      const payload = await lookupViaBackground(runtime.lookup.word, langCode, runtime.lookup.sourceLang);
      if (runtime.lookupToken !== existingToken || !runtime.lookup) {
        return;
      }
      runtime.lookup.results[langCode] = lookupResultFromPayload(payload, langCode);
      renderDictionary();
    } catch (_error) {
      if (runtime.lookupToken !== existingToken || !runtime.lookup) {
        return;
      }
      runtime.lookup.results[langCode] = {
        phonetic: "",
        definition: t("manualDefinition"),
        examples: [],
        sources: [],
        activeSourceId: "all",
        status: t("lookupFailed"),
        loading: false
      };
      renderDictionary();
    }
  }

  function lookupResultFromPayload(payload, langCode) {
    const sources = normalizeLookupSources(payload.sourceResults);
    return {
      phonetic: payload.phonetic || "",
      definition: formatLookupDefinition(payload),
      examples: Array.isArray(payload.examples) ? payload.examples : [],
      sources,
      activeSourceId: sources.length ? "all" : "",
      status: "",
      loading: false
    };
  }

  function normalizeLookupSources(sources) {
    if (!Array.isArray(sources)) {
      return [];
    }

    return sources
      .map((source) => {
        const definitions = Array.isArray(source.definitions) ? source.definitions.filter(Boolean) : [];
        const examples = Array.isArray(source.examples) ? source.examples.filter(Boolean) : [];
        return {
          id: String(source.id || "").trim(),
          label: String(source.label || source.id || "").trim(),
          definitions,
          examples
        };
      })
      .filter((source) => source.id && source.label && (source.definitions.length || source.examples.length));
  }

  function dictionaryDisplayResult(result) {
    const activeSourceId = result?.activeSourceId || "all";
    if (activeSourceId && activeSourceId !== "all") {
      const source = (result.sources || []).find((item) => item.id === activeSourceId);
      if (source) {
        return {
          definition: formatDefinitionLines(source.definitions),
          examples: source.examples || []
        };
      }
    }

    return {
      definition: result?.definition || "",
      examples: Array.isArray(result?.examples) ? result.examples : []
    };
  }

  function lookupViaBackground(word, meaningLang, sourceLanguage) {
    if (!hasChromeRuntime()) {
      return Promise.resolve({
        word,
        targetLang: meaningLang,
        sourceLang: sourceLanguage,
        phonetic: "",
        definitions: [word],
        examples: [],
        source: "local-preview",
        sourceResults: [{
          id: "local-preview",
          label: "Preview",
          definitions: [word],
          examples: []
        }]
      });
    }

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: "DE_LOOKUP_WORD",
          word,
          targetLang: meaningLang,
          sourceLang: sourceLanguage,
          searchMode: state.dictionarySearchMode === "precise" ? "precise" : "fast"
        },
        (response) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (!response || !response.ok) {
            reject(new Error(response?.error || "Lookup failed"));
            return;
          }
          resolve(response.payload);
        }
      );
    });
  }

  function formatLookupDefinition(payload) {
    const definitions = Array.isArray(payload.definitions) ? payload.definitions : [];
    return formatDefinitionLines(definitions);
  }

  function formatDefinitionLines(definitions) {
    if (!definitions.length) {
      return t("manualDefinition");
    }

    return definitions
      .map((definition, index) => `${index + 1}. ${definition}`)
      .join("\n");
  }

  async function saveCurrentWord() {
    if (runtime.activeView !== "dictionary" || !runtime.lookup?.word) {
      toast(t("dictionary"));
      return;
    }

    const definitionField = $("#de-dict-definition");
    const deckSelect = $("#de-dict-deck");
    const newDeckInput = $("#de-new-deck-name");
    const meaningLang = runtime.lookup.activeMeaningLang || activeMeaningLang();
    const lookupResult = runtime.lookup.results?.[meaningLang] || {};
    const displayResult = dictionaryDisplayResult(lookupResult);

    let deckId = deckSelect ? deckSelect.value : "";
    if (deckId === "NEW_DECK") {
      const name = newDeckInput.value.trim();
      if (!name) {
        newDeckInput.focus();
        return;
      }
      deckId = createDeck(name, sourceLang()).id;
    }

    if (!deckId) {
      deckId = ensureDeckForCurrentLanguage().id;
    }

    const word = runtime.lookup.word.trim();
    const normalized = normalizeWord(word);
    const sourceLanguage = runtime.lookup.sourceLang || sourceLang();
    const existing = state.vocab.find((item) => localVocabKey(item) === localVocabKey({
      normalized,
      deckId,
      lang: sourceLanguage,
      meaningLang
    }));
    const now = Date.now();
    const payload = {
      id: existing?.id || `word_${now}`,
      word,
      normalized,
      definition: definitionField ? definitionField.value.trim() : displayResult.definition,
      phonetic: lookupResult.phonetic || "",
      examples: displayResult.examples || [],
      deckId,
      lang: sourceLanguage,
      meaningLang,
      level: existing?.level || 0,
      stats: existing?.stats || { seen: 0, correct: 0, wrong: 0 },
      createdAt: existing?.createdAt || now,
      updatedAt: now
    };

    if (existing) {
      Object.assign(existing, payload);
    } else {
      state.vocab.push(payload);
    }

    runtime.currentDeckId = deckId;
    await saveState();
    fillLanguageSelects();
    renderAll();
    toast(t("saved"));
  }

  function openDeck(deckId) {
    runtime.currentDeckId = deckId;
    setView("deck");
  }

  function openEditModal(wordId) {
    runtime.editingWordId = wordId;
    renderEditModal();
    $("#de-edit-modal").classList.add("is-open");
  }

  function closeEditModal() {
    runtime.editingWordId = null;
    $("#de-edit-modal").classList.remove("is-open");
  }

  async function saveEditModal() {
    const word = getWord(runtime.editingWordId);
    if (!word) {
      closeEditModal();
      return;
    }

    const nextWord = $("#de-edit-word").value.trim();
    const nextDefinition = $("#de-edit-definition").value.trim();
    const nextDeckId = $("#de-edit-deck").value || word.deckId;
    const nextNotes = $("#de-edit-notes") ? $("#de-edit-notes").value.trim() : "";
    const selectedLevel = $(".de-level-option.is-active");

    word.word = nextWord || word.word;
    word.normalized = normalizeWord(word.word);
    word.definition = nextDefinition || word.definition;
    word.notes = nextNotes;
    word.level = selectedLevel ? Number(selectedLevel.dataset.rate) : word.level;
    word.deckId = nextDeckId;
    word.updatedAt = Date.now();

    runtime.currentDeckId = nextDeckId;
    await saveState();
    closeEditModal();
    renderAll();
  }

  async function deleteEditWord() {
    if (!runtime.editingWordId) {
      return;
    }

    state.vocab = state.vocab.filter((word) => word.id !== runtime.editingWordId);
    await saveState();
    closeEditModal();
    renderAll();
  }

  function startTest() {
    const deck = getCurrentDeck();
    if (!deck) {
      toast(t("startTestHint"));
      setView("home");
      return;
    }

    const words = shuffle(getWordsByDeck(deck.id)).slice(0, clampBatchSize(state.testBatchSize));
    if (!words.length) {
      toast(t("emptyWords"));
      setView("deck");
      return;
    }

    const questions = buildTestQuestions(words);

    runtime.test = {
      deckId: deck.id,
      words,
      questions,
      index: 0,
      score: 0,
      possibleScore: questions.length,
      pendingCorrect: false,
      pendingRate: 0,
      pendingAnswered: false,
      revealed: false
    };
    setView("test-run");
  }

  function buildTestQuestions(words) {
    const modes = words.length > 1 ? ["card", "choice", "spell"] : ["card", "spell"];
    const questionsByWord = words.map((word) => ({
      word,
      modes: shuffle(modes).slice(0, 2)
    }));
    const queue = [];
    let rounds = Math.max(...questionsByWord.map((item) => item.modes.length), 0);

    for (let round = 0; round < rounds; round += 1) {
      shuffle(questionsByWord).forEach((item) => {
        const mode = item.modes[round];
        if (mode) {
          queue.push({ wordId: item.word.id, mode });
        }
      });
    }

    return spaceTestQuestions(queue);
  }

  function spaceTestQuestions(questions) {
    const remaining = questions.slice();
    const spaced = [];

    while (remaining.length) {
      const lastWordId = spaced[spaced.length - 1]?.wordId || "";
      let bestIndex = 0;
      let bestDistance = -1;

      remaining.forEach((question, index) => {
        if (question.wordId === lastWordId && remaining.some((item) => item.wordId !== lastWordId)) {
          return;
        }
        const previousIndex = spaced.map((item) => item.wordId).lastIndexOf(question.wordId);
        const distance = previousIndex === -1 ? Number.POSITIVE_INFINITY : spaced.length - previousIndex;
        if (distance > bestDistance) {
          bestDistance = distance;
          bestIndex = index;
        }
      });

      spaced.push(remaining.splice(bestIndex, 1)[0]);
    }

    return spaced;
  }

  function answerCurrentQuestion(isCorrect) {
    if (!runtime.test) {
      return;
    }

    if (runtime.test.pendingAnswered) {
      return;
    }

    if (isCorrect) {
      runtime.test.score += 1;
    }

    const current = getCurrentTestWord();
    runtime.test.pendingCorrect = Boolean(isCorrect);
    runtime.test.pendingAnswered = true;
    runtime.test.pendingRate = isCorrect ? Math.max(Number(current?.level || 0), 4) : 0;
    setView("proficiency");
  }

  function submitSpellingAnswer() {
    const input = $("#de-spell-input");
    if (!input || !runtime.test) {
      return;
    }

    const current = getCurrentTestWord();
    if (!current) {
      return;
    }
    const answer = normalizeWord(input.value);
    answerCurrentQuestion(answer === current.normalized);
  }

  function speakLookupWord() {
    if (!runtime.lookup?.word) {
      return;
    }
    speakText(runtime.lookup.word, runtime.lookup.sourceLang || sourceLang());
  }

  function speakCurrentTestWord() {
    const word = getCurrentTestWord();
    if (!word) {
      return;
    }
    speakText(word.word, word.lang || sourceLang());
  }

  function revealCard() {
    if (!runtime.test) {
      return;
    }

    runtime.test.revealed = true;
    renderTestRun();
  }

  function setPendingRate(rate) {
    if (!runtime.test) {
      return;
    }
    runtime.test.pendingRate = rate;
    renderProficiency();
  }

  function setEditRate(trigger) {
    const row = trigger.closest(".de-level-row");
    if (!row) {
      return;
    }
    row.querySelectorAll(".de-level-option").forEach((button) => button.classList.remove("is-active"));
    trigger.classList.add("is-active");
  }

  async function goNextQuestion() {
    if (!runtime.test) {
      return;
    }

    const word = getCurrentTestWord();
    if (word) {
      word.stats = word.stats || { seen: 0, correct: 0, wrong: 0 };
      word.stats.seen += 1;
      if (runtime.test.pendingCorrect) {
        word.stats.correct += 1;
        word.level = runtime.test.pendingRate || word.level || 4;
      } else {
        word.stats.wrong += 1;
      }
      word.updatedAt = Date.now();
      await saveState();
    }

    runtime.test.index += 1;
    runtime.test.revealed = false;
    runtime.test.pendingRate = 0;
    runtime.test.pendingAnswered = false;
    runtime.test.pendingCorrect = false;

    if (runtime.test.index >= runtime.test.questions.length) {
      setView("test-result");
    } else {
      setView("test-run");
    }
  }

  function finishTest() {
    const deckId = runtime.test?.deckId || runtime.currentDeckId;
    runtime.test = null;
    if (deckId) {
      runtime.currentDeckId = deckId;
      setView("deck");
    } else {
      setView("home");
    }
  }

  async function resetData() {
    if (!window.confirm(t("resetConfirm"))) {
      return;
    }

    const previousUiLang = state.uiLang;
    const previousTheme = state.theme;
    state = clone(DEFAULT_STATE);
    state.uiLang = previousUiLang;
    state.theme = previousTheme;
    state.sourceLang = "en";
    state.targetLang = "en";
    state.currentDictLang = "en";
    state.targetLangs = ["ko"];
    state.currentMeaningLang = "ko";
    ensureDeckForCurrentLanguage();
    runtime.currentDeckId = state.decks[0].id;
    runtime.lookup = null;
    runtime.test = null;
    await saveState();
    fillLanguageSelects();
    renderAll();
  }

  function renderAll() {
    renderStaticText();
    renderMenu();
    renderHome();
    renderDictionary();
    renderDeck();
    renderExport();
    renderExportGuide();
    renderSync();
    renderTestSetup();
    renderTestRun();
    renderProficiency();
    renderTestResult();
    renderSettings();
    renderEditModal();
  }

  function renderStaticText() {
    host.classList.toggle("de-rtl", tLang() === "fa");
    host.setAttribute("lang", tLang());
    host.setAttribute("dir", tLang() === "fa" ? "rtl" : "ltr");
    $("#de-brand-label").textContent = t("appName");
    $("#de-search-input").placeholder = t("searchPlaceholder");
    $("#de-menu-title").textContent = t("menu");
    $("#de-menu-meaning-label").textContent = t("menuLanguage");
    $("#de-tooltip-content").innerHTML = renderTooltipContent();
    $$("[data-i18n]").forEach((node) => {
      node.textContent = t(node.dataset.i18n);
    });
    renderBottomLeft();
  }

  function renderMenu() {
    $("#de-menu").classList.toggle("is-open", runtime.menuOpen);
    $("#de-menu-language-card").innerHTML = renderLanguageCardContent(sourceLang());
    $("#de-menu-language-options").classList.toggle("is-open", runtime.languageMenuOpen);
    $("#de-menu-language-options").innerHTML = renderLanguageOptions();
  }

  function renderBottomLeft() {
    const button = $("#de-bottom-left");
    const isHome = runtime.activeView === "home";
    button.innerHTML = isHome ? ICONS.close : ICONS.back;
    button.classList.toggle("is-close", isHome);
    button.setAttribute("aria-label", isHome ? t("closePanel") : t("back"));
  }

  function renderTooltipContent() {
    const mark = `<span class="de-tooltip-mark">${ICONS.book}</span>`;
    if (tLang() === "ko") {
      return `${mark}<span>${escapeHtml(t("selectWord"))}</span>`;
    }
    return `<span>${escapeHtml(t("selectWord"))}</span>${mark}`;
  }

  function renderLanguageCardContent(langCode) {
    return `
      ${flagIcon(langCode)}
      <span>
        <strong>${escapeHtml(languageLabel(langCode))}</strong>
        <span>${escapeHtml(t("changeLanguage"))}</span>
      </span>
      <span aria-hidden="true">${directionalChevron()}</span>
    `;
  }

  function renderLanguageOptions() {
    return LANGUAGES.map((lang) => `
      <button class="de-language-option ${lang.code === sourceLang() ? "is-active" : ""}" data-action="set-target-language" data-lang="${escapeAttr(lang.code)}" type="button">
        ${flagIcon(lang.code, true)}
        <span>${escapeHtml(languageLabel(lang.code))}</span>
        <span>${lang.code === sourceLang() ? ICONS.check : ""}</span>
      </button>
    `).join("");
  }

  function renderMeaningLanguageCardContent() {
    const langs = getMeaningLanguages();
    const primary = langs.map((langCode) => languageLabel(langCode)).join(", ");
    const hiddenCount = Math.max(0, langs.length - 3);
    return `
      <span class="de-meaning-content">
        <span class="de-meaning-line">
          <span class="de-meaning-summary">
            ${langs.slice(0, 3).map((langCode) => flagIcon(langCode, true)).join("")}
            ${hiddenCount ? `<span class="de-meaning-more" aria-label="+${hiddenCount}">⋯</span>` : ""}
          </span>
          <strong>${escapeHtml(primary)}</strong>
        </span>
        <span class="de-meaning-help">${escapeHtml(t("chooseMeaningLanguages"))}</span>
      </span>
      <span aria-hidden="true">${directionalChevron()}</span>
    `;
  }

  function renderMeaningLanguageOptions() {
    const selected = getMeaningLanguages();
    return LANGUAGES.map((lang) => `
      <button class="de-language-option ${selected.includes(lang.code) ? "is-active" : ""}" data-action="toggle-meaning-language" data-lang="${escapeAttr(lang.code)}" type="button">
        ${flagIcon(lang.code, true)}
        <span>${escapeHtml(languageLabel(lang.code))}</span>
        <span>${selected.includes(lang.code) ? ICONS.check : ""}</span>
      </button>
    `).join("");
  }

  function renderEmptyState(title, body, actionLabel = "", action = "") {
    return `
      <div class="de-empty-state">
        <span class="de-empty-icon">${ICONS.book}</span>
        <div>
          <strong>${escapeHtml(title)}</strong>
          <p>${escapeHtml(body)}</p>
        </div>
        ${actionLabel && action ? `<button class="de-secondary-button" data-action="${escapeAttr(action)}" type="button">${escapeHtml(actionLabel)}</button>` : ""}
      </div>
    `;
  }

  function renderProgressBar(value) {
    const safeValue = Math.max(0, Math.min(100, Number(value) || 0));
    return `
      <span class="de-progress" aria-hidden="true">
        <span class="de-progress-fill" style="--de-progress:${safeValue}%;"></span>
      </span>
    `;
  }

  function percent(value, total) {
    const denominator = Number(total) || 0;
    if (!denominator) {
      return 0;
    }
    return Math.round((Number(value) || 0) / denominator * 100);
  }

  function renderHome() {
    const decks = getDecksForCurrentLanguage();
    const currentSourceLang = sourceLang();
    const totalWords = state.vocab.filter((word) => word.lang === currentSourceLang).length;
    const reviewed = state.vocab.filter((word) => word.lang === currentSourceLang && word.stats?.seen > 0).length;
    const known = state.vocab.filter((word) => word.lang === currentSourceLang && Number(word.level) >= 4).length;
    const knownPercent = percent(known, totalWords);

    $("#de-view-home").innerHTML = `
      <div class="de-home-language">
        <button class="de-language-card" data-action="toggle-language-list" type="button">
          ${renderLanguageCardContent(currentSourceLang)}
        </button>
        <div class="de-language-options ${runtime.languageMenuOpen ? "is-open" : ""}">
          ${renderLanguageOptions()}
        </div>
      </div>
      <div class="de-title-row">
        <h2 class="de-title">${escapeHtml(t("decks"))}</h2>
        <button class="de-secondary-button" data-action="go-settings" type="button">${escapeHtml(t("settings"))}</button>
      </div>
      <div class="de-stat-row">
        <div class="de-stat"><strong>${decks.length}</strong><span>${escapeHtml(t("decks"))}</span></div>
        <div class="de-stat"><strong>${totalWords}</strong><span>${escapeHtml(t("words"))}</span></div>
        <div class="de-stat"><strong>${known}</strong><span>${escapeHtml(t("knownWords"))}</span></div>
      </div>
      ${totalWords ? `
        <div class="de-progress-panel">
          <span class="de-progress-panel-head">
            <span>${escapeHtml(t("knownRatio"))}</span>
            <span>${knownPercent}%</span>
          </span>
          ${renderProgressBar(knownPercent)}
          <p class="de-sub" style="margin:9px 0 0;">${reviewed} / ${totalWords} ${escapeHtml(t("reviewedWords"))}</p>
        </div>
      ` : renderEmptyState(t("emptyHomeTitle"), t("emptyHomeBody"), t("searchAction"), "focus-search")}
      <div class="de-grid">
        ${decks.map((deck) => renderDeckCard(deck)).join("")}
      </div>
    `;
  }

  function renderDeckCard(deck) {
    const words = getWordsByDeck(deck.id);
    const known = words.filter((word) => Number(word.level) >= 4).length;
    const knownPercent = percent(known, words.length);
    return `
      <button class="de-card" data-action="open-deck" data-deck-id="${escapeAttr(deck.id)}" type="button">
        <span class="de-card-head">
          <span class="de-card-title">${escapeHtml(deck.name)}</span>
          <span class="de-card-meta">${words.length} ${escapeHtml(t("words"))}</span>
        </span>
        <span class="de-sub">${flagIcon(deck.lang, true)} <span style="vertical-align:middle;">${escapeHtml(languageLabel(deck.lang))} · ${known} ${escapeHtml(t("learned"))}</span></span>
        <span class="de-card-progress">
          <span>${escapeHtml(t("knownRatio"))}</span>
          <span>${knownPercent}%</span>
        </span>
        ${renderProgressBar(knownPercent)}
      </button>
    `;
  }

  function renderDictionary() {
    const lookup = runtime.lookup || {
      word: t("dictionary"),
      sourceLang: sourceLang(),
      activeMeaningLang: activeMeaningLang(),
      results: {}
    };
    const meaningLang = lookup.activeMeaningLang || activeMeaningLang();
    const result = lookup.results?.[meaningLang] || {
      phonetic: "",
      definition: "",
      examples: [],
      sources: [],
      activeSourceId: "all",
      status: "",
      loading: false
    };
    const displayResult = dictionaryDisplayResult(result);
    const deck = ensureDeckForCurrentLanguage();
    const decks = getDecksForCurrentLanguage();
    const statusText = [result.phonetic, result.status || ""]
      .filter(Boolean)
      .join(" · ");

    $("#de-view-dictionary").innerHTML = `
      <div class="de-dict-heading">
        <h2 class="de-dict-word" dir="auto">${escapeHtml(lookup.word)}</h2>
        <button class="de-speak-button" data-action="speak-lookup" type="button" aria-label="${escapeAttr(t("listen"))}" title="${escapeAttr(t("listen"))}">
          ${ICONS.speaker}
        </button>
      </div>
      <div class="de-dict-status">${escapeHtml(statusText)}</div>
      <div class="de-dict-form">
        ${renderDictionaryLanguageTabs(meaningLang)}
        ${renderDictionarySourceTabs(result)}
        <label class="de-label" for="de-dict-definition">${escapeHtml(t("meanings"))}</label>
        <textarea class="de-textarea" id="de-dict-definition" dir="auto" ${result.loading ? "disabled" : ""}>${escapeHtml(displayResult.definition || "")}</textarea>
        ${renderExamples(displayResult.examples)}
        <div class="de-dict-actions">
          <div>
            <label class="de-label" for="de-dict-deck">${escapeHtml(t("chooseDeck"))}</label>
            <select class="de-select" id="de-dict-deck">
              ${decks.map((item) => `<option value="${escapeAttr(item.id)}" ${item.id === deck.id ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}
              <option value="NEW_DECK">${escapeHtml(t("newDeck"))}</option>
            </select>
            <input class="de-input de-hidden" id="de-new-deck-name" type="text" placeholder="${escapeAttr(t("newDeckPlaceholder"))}" dir="auto" />
          </div>
          <button class="de-round-button" data-action="save-word" type="button" aria-label="${escapeAttr(t("save"))}">${ICONS.check}</button>
        </div>
      </div>
    `;
  }

  function renderDictionaryLanguageTabs(activeLang) {
    const langs = getMeaningLanguages();
    return `
      <div class="de-dict-language-bar">
        <span class="de-label">${escapeHtml(t("meaningLanguages"))}</span>
        <div class="de-dict-language-tabs">
          ${langs.map((langCode) => `
            <button class="de-dict-lang-tab ${langCode === activeLang ? "is-active" : ""}" data-action="set-lookup-language" data-lang="${escapeAttr(langCode)}" type="button">
              ${flagIcon(langCode, true)}
              <span>${escapeHtml(languageLabel(langCode))}</span>
            </button>
          `).join("")}
        </div>
      </div>
    `;
  }

  function renderDictionarySourceTabs(result) {
    const sources = Array.isArray(result.sources) ? result.sources : [];
    if (result.loading || !sources.length) {
      return "";
    }

    const activeSourceId = result.activeSourceId || "all";
    const sourceOptions = [
      { id: "all", label: t("allSources") },
      ...sources.map((source) => ({ id: source.id, label: source.label }))
    ];

    return `
      <div class="de-dict-language-bar">
        <span class="de-label">${escapeHtml(t("dictionarySources"))}</span>
        <div class="de-dict-language-tabs">
          ${sourceOptions.map((source) => `
            <button class="de-dict-lang-tab ${source.id === activeSourceId ? "is-active" : ""}" data-action="set-lookup-source" data-source="${escapeAttr(source.id)}" type="button">
              <span>${escapeHtml(source.label)}</span>
            </button>
          `).join("")}
        </div>
      </div>
    `;
  }

  function renderExamples(examples) {
    if (!Array.isArray(examples) || !examples.length) {
      return "";
    }

    return `
      <div class="de-examples">
        <h4>${escapeHtml(t("examples"))}</h4>
        ${examples.map((example) => `<p dir="auto">${escapeHtml(example)}</p>`).join("")}
      </div>
    `;
  }

  function renderDeck() {
    const deck = getCurrentDeck();
    const container = $("#de-view-deck");

    if (!deck) {
      container.innerHTML = `
        <div class="de-title-row">
          <h2 class="de-title">${escapeHtml(t("vocabulary"))}</h2>
        </div>
        <p class="de-sub">${escapeHtml(t("emptyDecks"))}</p>
      `;
      return;
    }

    const words = getWordsByDeck(deck.id).slice().sort((a, b) => b.updatedAt - a.updatedAt);
    const known = words.filter((word) => Number(word.level) >= 4).length;
    const knownPercent = percent(known, words.length);
    const canStartTest = words.length > 0;

    container.innerHTML = `
      <div class="de-title-row">
        <div>
          <h2 class="de-title">${escapeHtml(deck.name)}</h2>
          <div class="de-sub">${flagIcon(deck.lang, true)} <span style="vertical-align:middle;">${words.length} ${escapeHtml(t("words"))} · ${escapeHtml(languageLabel(deck.lang))}</span></div>
        </div>
        <div class="de-title-actions">
          <button class="de-secondary-button" data-action="go-export" type="button">${escapeHtml(t("share"))}</button>
          <button class="de-primary-button" data-action="start-test" type="button" ${canStartTest ? "" : "disabled"} title="${escapeAttr(canStartTest ? t("integratedTest") : t("notEnoughWords"))}">${escapeHtml(t("integratedTest"))}</button>
        </div>
      </div>
      ${words.length ? `
        <div class="de-progress-panel">
          <span class="de-progress-panel-head">
            <span>${escapeHtml(t("knownRatio"))}</span>
            <span>${knownPercent}%</span>
          </span>
          ${renderProgressBar(knownPercent)}
        </div>
      ` : ""}
      <div class="de-grid">
        ${words.length ? words.map((word) => renderWordCard(word)).join("") : renderEmptyState(t("emptyDeckTitle"), t("searchToAddWords"))}
      </div>
    `;
  }

  function renderWordCard(word) {
    const firstLine = firstDefinitionLine(word.definition);
    return `
      <button class="de-card" data-action="open-word" data-word-id="${escapeAttr(word.id)}" type="button">
        <span class="de-word-row">
          <span>
            <span class="de-card-title" dir="auto">${escapeHtml(word.word)}</span>
            <span class="de-word-def" dir="auto">${escapeHtml(firstLine)}</span>
          </span>
          <span class="de-level ${word.level ? "is-filled" : ""}">${word.level || "-"}</span>
        </span>
      </button>
    `;
  }

  function renderExport() {
    const deck = getCurrentDeck();
    const words = deck ? getWordsByDeck(deck.id) : [];

    $("#de-view-export").innerHTML = `
      <div class="de-title-row">
        <div>
          <h2 class="de-title">${escapeHtml(t("exportVocabulary"))}</h2>
          <div class="de-sub">${escapeHtml(deck?.name || t("vocabulary"))} · ${words.length} ${escapeHtml(t("words"))}</div>
        </div>
      </div>
      <p class="de-sub" style="margin-bottom:14px;">${escapeHtml(t("exportSubtitle"))}</p>
      <div class="de-grid">
        <button class="de-card" data-action="export-anki" type="button">
          <span class="de-card-head">
            <span class="de-card-title">${escapeHtml(t("ankiExport"))}</span>
            <span class="de-card-meta">TSV</span>
          </span>
          <span class="de-sub">${escapeHtml(t("ankiGuide1"))}</span>
        </button>
        <button class="de-card" data-action="export-quizlet" type="button">
          <span class="de-card-head">
            <span class="de-card-title">${escapeHtml(t("quizletExport"))}</span>
            <span class="de-card-meta">Copy</span>
          </span>
          <span class="de-sub">${escapeHtml(t("quizletGuide2"))}</span>
        </button>
        <button class="de-card" data-action="export-lingq" type="button">
          <span class="de-card-head">
            <span class="de-card-title">${escapeHtml(t("lingqExport"))}</span>
            <span class="de-card-meta">CSV</span>
          </span>
          <span class="de-sub">${escapeHtml(t("lingqGuide2"))}</span>
        </button>
      </div>
    `;
  }

  function renderExportGuide() {
    const guide = runtime.exportGuide || exportGuideContent("anki", "");
    const linkButton = guide.url
      ? `<button class="de-secondary-button" data-action="open-export-link" data-url="${escapeAttr(guide.url)}" type="button">${escapeHtml(guide.openLabel)}</button>`
      : "";

    $("#de-view-export-guide").innerHTML = `
      <div class="de-title-row">
        <div>
          <h2 class="de-title">${escapeHtml(guide.title)}</h2>
          <div class="de-sub">${escapeHtml(guide.status || t("exportReady"))}</div>
        </div>
      </div>
      <div class="de-card" style="cursor:default;">
        <ol class="de-guide-list">
          ${guide.steps.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}
        </ol>
      </div>
      <div class="de-action-row" style="margin-top:14px;">
        ${linkButton}
        <button class="de-primary-button" data-action="go-export" type="button">${escapeHtml(t("exportVocabulary"))}</button>
      </div>
    `;
  }

  async function exportCurrentDeck(type) {
    const deck = getCurrentDeck();
    const words = deck ? getWordsByDeck(deck.id).slice().sort((a, b) => a.word.localeCompare(b.word)) : [];

    if (!words.length) {
      toast(t("exportEmpty"));
      return;
    }

    const filenameBase = safeFilename(`DictionEvery-${deck.name}-${deck.lang}`);
    let status = t("exportReady");

    if (type === "anki") {
      downloadTextFile(`${filenameBase}-anki.tsv`, buildAnkiTsv(words), "text/tab-separated-values;charset=utf-8");
      status = t("exportDownloaded");
    } else if (type === "quizlet") {
      await copyText(buildQuizletImportText(words));
      status = t("exportCopied");
    } else if (type === "lingq") {
      downloadTextFile(`${filenameBase}-lingq.csv`, buildLingqCsv(words), "text/csv;charset=utf-8");
      status = t("exportDownloaded");
    }

    runtime.exportGuide = exportGuideContent(type, status);
    setView("export-guide");
  }

  function buildAnkiTsv(words) {
    return words.map((word) => [
      compactText([word.word, word.phonetic].filter(Boolean).join(" ")),
      compactText([firstDefinitionLine(word.definition), firstExample(word)].filter(Boolean).join(" | "))
    ].map(tsvCell).join("\t")).join("\n");
  }

  function buildQuizletImportText(words) {
    return words.map((word) => [
      compactText(word.word),
      compactText([firstDefinitionLine(word.definition), firstExample(word)].filter(Boolean).join(" | "))
    ].map(tsvCell).join("\t")).join("\n");
  }

  function buildLingqCsv(words) {
    const rows = [
      ["term", "phrase", "tag1", "tag2", "meaninglanguage1", "meaning1", "meaninglanguage2", "meaning2"]
    ];

    words.forEach((word) => {
      rows.push([
        compactText(word.word),
        compactText(firstExample(word)),
        "DictionEvery",
        compactText(word.lang || sourceLang()),
        compactText(word.meaningLang || activeMeaningLang()),
        compactText(firstDefinitionLine(word.definition)),
        "",
        ""
      ]);
    });

    return rows.map((row) => row.map(csvCell).join(",")).join("\n");
  }

  function exportGuideContent(type, status) {
    if (type === "quizlet") {
      return {
        title: t("quizletGuideTitle"),
        status,
        steps: [t("quizletGuide1"), t("quizletGuide2"), t("quizletGuide3")],
        url: "https://quizlet.com/create-set",
        openLabel: t("openQuizlet")
      };
    }

    if (type === "lingq") {
      return {
        title: t("lingqGuideTitle"),
        status,
        steps: [t("lingqGuide1"), t("lingqGuide2"), t("lingqGuide3")],
        url: "https://www.lingq.com/",
        openLabel: t("openLingq")
      };
    }

    return {
      title: t("ankiGuideTitle"),
      status,
      steps: [t("ankiGuide1"), t("ankiGuide2"), t("ankiGuide3")],
      url: "",
      openLabel: ""
    };
  }

  function firstExample(word) {
    return Array.isArray(word.examples) ? word.examples.find(Boolean) || "" : "";
  }

  function compactText(value) {
    return String(value || "")
      .replace(/\t/g, " ")
      .replace(/\r?\n/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function tsvCell(value) {
    return compactText(value);
  }

  function csvCell(value) {
    const text = compactText(value).replace(/"/g, "\"\"");
    return /[",\n]/.test(text) ? `"${text}"` : text;
  }

  function downloadTextFile(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function copyText(value) {
    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(value);
        return;
      } catch (_error) {
        // Fall through to the textarea copy path.
      }
    }

    const textarea = document.createElement("textarea");
    textarea.value = value;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }

  function openExportLink(url) {
    if (!url) {
      return;
    }
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function safeFilename(value) {
    return String(value || "DictionEvery")
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 80);
  }

  function renderSync() {
    const sync = runtime.sync || {};
    const configured = Boolean(sync.configured);
    const config = sync.config || {};
    const signedIn = Boolean(sync.session?.user?.id);
    const email = sync.session?.user?.email || "";
    const busy = Boolean(sync.busy);
    const localCount = state.vocab.length;
    const status = sync.status ||
      (configured
        ? signedIn
          ? `${t("syncLoggedInAs")} · ${email || sync.session.user.id}`
          : t("syncLoggedOut")
        : t("syncConfiguredMissing"));

    $("#de-view-sync").innerHTML = `
      <div class="de-title-row">
        <div>
          <h2 class="de-title">${escapeHtml(t("syncTitle"))}</h2>
          <div class="de-sub">${escapeHtml(t("syncSubtitle"))}</div>
        </div>
      </div>
      <div class="de-grid">
        <div class="de-sync-status">
          <strong>${escapeHtml(signedIn ? t("syncLoggedInAs") : t("syncLoggedOut"))}</strong>
          <span>${escapeHtml(status)}</span>
        </div>
        <div class="de-card" style="cursor:default;">
          <span class="de-card-head">
            <span class="de-card-title">${escapeHtml(t("syncSetupTitle"))}</span>
            <span class="de-card-meta">${escapeHtml(configured ? t("syncConfigReady") : "Supabase")}</span>
          </span>
          <p class="de-info-note" style="margin:10px 0 12px;">${escapeHtml(t("syncConfigHint"))}</p>
          <div class="de-grid">
            <label>
              <span class="de-label">${escapeHtml(t("supabaseUrl"))}</span>
              <input class="de-input" id="de-sync-url" type="url" dir="ltr" autocomplete="off" placeholder="https://xxxx.supabase.co" value="${escapeAttr(config.url || "")}" />
            </label>
            <label>
              <span class="de-label">${escapeHtml(t("supabaseAnonKey"))}</span>
              <input class="de-input" id="de-sync-anon-key" type="password" dir="ltr" autocomplete="off" placeholder="${escapeAttr(config.anonKeyPreview || "eyJ...")}" />
            </label>
            <label>
              <span class="de-label">${escapeHtml(t("supabaseTable"))}</span>
              <input class="de-input" id="de-sync-table" type="text" dir="ltr" autocomplete="off" value="${escapeAttr(config.table || "dictionevery_words")}" />
            </label>
            ${sync.redirectUrl ? `
              <div class="de-sync-status">
                <strong>${escapeHtml(t("syncRedirectUrl"))}</strong>
                <span dir="ltr" style="word-break:break-all;">${escapeHtml(sync.redirectUrl)}</span>
              </div>
            ` : ""}
            <div class="de-action-row" style="margin-top:4px;">
              <button class="de-secondary-button" data-action="sync-clear-config" type="button" ${busy || !configured ? "disabled" : ""}>${escapeHtml(t("resetSyncConfig"))}</button>
              <button class="de-secondary-button" data-action="sync-test-config" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("syncTestConnection"))}</button>
              <button class="de-primary-button" data-action="sync-save-config" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("saveSyncConfig"))}</button>
            </div>
          </div>
        </div>
        ${configured && !signedIn ? `
          <label>
            <span class="de-label">${escapeHtml(t("email"))}</span>
            <input class="de-input" id="de-sync-email" type="email" autocomplete="email" dir="ltr" />
          </label>
          <label>
            <span class="de-label">${escapeHtml(t("password"))}</span>
            <input class="de-input" id="de-sync-password" type="password" autocomplete="current-password" dir="ltr" />
          </label>
          <div class="de-action-row" style="margin-top:4px;">
            <button class="de-secondary-button" data-action="sync-sign-up" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("signUp"))}</button>
            <button class="de-primary-button" data-action="sync-sign-in" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("signIn"))}</button>
          </div>
          <button class="de-secondary-button" data-action="sync-google" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("googleSignIn"))}</button>
        ` : ""}
        ${signedIn ? `
          <div class="de-card" style="cursor:default;">
            <span class="de-card-head">
              <span class="de-card-title">${escapeHtml(email || t("syncLoggedInAs"))}</span>
              <span class="de-card-meta">${localCount} ${escapeHtml(t("syncLocalCount"))}</span>
            </span>
            <p class="de-info-note" style="margin:10px 0 0;">${escapeHtml(t("syncManualHint"))}</p>
          </div>
          <div class="de-sync-actions">
            <button class="de-secondary-button" data-action="sync-download" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("syncDownload"))}</button>
            <button class="de-secondary-button" data-action="sync-upload" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("syncUpload"))}</button>
            <button class="de-primary-button" data-action="sync-merge" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("syncMerge"))}</button>
          </div>
          <button class="de-secondary-button" data-action="sync-sign-out" type="button" ${busy ? "disabled" : ""}>${escapeHtml(t("signOut"))}</button>
        ` : ""}
        <p class="de-info-note">${escapeHtml(configured ? t("syncLatestWins") : t("syncConfiguredMissing"))}</p>
      </div>
    `;
  }

  async function loadSyncStatus() {
    try {
      const payload = await syncViaBackground("status");
      runtime.sync.configured = Boolean(payload.configured);
      runtime.sync.config = payload.config || null;
      runtime.sync.redirectUrl = payload.redirectUrl || "";
      runtime.sync.session = payload.session || null;
      if (!runtime.sync.status) {
        runtime.sync.status = "";
      }
      renderSync();
    } catch (error) {
      runtime.sync.configured = false;
      runtime.sync.config = null;
      runtime.sync.redirectUrl = "";
      runtime.sync.session = null;
      runtime.sync.status = error.message || t("syncConfiguredMissing");
      renderSync();
    }
  }

  async function saveSyncConfig() {
    const config = readSyncConfigFields();
    if (!config) {
      return;
    }

    await runConfigOperation(async () => {
      const payload = await syncViaBackground("save-config", {
        config,
        keepAnonKey: Boolean(config.keepAnonKey)
      });
      runtime.sync.configured = Boolean(payload.configured);
      runtime.sync.config = payload.config || null;
      runtime.sync.redirectUrl = payload.redirectUrl || "";
      runtime.sync.session = null;
      runtime.sync.status = t("syncConfigSaved");
    });
  }

  async function clearSyncConfig() {
    await runConfigOperation(async () => {
      const payload = await syncViaBackground("clear-config");
      runtime.sync.configured = Boolean(payload.configured);
      runtime.sync.config = payload.config || null;
      runtime.sync.redirectUrl = payload.redirectUrl || "";
      runtime.sync.session = null;
      runtime.sync.status = t("syncConfiguredMissing");
    });
  }

  async function testSyncConfig() {
    const config = readSyncConfigFields();
    if (!config) {
      return;
    }

    await runConfigOperation(async () => {
      const payload = await syncViaBackground("test-config", {
        config,
        keepAnonKey: Boolean(config.keepAnonKey)
      });
      runtime.sync.configured = Boolean(payload.configured);
      runtime.sync.config = payload.config || runtime.sync.config || null;
      runtime.sync.redirectUrl = payload.redirectUrl || runtime.sync.redirectUrl || "";
      runtime.sync.session = payload.session || runtime.sync.session || null;
      runtime.sync.status = t("syncConnectionOk");
    }, t("syncConnectionFailed"));
  }

  async function runConfigOperation(operation, failureLabel = "") {
    runtime.sync.busy = true;
    runtime.sync.status = t("syncBusy");
    renderSync();

    try {
      await operation();
      toast(runtime.sync.status);
    } catch (error) {
      const message = error.message || "Sync failed";
      runtime.sync.status = failureLabel ? `${failureLabel}: ${message}` : message;
      toast(runtime.sync.status);
    } finally {
      runtime.sync.busy = false;
      renderSync();
    }
  }

  function readSyncConfigFields() {
    const url = $("#de-sync-url")?.value.trim() || "";
    const anonKeyInput = $("#de-sync-anon-key")?.value.trim() || "";
    const table = $("#de-sync-table")?.value.trim() || "dictionevery_words";
    const existing = runtime.sync.config || {};
    const anonKey = anonKeyInput || (existing.hasAnonKey ? "" : "");

    if (!url || (!anonKey && !existing.hasAnonKey)) {
      toast(t("syncConfiguredMissing"));
      return null;
    }

    return {
      url,
      anonKey: anonKey || undefined,
      table,
      keepAnonKey: !anonKey && Boolean(existing.hasAnonKey)
    };
  }

  async function signInSync() {
    const credentials = readSyncCredentials();
    if (!credentials) {
      return;
    }
    await runSyncOperation(async () => {
      const payload = await syncViaBackground("sign-in", credentials);
      runtime.sync.session = payload.session || null;
      runtime.sync.status = runtime.sync.session
        ? `${t("syncLoggedInAs")} · ${runtime.sync.session.user.email || ""}`
        : t("syncLoggedOut");
    });
  }

  async function signUpSync() {
    const credentials = readSyncCredentials();
    if (!credentials) {
      return;
    }
    await runSyncOperation(async () => {
      const payload = await syncViaBackground("sign-up", credentials);
      runtime.sync.session = payload.session || null;
      runtime.sync.status = runtime.sync.session
        ? `${t("syncLoggedInAs")} · ${runtime.sync.session.user.email || ""}`
        : t("syncLoggedOut");
    });
  }

  async function googleSignInSync() {
    await runSyncOperation(async () => {
      const payload = await syncViaBackground("google-sign-in");
      runtime.sync.session = payload.session || null;
      runtime.sync.status = runtime.sync.session
        ? `${t("syncLoggedInAs")} · ${runtime.sync.session.user.email || ""}`
        : t("syncLoggedOut");
    });
  }

  async function signOutSync() {
    await runSyncOperation(async () => {
      await syncViaBackground("sign-out");
      runtime.sync.session = null;
      runtime.sync.status = t("syncLoggedOut");
    });
  }

  async function uploadSync() {
    const rows = buildSyncRows();
    if (!rows.length) {
      toast(t("syncNoWords"));
      return;
    }

    await runSyncOperation(async () => {
      const payload = await syncViaBackground("upload", { rows });
      runtime.sync.session = payload.session || runtime.sync.session;
      runtime.sync.status = `${t("syncUploadDone")} · ${payload.uploaded || rows.length}`;
    });
  }

  async function downloadSync() {
    await runSyncOperation(async () => {
      const payload = await syncViaBackground("download");
      runtime.sync.session = payload.session || runtime.sync.session;
      const changed = await mergeRemoteRows(payload.rows || []);
      runtime.sync.status = `${t("syncDownloadDone")} · ${changed} / ${(payload.rows || []).length}`;
    });
  }

  async function mergeSync() {
    await runSyncOperation(async () => {
      const downloaded = await syncViaBackground("download");
      runtime.sync.session = downloaded.session || runtime.sync.session;
      const changed = await mergeRemoteRows(downloaded.rows || []);
      const rows = buildSyncRows();
      const uploaded = rows.length
        ? await syncViaBackground("upload", { rows })
        : { uploaded: 0, session: runtime.sync.session };
      runtime.sync.session = uploaded.session || runtime.sync.session;
      runtime.sync.status = `${t("syncMergeDone")} · ${changed} / ${uploaded.uploaded || 0}`;
    });
  }

  async function runSyncOperation(operation) {
    if (!runtime.sync.configured) {
      runtime.sync.status = t("syncConfiguredMissing");
      renderSync();
      toast(t("syncConfiguredMissing"));
      return;
    }

    runtime.sync.busy = true;
    runtime.sync.status = t("syncBusy");
    renderSync();

    try {
      await operation();
      toast(runtime.sync.status);
    } catch (error) {
      runtime.sync.status = error.message || "Sync failed";
      toast(runtime.sync.status);
    } finally {
      runtime.sync.busy = false;
      renderSync();
    }
  }

  function readSyncCredentials() {
    const email = $("#de-sync-email")?.value.trim() || "";
    const password = $("#de-sync-password")?.value || "";
    if (!email || !password) {
      toast(`${t("email")} / ${t("password")}`);
      return null;
    }
    return { email, password };
  }

  function syncViaBackground(action, payload = {}) {
    if (!hasChromeRuntime()) {
      return Promise.resolve({
        configured: false,
        session: null,
        rows: [],
        uploaded: 0
      });
    }

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: "DE_SYNC", action, payload },
        (response) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (!response || !response.ok) {
            reject(new Error(response?.error || "Sync failed"));
            return;
          }
          resolve(response.payload || {});
        }
      );
    });
  }

  async function loadAiConfigStatus() {
    try {
      const payload = await aiViaBackground("status");
      runtime.ai.config = payload.config || runtime.ai.config;
    } catch (_error) {
      runtime.ai.status = "";
    }
  }

  async function saveAiConfig() {
    const config = readAiConfigForm();
    runtime.ai.busy = true;
    runtime.ai.status = t("aiSaving");
    renderSettings();
    try {
      const payload = await aiViaBackground("save", {
        config,
        keepApiKey: !config.apiKey
      });
      runtime.ai.config = payload.config || runtime.ai.config;
      runtime.ai.status = t("aiConfigSaved");
      toast(runtime.ai.status);
    } catch (error) {
      runtime.ai.status = error.message || t("aiConfigFailed");
      toast(runtime.ai.status);
    } finally {
      runtime.ai.busy = false;
      renderSettings();
    }
  }

  async function testAiConfig() {
    const config = readAiConfigForm();
    runtime.ai.busy = true;
    runtime.ai.status = t("aiTesting");
    renderSettings();
    try {
      const payload = await aiViaBackground("test", {
        config,
        keepApiKey: !config.apiKey
      });
      runtime.ai.config = payload.config || runtime.ai.config;
      runtime.ai.status = t("aiTestOk");
      toast(runtime.ai.status);
    } catch (error) {
      runtime.ai.status = `${t("aiTestFailed")}: ${error.message || "Error"}`;
      toast(runtime.ai.status);
    } finally {
      runtime.ai.busy = false;
      renderSettings();
    }
  }

  async function clearAiConfig() {
    runtime.ai.busy = true;
    runtime.ai.status = "";
    renderSettings();
    try {
      const payload = await aiViaBackground("clear");
      runtime.ai.config = payload.config || runtime.ai.config;
      runtime.ai.status = t("aiConfigCleared");
      toast(runtime.ai.status);
    } catch (error) {
      runtime.ai.status = error.message || t("aiConfigFailed");
      toast(runtime.ai.status);
    } finally {
      runtime.ai.busy = false;
      renderSettings();
    }
  }

  function readAiConfigForm() {
    const provider = $("#de-ai-provider")?.value || runtime.ai.config.provider || "gemini";
    return {
      mode: $("#de-ai-mode")?.value || "off",
      provider,
      apiKey: $("#de-ai-key")?.value.trim() || "",
      model: defaultAiModel(provider),
      accountId: $("#de-ai-account")?.value.trim() || ""
    };
  }

  function aiViaBackground(action, payload = {}) {
    if (!hasChromeRuntime()) {
      return Promise.resolve({
        config: {
          mode: "off",
          provider: "gemini",
          model: "gemini-2.5-flash-lite",
          accountId: "",
          hasApiKey: false,
          apiKeyPreview: ""
        }
      });
    }

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: "DE_AI_CONFIG", action, payload },
        (response) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (!response || !response.ok) {
            reject(new Error(response?.error || "AI setup failed"));
            return;
          }
          resolve(response.payload || {});
        }
      );
    });
  }

  function defaultAiModel(provider) {
    if (provider === "groq") return "llama-3.1-8b-instant";
    if (provider === "huggingface") return "meta-llama/Llama-3.1-8B-Instruct";
    if (provider === "cloudflare") return "@cf/meta/llama-3.1-8b-instruct";
    return "gemini-2.5-flash-lite";
  }

  function buildSyncRows() {
    return state.vocab.map((word) => {
      const payload = wordToSyncPayload(word);
      return {
        syncKey: syncKeyForPayload(payload),
        updatedMs: Number(payload.updatedAt || Date.now()),
        payload
      };
    });
  }

  function wordToSyncPayload(word) {
    const deck = state.decks.find((item) => item.id === word.deckId);
    const wordText = String(word.word || "").trim();
    const lang = isSupportedLanguage(word.lang) ? word.lang : sourceLang();
    const meaningLang = isSupportedLanguage(word.meaningLang) ? word.meaningLang : activeMeaningLang();
    return {
      id: word.id,
      word: wordText,
      normalized: word.normalized || normalizeWord(wordText),
      definition: word.definition || "",
      phonetic: word.phonetic || "",
      examples: Array.isArray(word.examples) ? word.examples : [],
      notes: word.notes || "",
      deckName: deck?.name || "Vocabulary",
      lang,
      sourceLang: lang,
      meaningLang,
      level: Number(word.level || 0),
      stats: word.stats || { seen: 0, correct: 0, wrong: 0 },
      createdAt: Number(word.createdAt || Date.now()),
      updatedAt: Number(word.updatedAt || Date.now())
    };
  }

  async function mergeRemoteRows(rows) {
    let changed = 0;
    const localByKey = new Map(state.vocab.map((word) => [syncKeyForWord(word), word]));

    rows.forEach((row) => {
      const payload = normalizeSyncPayload(row.payload || {}, row.updated_ms);
      if (!payload.word) {
        return;
      }

      const key = row.sync_key || syncKeyForPayload(payload);
      const local = localByKey.get(key);
      const remoteUpdated = Number(row.updated_ms || payload.updatedAt || 0);

      if (!local) {
        const deck = ensureDeckForSyncPayload(payload);
        const nextWord = {
          ...payload,
          id: payload.id || `word_sync_${Date.now()}_${Math.random().toString(16).slice(2)}`,
          deckId: deck.id
        };
        state.vocab.push(nextWord);
        localByKey.set(key, nextWord);
        changed += 1;
        return;
      }

      const localUpdated = Number(local.updatedAt || 0);
      if (remoteUpdated > localUpdated) {
        const deck = ensureDeckForSyncPayload(payload);
        Object.assign(local, {
          ...payload,
          id: local.id,
          deckId: deck.id,
          createdAt: local.createdAt || payload.createdAt
        });
        changed += 1;
      }
    });

    if (changed) {
      await saveState();
      fillLanguageSelects();
      renderAll();
    }
    return changed;
  }

  function normalizeSyncPayload(payload, fallbackUpdatedAt) {
    const word = String(payload.word || "").trim();
    const lang = isSupportedLanguage(payload.lang || payload.sourceLang)
      ? payload.lang || payload.sourceLang
      : sourceLang();
    const meaningLang = isSupportedLanguage(payload.meaningLang)
      ? payload.meaningLang
      : activeMeaningLang();
    const updatedAt = Number(payload.updatedAt || fallbackUpdatedAt || Date.now());

    return {
      id: payload.id ? String(payload.id) : "",
      word,
      normalized: payload.normalized || normalizeWord(word),
      definition: payload.definition || "",
      phonetic: payload.phonetic || "",
      examples: Array.isArray(payload.examples) ? payload.examples : [],
      notes: payload.notes || "",
      deckName: payload.deckName || "Vocabulary",
      lang,
      sourceLang: lang,
      meaningLang,
      level: Number(payload.level || 0),
      stats: payload.stats || { seen: 0, correct: 0, wrong: 0 },
      createdAt: Number(payload.createdAt || updatedAt),
      updatedAt
    };
  }

  function ensureDeckForSyncPayload(payload) {
    const lang = isSupportedLanguage(payload.lang || payload.sourceLang)
      ? payload.lang || payload.sourceLang
      : sourceLang();
    const name = String(payload.deckName || "Vocabulary").trim() || "Vocabulary";
    let deck = state.decks.find((item) => item.lang === lang && item.name === name);
    if (deck) {
      return deck;
    }
    deck = {
      id: `deck_sync_${lang}_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      name,
      lang
    };
    state.decks.push(deck);
    return deck;
  }

  function syncKeyForWord(word) {
    return syncKeyForPayload(wordToSyncPayload(word));
  }

  function localVocabKey(word) {
    const lang = isSupportedLanguage(word.lang || word.sourceLang)
      ? word.lang || word.sourceLang
      : sourceLang();
    const normalized = word.normalized || normalizeWord(word.word);
    const meaningLang = isSupportedLanguage(word.meaningLang)
      ? word.meaningLang
      : activeMeaningLang();
    return [word.deckId || "", lang, normalized, meaningLang].join("|");
  }

  function syncKeyForPayload(payload) {
    const lang = isSupportedLanguage(payload.lang || payload.sourceLang)
      ? payload.lang || payload.sourceLang
      : sourceLang();
    const normalized = payload.normalized || normalizeWord(payload.word);
    const meaningLang = isSupportedLanguage(payload.meaningLang)
      ? payload.meaningLang
      : activeMeaningLang();
    return [lang, normalized, meaningLang].join("|");
  }

  function renderTestSetup() {
    const deck = getCurrentDeck();
    const count = deck ? getWordsByDeck(deck.id).length : 0;
    $("#de-view-test-setup").innerHTML = `
      <div class="de-test-header">
        <button class="de-test-icon" data-action="finish-test" type="button">${ICONS.book}</button>
        <div class="de-test-progress">${escapeHtml(deck?.name || t("test"))}</div>
        <span></span>
      </div>
      <div class="de-test-center">
        <h2 class="de-test-word">${escapeHtml(t("integratedTest"))}</h2>
        <p class="de-test-hint">${escapeHtml(t("testIntro"))}</p>
        <p class="de-test-hint">${Math.min(count, clampBatchSize(state.testBatchSize))} ${escapeHtml(t("words"))}</p>
        <button class="de-choice" data-action="start-test" type="button" style="text-align:center;">${escapeHtml(t("chooseTest"))}</button>
      </div>
    `;
  }

  function renderTestRun() {
    const test = runtime.test;
    const container = $("#de-view-test-run");

    if (!test) {
      container.innerHTML = "";
      return;
    }

    const word = getCurrentTestWord();
    const question = getCurrentTestQuestion();
    const progress = `${test.index + 1} / ${test.questions.length} · ${escapeHtml(stageLabel(question?.mode))}`;
    container.innerHTML = `
      <div class="de-test-header">
        <button class="de-test-icon" data-action="finish-test" type="button">${ICONS.book}</button>
        <div class="de-test-progress">${progress}</div>
        <span></span>
      </div>
      <div class="de-test-center">
        ${renderQuestionByMode(test, word)}
      </div>
    `;

    const spelling = $("#de-spell-input");
    if (spelling) {
      window.setTimeout(() => spelling.focus(), 30);
      spelling.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          submitSpellingAnswer();
        }
      });
    }

  }

  function renderQuestionByMode(test, word) {
    if (!word) {
      return "";
    }

    const question = getCurrentTestQuestion();
    const mode = question?.mode || "card";

    if (mode === "card") {
      if (!test.revealed) {
        return `
          <h2 class="de-test-word" dir="auto">${escapeHtml(word.word)}</h2>
          <p class="de-test-hint">${escapeHtml(t("cardHint"))}</p>
          <button class="de-choice" data-action="reveal-card" type="button" style="text-align:center;min-height:132px;">${escapeHtml(t("dictionary"))}</button>
        `;
      }
      return `
        <h2 class="de-test-word" dir="auto">${escapeHtml(word.word)}</h2>
        <p class="de-test-hint" dir="auto">${escapeHtml(firstDefinitionLine(word.definition))}</p>
        <div class="de-test-divider"></div>
        <div class="de-ox-row">
          <button class="de-ox-button" data-action="card-answer" data-correct="false" type="button">${escapeHtml(t("notMemorized"))}</button>
          <button class="de-ox-button" data-action="card-answer" data-correct="true" type="button">${escapeHtml(t("memorized"))}</button>
        </div>
      `;
    }

    if (mode === "spell") {
      return `
        <button class="de-speak-button is-test" data-action="speak-test-word" type="button" aria-label="${escapeAttr(t("listen"))}" title="${escapeAttr(t("listen"))}">
          ${ICONS.speaker}
        </button>
        <p class="de-test-hint">${escapeHtml(t("listenAndType"))}</p>
        <input class="de-spell-input" id="de-spell-input" autocomplete="off" spellcheck="false" dir="auto" />
        <div class="de-action-row">
          <button class="de-test-button" data-action="spell-skip" type="button">${escapeHtml(t("skip"))}</button>
          <button class="de-test-button" data-action="spell-submit" type="button">${escapeHtml(t("submit"))}</button>
        </div>
      `;
    }

    const choices = buildChoices(word);
    return `
      <h2 class="de-test-word" dir="auto">${escapeHtml(word.word)}</h2>
      <p class="de-test-hint">${escapeHtml(t("choiceTest"))}</p>
      ${choices.map((choice) => `
        <button class="de-choice" data-action="answer-choice" data-correct="${choice.id === word.id}" type="button" dir="auto">${escapeHtml(firstDefinitionLine(choice.definition))}</button>
      `).join("")}
      <div class="de-action-row">
        <button class="de-test-button" data-action="answer-choice" data-correct="false" type="button">${escapeHtml(t("skip"))}</button>
      </div>
    `;
  }

  function renderProficiency() {
    const test = runtime.test;
    const container = $("#de-view-proficiency");

    if (!test) {
      container.innerHTML = "";
      return;
    }

    const word = getCurrentTestWord();
    const rate = test.pendingRate || 0;
    const examples = Array.isArray(word?.examples) ? word.examples : [];

    container.innerHTML = `
      <div class="de-test-header">
        <button class="de-test-icon" data-action="finish-test" type="button">${ICONS.book}</button>
        <div class="de-test-progress">${escapeHtml(test.pendingCorrect ? t("correct") : t("incorrect"))}</div>
        <span></span>
      </div>
      <div class="de-test-center">
        <h2 class="de-test-word" dir="auto">${escapeHtml(word?.word || "")}</h2>
        <p class="de-test-hint">${escapeHtml(test.pendingCorrect ? t("proficiency") : t("reviewMeaning"))}</p>
        <p class="de-test-hint" dir="auto">${escapeHtml(firstDefinitionLine(word?.definition || ""))}</p>
        ${!test.pendingCorrect && examples.length ? `
          <div class="de-examples" style="text-align:start;width:100%;">
            <h4>${escapeHtml(t("examples"))}</h4>
            ${examples.slice(0, 3).map((example) => `<p dir="auto">${escapeHtml(example)}</p>`).join("")}
          </div>
        ` : ""}
        <div class="de-test-divider"></div>
        ${test.pendingCorrect ? `
          <div class="de-level-grid">
            ${[1, 2, 3, 4, 5].map((value) => `
              <button class="de-level-option ${value === rate ? "is-active" : ""}" data-action="set-rate" data-rate="${value}" type="button">${value}</button>
            `).join("")}
          </div>
        ` : ""}
        <div class="de-action-row">
          <button class="de-test-button" data-action="next-question" type="button">${escapeHtml(t("next"))}</button>
        </div>
      </div>
    `;
  }

  function renderTestResult() {
    const test = runtime.test;
    const container = $("#de-view-test-result");

    if (!test) {
      container.innerHTML = "";
      return;
    }

    container.innerHTML = `
      <div class="de-test-header">
        <button class="de-test-icon" data-action="finish-test" type="button">${ICONS.book}</button>
        <div class="de-test-progress">${escapeHtml(t("finish"))}</div>
        <span></span>
      </div>
      <div class="de-test-center">
        <h2 class="de-test-word">${escapeHtml(t("result"))}</h2>
        <p class="de-test-word" style="font-size:38px;">${test.score} / ${test.possibleScore}</p>
        <div class="de-action-row">
          <button class="de-test-button" data-action="finish-test" type="button">${escapeHtml(t("finish"))}</button>
        </div>
      </div>
    `;
  }

  function renderSettings() {
    const aiConfig = runtime.ai.config || {};
    const aiProvider = aiConfig.provider || "gemini";
    const aiMode = aiConfig.mode || "off";
    const aiStatus = runtime.ai.status || (aiConfig.hasApiKey ? `${t("aiKeySaved")} · ${aiConfig.apiKeyPreview || ""}` : t("aiKeyNotSaved"));
    $("#de-view-settings").innerHTML = `
      <div class="de-title-row">
        <h2 class="de-title">${escapeHtml(t("settings"))}</h2>
      </div>
      <div class="de-settings-stack">
        <section class="de-settings-section">
          <h3 class="de-settings-section-title">${escapeHtml(t("settingsGeneral"))}</h3>
          <div class="de-settings-fields">
            <div class="de-settings-priority">
              <div class="de-settings-language">
                <span class="de-label">${escapeHtml(t("meaningLanguages"))}</span>
                <button class="de-language-card" data-action="toggle-meaning-list" type="button">
                  ${renderMeaningLanguageCardContent()}
                </button>
                <div class="de-language-options ${runtime.meaningLanguageMenuOpen ? "is-open" : ""}">
                  ${renderMeaningLanguageOptions()}
                </div>
              </div>
            </div>
            <div class="de-settings-secondary">
              <label>
                <span class="de-label">${escapeHtml(t("interfaceLanguage"))}</span>
                <select class="de-select" id="de-settings-ui-lang">
                  <option value="ko" ${state.uiLang === "ko" ? "selected" : ""}>한국어</option>
                  <option value="en" ${state.uiLang === "en" ? "selected" : ""}>English</option>
                  <option value="ru" ${state.uiLang === "ru" ? "selected" : ""}>Русский</option>
                  <option value="fa" ${state.uiLang === "fa" ? "selected" : ""}>فارسی</option>
                  <option value="tr" ${state.uiLang === "tr" ? "selected" : ""}>Türkçe</option>
                </select>
              </label>
              <label>
                <span class="de-label">${escapeHtml(t("theme"))}</span>
                <select class="de-select" id="de-settings-theme">
                  <option value="system" ${state.theme === "system" ? "selected" : ""}>${escapeHtml(t("system"))}</option>
                  <option value="light" ${state.theme === "light" ? "selected" : ""}>${escapeHtml(t("light"))}</option>
                  <option value="dark" ${state.theme === "dark" ? "selected" : ""}>${escapeHtml(t("dark"))}</option>
                </select>
              </label>
            </div>
          </div>
        </section>
        <section class="de-settings-section">
          <h3 class="de-settings-section-title">${escapeHtml(t("settingsLookup"))}</h3>
          <div class="de-settings-priority">
            <label>
              <span class="de-label">${escapeHtml(t("dictionarySearchMode"))}</span>
              <select class="de-select" id="de-settings-dictionary-mode">
                <option value="fast" ${state.dictionarySearchMode !== "precise" ? "selected" : ""}>${escapeHtml(t("searchFast"))}</option>
                <option value="precise" ${state.dictionarySearchMode === "precise" ? "selected" : ""}>${escapeHtml(t("searchPrecise"))}</option>
              </select>
            </label>
          </div>
          <div class="de-settings-secondary">
            <label>
              <span class="de-label">${escapeHtml(t("batchSize"))}</span>
              <select class="de-select" id="de-settings-batch-size">
                ${[5, 10, 15, 20, 25, 30, 35, 40, 45, 50].map((value) => `
                  <option value="${value}" ${clampBatchSize(state.testBatchSize) === value ? "selected" : ""}>${value}</option>
                `).join("")}
              </select>
            </label>
          </div>
        </section>
        <section class="de-settings-section">
          <h3 class="de-settings-section-title">${escapeHtml(t("settingsAi"))}</h3>
          <div class="de-settings-fields">
            <div class="de-settings-priority">
              <label>
                <span class="de-label">${escapeHtml(t("aiOrganizer"))}</span>
                <select class="de-select" id="de-ai-mode">
                  <option value="off" ${aiMode === "off" ? "selected" : ""}>${escapeHtml(t("aiOff"))}</option>
                  <option value="quality" ${aiMode === "quality" ? "selected" : ""}>${escapeHtml(t("aiQualityOnly"))}</option>
                  <option value="always" ${aiMode === "always" ? "selected" : ""}>${escapeHtml(t("aiAlways"))}</option>
                </select>
              </label>
            </div>
            <div class="de-settings-secondary">
              <label>
                <span class="de-label">${escapeHtml(t("aiProvider"))}</span>
                <select class="de-select" id="de-ai-provider">
                  <option value="gemini" ${aiProvider === "gemini" ? "selected" : ""}>Gemini</option>
                  <option value="groq" ${aiProvider === "groq" ? "selected" : ""}>Groq</option>
                  <option value="huggingface" ${aiProvider === "huggingface" ? "selected" : ""}>Hugging Face</option>
                  <option value="cloudflare" ${aiProvider === "cloudflare" ? "selected" : ""}>Cloudflare</option>
                </select>
              </label>
              <label>
                <span class="de-label">${escapeHtml(t("aiApiKey"))}</span>
                <input class="de-input" id="de-ai-key" type="password" autocomplete="off" placeholder="${escapeAttr(aiConfig.hasApiKey ? t("aiKeepKey") : t("aiApiKeyPlaceholder"))}">
                <span class="de-setting-note">${escapeHtml(aiStatus)}</span>
              </label>
            </div>
            <label class="de-ai-account-row ${aiProvider === "cloudflare" ? "" : "de-hidden-setting"}">
              <span class="de-label">${escapeHtml(t("aiAccountId"))}</span>
              <input class="de-input" id="de-ai-account" type="text" value="${escapeAttr(aiConfig.accountId || "")}" placeholder="${escapeAttr(t("aiAccountIdPlaceholder"))}">
            </label>
            <div class="de-action-row de-settings-actions">
              <button class="de-secondary-button" data-action="ai-save-config" type="button" ${runtime.ai.busy ? "disabled" : ""}>${escapeHtml(t("save"))}</button>
              <button class="de-secondary-button" data-action="ai-test-config" type="button" ${runtime.ai.busy ? "disabled" : ""}>${escapeHtml(t("aiTest"))}</button>
              <button class="de-secondary-button" data-action="ai-clear-config" type="button" ${runtime.ai.busy ? "disabled" : ""}>${escapeHtml(t("resetSyncConfig"))}</button>
            </div>
          </div>
        </section>
        <section class="de-settings-section">
          <h3 class="de-settings-section-title">${escapeHtml(t("settingsData"))}</h3>
          <button class="de-danger-button" data-action="reset-data" type="button">${escapeHtml(t("reset"))}</button>
        </section>
      </div>
    `;
  }

  function renderEditModal() {
    const modal = $("#de-edit-modal");
    const word = getWord(runtime.editingWordId);

    if (!word) {
      modal.innerHTML = "";
      return;
    }

    const decks = getDecksForCurrentLanguage();
    const examples = Array.isArray(word.examples) ? word.examples : [];
    modal.innerHTML = `
      <div class="de-modal-box">
        <div class="de-word-detail-head">
          <div>
            <div class="de-sub">${escapeHtml(t("edit"))}</div>
            <h2 class="de-title" dir="auto" style="font-size:22px;">${escapeHtml(word.word)}</h2>
            ${word.phonetic ? `<div class="de-sub">${escapeHtml(word.phonetic)}</div>` : ""}
          </div>
          <button class="de-icon-button" data-action="close-edit" type="button">${ICONS.close}</button>
        </div>
        <div class="de-grid" style="margin-top:16px;">
          <label>
            <span class="de-label">${escapeHtml(t("term"))}</span>
            <input class="de-input" id="de-edit-word" type="text" value="${escapeAttr(word.word)}" dir="auto" />
          </label>
          <label>
            <span class="de-label">${escapeHtml(t("savedMeaning"))}</span>
            <textarea class="de-textarea" id="de-edit-definition" dir="auto">${escapeHtml(word.definition)}</textarea>
          </label>
          ${examples.length ? `
            <div class="de-examples">
              <h4>${escapeHtml(t("sourceExamples"))}</h4>
              ${examples.map((example) => `<p>${escapeHtml(example)}</p>`).join("")}
            </div>
          ` : ""}
          <label>
            <span class="de-label">${escapeHtml(t("notes"))}</span>
            <textarea class="de-textarea" id="de-edit-notes" dir="auto" style="min-height:76px;">${escapeHtml(word.notes || "")}</textarea>
          </label>
          <label>
            <span class="de-label">${escapeHtml(t("chooseDeck"))}</span>
            <select class="de-select" id="de-edit-deck">
              ${decks.map((deck) => `<option value="${escapeAttr(deck.id)}" ${deck.id === word.deckId ? "selected" : ""}>${escapeHtml(deck.name)}</option>`).join("")}
            </select>
          </label>
          <div>
            <span class="de-label">${escapeHtml(t("proficiency"))}</span>
            <div class="de-level-row">
              ${[1, 2, 3, 4, 5].map((value) => `
                <button class="de-level-option ${Number(word.level) === value ? "is-active" : ""}" data-action="set-edit-rate" data-rate="${value}" type="button">${value}</button>
              `).join("")}
            </div>
          </div>
        </div>
        <div class="de-modal-actions">
          <button class="de-danger-button" data-action="delete-edit" type="button">${escapeHtml(t("delete"))}</button>
          <button class="de-secondary-button" data-action="close-edit" type="button">${escapeHtml(t("cancel"))}</button>
          <button class="de-primary-button" data-action="save-edit" type="button">${escapeHtml(t("save"))}</button>
        </div>
      </div>
    `;
  }

  function renderSuggestions(query) {
    const text = cleanSelectedText(query);
    const container = $("#de-suggestions");

    if (!text) {
      hideSuggestions();
      return;
    }

    const matches = state.vocab
      .filter((word) => {
        const haystack = `${word.word} ${word.definition}`.toLowerCase();
        return haystack.includes(text.toLowerCase());
      })
      .slice(0, 4);

    const recent = state.recent
      .filter((word) => word.toLowerCase().includes(text.toLowerCase()))
      .slice(0, 2)
      .map((word) => ({ word, definition: t("searchAction") }));

    const rows = [...matches, ...recent];
    container.innerHTML = `
      ${rows.map((item) => `
        <button class="de-suggestion" data-action="suggest-search" data-word="${escapeAttr(item.word)}" type="button">
        <span class="de-suggestion-word" dir="auto">${escapeHtml(item.word)}</span>
        <span class="de-suggestion-def" dir="auto">${escapeHtml(firstDefinitionLine(item.definition || ""))}</span>
        </button>
      `).join("")}
      <button class="de-suggestion" data-action="suggest-search" data-word="${escapeAttr(text)}" type="button">
        <span class="de-suggestion-word" dir="auto">${escapeHtml(text)}</span>
        <span class="de-suggestion-def">${escapeHtml(t("searchAction"))}</span>
      </button>
    `;
    container.classList.add("is-visible");
  }

  function hideSuggestions() {
    $("#de-suggestions").classList.remove("is-visible");
  }

  function hideTooltip() {
    $("#de-tooltip").classList.remove("is-visible");
  }

  function fillLanguageSelects() {
    renderMenu();
  }

  function applyTheme() {
    const dark = state.theme === "dark" ||
      (state.theme === "system" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    host.classList.toggle("de-dark", dark);
  }

  function toast(message) {
    const node = $("#de-toast");
    node.textContent = message;
    node.classList.add("is-visible");
    window.clearTimeout(toast.timer);
    toast.timer = window.setTimeout(() => node.classList.remove("is-visible"), 1700);
  }

  function getCurrentDeck() {
    return state.decks.find((deck) => deck.id === runtime.currentDeckId) || getDecksForCurrentLanguage()[0] || null;
  }

  function getDecksForCurrentLanguage() {
    return state.decks.filter((deck) => deck.lang === sourceLang());
  }

  function ensureDeckForCurrentLanguage() {
    let deck = getDecksForCurrentLanguage()[0];
    if (!deck) {
      deck = createDeck("Vocabulary", sourceLang());
    }
    const matchingCurrentDeck = state.decks.find(
      (item) => item.id === runtime.currentDeckId && item.lang === sourceLang()
    );
    if (matchingCurrentDeck) {
      return matchingCurrentDeck;
    }
    if (!runtime.currentDeckId || !state.decks.some((item) => item.id === runtime.currentDeckId)) {
      runtime.currentDeckId = deck.id;
      return deck;
    }
    runtime.currentDeckId = deck.id;
    return deck;
  }

  function createDeck(name, lang) {
    const deck = {
      id: `deck_${lang}_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      name,
      lang
    };
    state.decks.push(deck);
    runtime.currentDeckId = deck.id;
    return deck;
  }

  function getWordsByDeck(deckId) {
    return state.vocab.filter((word) => word.deckId === deckId);
  }

  function getWord(id) {
    return state.vocab.find((word) => word.id === id) || null;
  }

  function getCurrentTestWord() {
    if (!runtime.test) {
      return null;
    }
    const question = getCurrentTestQuestion();
    return runtime.test.words.find((word) => word.id === question?.wordId) || null;
  }

  function getCurrentTestQuestion() {
    if (!runtime.test) {
      return null;
    }
    return runtime.test.questions[runtime.test.index] || null;
  }

  function buildChoices(correctWord) {
    const pool = state.vocab.filter((word) => word.id !== correctWord.id && word.definition);
    return shuffle([correctWord, ...shuffle(pool).slice(0, 3)]);
  }

  function stageLabel(stage) {
    if (stage === "card") return t("cardTest");
    if (stage === "choice") return t("choiceTest");
    if (stage === "spell") return t("spellingTest");
    return t("test");
  }

  function speakText(value, langCode) {
    const text = String(value || "").trim();
    if (!text || !("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    const speechLang = speechLanguageCode(langCode || detectWordLanguage(text));
    utterance.lang = speechLang;
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;

    const voice = preferredSpeechVoice(speechLang);
    if (voice) {
      utterance.voice = voice;
    }

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  function preferredSpeechVoice(speechLang) {
    const voices = window.speechSynthesis?.getVoices?.() || [];
    if (!voices.length) {
      return null;
    }
    const exact = voices.find((voice) => voice.lang.toLowerCase() === speechLang.toLowerCase());
    if (exact) {
      return exact;
    }
    const base = speechLang.split("-")[0].toLowerCase();
    return voices.find((voice) => voice.lang.toLowerCase().startsWith(`${base}-`)) || null;
  }

  function speechLanguageCode(langCode) {
    const map = {
      ko: "ko-KR",
      en: "en-US",
      ja: "ja-JP",
      "zh-CN": "zh-CN",
      ru: "ru-RU",
      tr: "tr-TR",
      fa: "fa-IR"
    };
    return map[langCode] || map[detectWordLanguage(langCode)] || "en-US";
  }

  function addRecent(word) {
    state.recent = [word, ...state.recent.filter((item) => item.toLowerCase() !== word.toLowerCase())].slice(0, 8);
    saveState();
  }

  async function saveAndRender() {
    ensureDeckForCurrentLanguage();
    fillLanguageSelects();
    await saveState();
    applyTheme();
    renderAll();
  }

  function loadState() {
    if (hasChromeStorage()) {
      return new Promise((resolve) => {
        chrome.storage.local.get({ [STORAGE_KEY]: DEFAULT_STATE }, (result) => {
          resolve(result[STORAGE_KEY] || DEFAULT_STATE);
        });
      });
    }

    try {
      return Promise.resolve(JSON.parse(window.localStorage.getItem(STORAGE_KEY)) || DEFAULT_STATE);
    } catch (_error) {
      return Promise.resolve(DEFAULT_STATE);
    }
  }

  function saveState() {
    const snapshot = clone(state);
    if (hasChromeStorage()) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [STORAGE_KEY]: snapshot }, resolve);
      });
    }
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    return Promise.resolve();
  }

  function isSupportedLanguage(langCode) {
    return LANGUAGES.some((lang) => lang.code === langCode);
  }

  function normalizeLanguageCodes(values) {
    const list = Array.isArray(values) ? values : [values];
    const seen = new Set();
    list.forEach((value) => {
      if (isSupportedLanguage(value)) {
        seen.add(value);
      }
    });
    return Array.from(seen);
  }

  function sourceLang() {
    const code = state.sourceLang || state.targetLang || state.currentDictLang || "en";
    return isSupportedLanguage(code) ? code : "en";
  }

  function getMeaningLanguages() {
    const fallback = isSupportedLanguage(state.uiLang) ? state.uiLang : "ko";
    const langs = normalizeLanguageCodes(state.targetLangs);
    return langs.length ? langs : [fallback];
  }

  function activeMeaningLang() {
    const langs = getMeaningLanguages();
    return langs.includes(state.currentMeaningLang) ? state.currentMeaningLang : langs[0];
  }

  function chooseInitialMeaningLanguage(currentSourceLang) {
    const langs = getMeaningLanguages();
    const remembered = activeMeaningLang();
    if (langs.includes(remembered) && remembered !== currentSourceLang) {
      return remembered;
    }
    return langs.find((langCode) => langCode !== currentSourceLang) || langs[0];
  }

  function detectWordLanguage(value) {
    const text = String(value || "");
    if (/[\uac00-\ud7af]/.test(text)) return "ko";
    if (/[\u3040-\u30ff]/.test(text)) return "ja";
    if (/[\u4e00-\u9fff]/.test(text)) return "zh-CN";
    if (/[\u0400-\u04ff]/.test(text)) return "ru";
    if (/[\u0600-\u06ff]/.test(text)) return "fa";
    if (/[çğıöşüÇĞİÖŞÜ]/.test(text)) return "tr";
    return "en";
  }

  function normalizeState(loaded) {
    const loadedState = clone(loaded || {});
    const next = { ...clone(DEFAULT_STATE), ...loadedState };
    const isLegacyState = Number(next.version || 0) < 2;
    next.uiLang = Object.prototype.hasOwnProperty.call(I18N, next.uiLang) ? next.uiLang : "ko";
    const migratedSourceLang = loadedState.sourceLang || loadedState.currentDictLang || loadedState.targetLang || next.sourceLang || "en";
    next.sourceLang = isSupportedLanguage(migratedSourceLang) ? migratedSourceLang : "en";
    next.targetLang = next.sourceLang;
    next.currentDictLang = next.sourceLang;
    const fallbackMeaningLang = isSupportedLanguage(next.uiLang) ? next.uiLang : "ko";
    const loadedMeaningLangs = Array.isArray(loadedState.targetLangs)
      ? loadedState.targetLangs
      : Array.isArray(loadedState.meaningLangs)
        ? loadedState.meaningLangs
        : [fallbackMeaningLang];
    next.targetLangs = normalizeLanguageCodes(loadedMeaningLangs);
    if (!next.targetLangs.length) {
      next.targetLangs = [fallbackMeaningLang];
    }
    next.currentMeaningLang = next.targetLangs.includes(loadedState.currentMeaningLang)
      ? loadedState.currentMeaningLang
      : next.targetLangs[0];
    next.theme = ["system", "light", "dark"].includes(next.theme) ? next.theme : "system";
    next.dictionarySearchMode = next.dictionarySearchMode === "precise" ? "precise" : "fast";
    next.testBatchSize = clampBatchSize(next.testBatchSize || 10);
    next.recent = Array.isArray(next.recent) ? next.recent : [];
    next.decks = Array.isArray(next.decks) ? next.decks : [];
    next.vocab = Array.isArray(next.vocab) ? next.vocab : [];
    next.layout = normalizeLayout(next.layout);

    next.decks = next.decks.map((deck, index) => ({
      id: deck.id || `deck_migrated_${index}`,
      name: deck.name || "Vocabulary",
      lang: isLegacyState ? next.sourceLang : deck.lang || next.sourceLang
    }));

    next.vocab = next.vocab.map((word, index) => {
      const normalizedWord = word.word || "";
      return {
        id: word.id ? String(word.id) : `word_migrated_${index}_${Date.now()}`,
        word: normalizedWord,
        normalized: word.normalized || normalizeWord(normalizedWord),
        definition: word.definition || word.def || "",
        phonetic: word.phonetic || "",
        examples: Array.isArray(word.examples) ? word.examples : [],
        notes: word.notes || "",
        deckId: word.deckId || next.decks[0]?.id || `deck_default_${next.sourceLang}`,
        lang: isLegacyState ? next.sourceLang : word.lang || next.sourceLang,
        meaningLang: word.meaningLang || next.currentMeaningLang,
        level: Number(word.level || 0),
        stats: word.stats || { seen: 0, correct: 0, wrong: 0 },
        createdAt: word.createdAt || Date.now(),
        updatedAt: word.updatedAt || word.createdAt || Date.now()
      };
    });

    if (!next.decks.length) {
      next.decks.push({ id: `deck_default_${next.sourceLang}`, name: "Vocabulary", lang: next.sourceLang });
    }

    next.version = 6;
    return next;
  }

  function normalizeLayout(layout) {
    const next = {};
    if (!layout || typeof layout !== "object") {
      return next;
    }

    if (layout.fab && Number.isFinite(layout.fab.left) && Number.isFinite(layout.fab.top)) {
      next.fab = {
        left: Number(layout.fab.left),
        top: Number(layout.fab.top)
      };
    }

    if (layout.panel && Number.isFinite(layout.panel.left) && Number.isFinite(layout.panel.top)) {
      next.panel = {
        left: Number(layout.panel.left),
        top: Number(layout.panel.top)
      };
    }

    return next;
  }

  function t(key) {
    return (I18N[tLang()] && I18N[tLang()][key]) || I18N.en[key] || key;
  }

  function tLang() {
    return Object.prototype.hasOwnProperty.call(I18N, state.uiLang) ? state.uiLang : "ko";
  }

  function directionalChevron() {
    return tLang() === "fa" ? "‹" : "›";
  }

  function flagAsset(code) {
    const pngPath = FLAG_PNGS[code];
    if (pngPath) {
      const src = typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.getURL === "function"
        ? chrome.runtime.getURL(pngPath)
        : pngPath;
      return `<img src="${escapeAttr(src)}" alt="">`;
    }
    return FLAG_SVGS[code] || "";
  }

  function flagIcon(code, small = false) {
    return `<span class="de-flag ${small ? "de-flag-small" : ""} de-flag-${escapeAttr(code)}" aria-hidden="true">${flagAsset(code)}</span>`;
  }

  function languageLabel(code) {
    const lang = LANGUAGES.find((item) => item.code === code);
    return lang?.label?.[tLang()] || lang?.label?.en || code;
  }

  function averageLevel(words) {
    const rated = words.filter((word) => word.level > 0);
    if (!rated.length) {
      return "-";
    }
    const value = rated.reduce((sum, word) => sum + word.level, 0) / rated.length;
    return value.toFixed(1);
  }

  function clampBatchSize(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 10;
    }
    return Math.min(50, Math.max(5, Math.round(number / 5) * 5));
  }

  function firstDefinitionLine(value) {
    return String(value || "")
      .split("\n")
      .map((line) => line.replace(/^\d+\.\s*/, "").trim())
      .find(Boolean) || "";
  }

  function cleanSelectedText(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "")
      .trim();
  }

  function normalizeWord(value) {
    return cleanSelectedText(value).toLowerCase();
  }

  function shuffle(items) {
    return items
      .map((item) => ({ item, sort: Math.random() }))
      .sort((a, b) => a.sort - b.sort)
      .map(({ item }) => item);
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function hasChromeRuntime() {
    return typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage;
  }

  function hasChromeStorage() {
    return typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  }
})();
