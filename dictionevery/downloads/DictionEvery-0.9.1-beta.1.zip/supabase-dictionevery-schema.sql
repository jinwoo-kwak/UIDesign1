create table if not exists public.dictionevery_words (
  user_id uuid not null references auth.users(id) on delete cascade,
  sync_key text not null,
  updated_ms bigint not null default 0,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, sync_key)
);

alter table public.dictionevery_words enable row level security;

create policy "DictionEvery users can read own words"
on public.dictionevery_words
for select
using (auth.uid() = user_id);

create policy "DictionEvery users can insert own words"
on public.dictionevery_words
for insert
with check (auth.uid() = user_id);

create policy "DictionEvery users can update own words"
on public.dictionevery_words
for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "DictionEvery users can delete own words"
on public.dictionevery_words
for delete
using (auth.uid() = user_id);
