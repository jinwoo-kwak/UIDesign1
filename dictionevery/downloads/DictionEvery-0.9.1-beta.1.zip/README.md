# DictionEvery

웹페이지 위에서 단어를 선택하고 바로 뜻을 찾아 단어장에 저장하는 Chrome 확장 프로그램입니다.

## 설치

1. Chrome에서 `chrome://extensions`를 엽니다.
2. 오른쪽 위의 개발자 모드를 켭니다.
3. `Load unpacked`를 누르고 이 폴더를 선택합니다.
4. 웹페이지에서 오른쪽 아래 앱 아이콘을 누르거나, 단어를 선택한 뒤 `Find in` / `에서 찾기` 버튼을 누릅니다.

## 구현된 기능

- 웹페이지 위 플로팅 아이콘
- 단어 선택 후 인터페이스 언어에 맞는 찾기 툴팁
- Google Translate fallback, Free Dictionary, FreeDictionaryAPI, WiktApi, Wiktionary, OpenRussian, 한국어기초사전 기반 사전 검색
- 도착언어별 호환 사전 소스 선택, 사전 간 대조, 뜻 직접 편집
- 속도 우선/품질 우선 검색 알고리즘 선택
- Gemini, Groq, Hugging Face, Cloudflare Workers AI를 선택해 사전 결과 정렬 보조
- 새 단어장 생성 및 단어 저장
- 단어장 목록, 단어 편집, 이동, 삭제
- 숙련도 1-5 기록
- 카드, 뜻 고르기, 철자 입력이 이어지는 통합 테스트
- 테스트 후 정답 여부와 숙련도 업데이트
- 인터페이스 언어, 도착언어, 화면 모드, 테스트 단어 수 설정
- Anki TSV, Quizlet 복사용 텍스트, LingQ CSV 내보내기
- Supabase 기반 계정 로그인과 수동 업로드, 다운로드, 병합 동기화
- 확장 프로그램 팝업에서 패널 열기 및 단어 검색

## Supabase 동기화 설정

1. Supabase 프로젝트를 만들고 `supabase-dictionevery-schema.sql`을 SQL editor에서 실행합니다.
2. 확장 프로그램의 `동기화` 화면에서 Supabase project URL, public anon key, 테이블 이름을 입력하고 저장합니다.
3. Google 로그인을 사용하려면 Supabase Auth의 Google provider를 켜고, 동기화 화면에 표시되는 redirect URL을 Supabase allow list에 추가합니다.

동기화 고유키는 `sourceLang + normalizedWord + meaningLang` 기준이며, 병합 시 마지막 수정 시간이 더 최신인 단어가 우선됩니다.

## 미리보기

Chrome 확장으로 설치하기 전에는 `demo.html`을 브라우저에서 열어 UI 형태를 확인할 수 있습니다.

## 리소스 출처

- 한국 국기 아이콘: Flaticon `south-korea_6211587`
- 이란 국기 아이콘: Flaticon `iran_6211416`
- 러시아어-영어 로컬 사전 데이터: Badestrand `russian-dictionary` / OpenRussian, CC-BY-SA-4.0
- 페르시아어-영어 구조화 사전 보조 소스: FreeDictionaryAPI.com, Wiktionary 기반 CC BY-SA 4.0
