const chrome = globalThis.chrome || globalThis.browser;
const STORAGE_KEY = "dictionState";
const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

const POPUP_I18N = {
  ko: {
    searchPlaceholder: "단어 검색...",
    search: "검색",
    openPanel: "웹페이지에서 열기",
    decks: "단어장",
    words: "단어",
    known: "알고 있는 단어",
    recent: "최근 단어",
    empty: "아직 저장된 단어가 없습니다.",
    noWord: "검색할 단어를 입력해주세요.",
    noTab: "활성 탭을 찾지 못했습니다.",
    cannotOpen: "이 페이지에서는 확장 프로그램을 열 수 없습니다."
  },
  en: {
    searchPlaceholder: "Search words...",
    search: "Search",
    openPanel: "Open on page",
    decks: "Decks",
    words: "Words",
    known: "Known",
    recent: "Recent words",
    empty: "No saved words yet.",
    noWord: "Enter a word to search.",
    noTab: "Could not find the active tab.",
    cannotOpen: "This page cannot open the extension."
  },
  ru: {
    searchPlaceholder: "Поиск слова...",
    search: "Искать",
    openPanel: "Открыть на странице",
    decks: "Списки",
    words: "Слова",
    known: "Известные",
    recent: "Недавние слова",
    empty: "Сохранённых слов пока нет.",
    noWord: "Введите слово для поиска.",
    noTab: "Активная вкладка не найдена.",
    cannotOpen: "На этой странице расширение открыть нельзя."
  },
  tr: {
    searchPlaceholder: "Kelime ara...",
    search: "Ara",
    openPanel: "Sayfada aç",
    decks: "Listeler",
    words: "Kelimeler",
    known: "Bilinen",
    recent: "Son kelimeler",
    empty: "Henüz kayıtlı kelime yok.",
    noWord: "Aramak için bir kelime girin.",
    noTab: "Etkin sekme bulunamadı.",
    cannotOpen: "Bu sayfada eklenti açılamıyor."
  },
  fa: {
    searchPlaceholder: "جست‌وجوی واژه...",
    search: "جست‌وجو",
    openPanel: "باز کردن در صفحه",
    decks: "فهرست‌ها",
    words: "واژه‌ها",
    known: "آشنا",
    recent: "واژه‌های اخیر",
    empty: "هنوز واژه‌ای ذخیره نشده است.",
    noWord: "برای جست‌وجو یک واژه وارد کنید.",
    noTab: "زبانه فعال پیدا نشد.",
    cannotOpen: "این صفحه امکان باز کردن افزونه را ندارد."
  }
};

document.addEventListener("DOMContentLoaded", async () => {
  const state = await loadState();
  renderSummary(state);

  document.getElementById("open-panel").addEventListener("click", async () => {
    await sendToActiveTab({ type: "DE_OPEN_PANEL" });
  });

  document.getElementById("search-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = document.getElementById("search-input");
    const word = input.value.trim();
    if (!word) {
      setStatus(t(state.uiLang, "noWord"));
      return;
    }
    await sendToActiveTab({ type: "DE_SEARCH_WORD", word });
  });
});

function loadState() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [STORAGE_KEY]: null }, (result) => {
      resolve(result[STORAGE_KEY] || { decks: [], vocab: [] });
    });
  });
}

function renderSummary(state) {
  const decks = Array.isArray(state.decks) ? state.decks : [];
  const words = Array.isArray(state.vocab) ? state.vocab : [];
  const lang = locale(state.uiLang);
  const known = words.filter((word) => Number(word.level || 0) >= 4).length;

  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
  document.documentElement.style.fontFamily = lang === "fa"
    ? '"Vazirmatn", "Noto Sans Arabic", "Noto Sans", "Segoe UI", Tahoma, Arial, sans-serif'
    : "";
  document.getElementById("search-input").placeholder = t(lang, "searchPlaceholder");
  document.getElementById("search-submit").textContent = t(lang, "search");
  document.getElementById("open-panel").textContent = t(lang, "openPanel");
  document.getElementById("deck-label").textContent = t(lang, "decks");
  document.getElementById("word-label").textContent = t(lang, "words");
  document.getElementById("known-label").textContent = t(lang, "known");
  document.getElementById("recent-label").textContent = t(lang, "recent");

  document.getElementById("deck-count").textContent = formatNumber(lang, decks.length);
  document.getElementById("word-count").textContent = formatNumber(lang, words.length);
  document.getElementById("known-count").textContent = formatNumber(lang, known);

  const recent = words
    .slice()
    .sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))
    .slice(0, 5);

  const list = document.getElementById("recent-list");
  if (!recent.length) {
    list.innerHTML = `<div class='empty'>${t(lang, "empty")}</div>`;
    return;
  }

  list.innerHTML = recent
    .map((word) => `
      <div class="word">
        <strong dir="auto">${escapeHtml(word.word || "")}</strong>
        <span dir="auto">${escapeHtml(firstLine(word.definition || word.def || ""))}</span>
      </div>
    `)
    .join("");
}

async function sendToActiveTab(message) {
  setStatus("");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    const state = await loadState();
    setStatus(t(state.uiLang, "noTab"));
    return;
  }

  try {
    await sendMessage(tab.id, message);
    window.close();
  } catch (_error) {
    try {
      await injectContentScript(tab.id);
      await sendMessage(tab.id, message);
      window.close();
    } catch (injectError) {
      setStatus(
        injectError && injectError.message
          ? injectError.message
          : t((await loadState()).uiLang, "cannotOpen")
      );
    }
  }
}

function injectContentScript(tabId) {
  if (chrome.scripting?.executeScript) {
    return chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  }

  if (chrome.tabs?.executeScript) {
    return new Promise((resolve, reject) => {
      chrome.tabs.executeScript(tabId, { file: "content.js" }, () => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message));
          return;
        }
        resolve();
      });
    });
  }

  return Promise.reject(new Error("Script injection is not available in this browser."));
}

function sendMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      if (!response || !response.ok) {
        reject(new Error("No response from content script"));
        return;
      }
      resolve(response);
    });
  });
}

function setStatus(message) {
  document.getElementById("status").textContent = message;
}

function locale(lang) {
  return Object.prototype.hasOwnProperty.call(POPUP_I18N, lang) ? lang : "ko";
}

function t(lang, key) {
  const safeLang = locale(lang);
  return localizeDigits(POPUP_I18N[safeLang][key] || POPUP_I18N.en[key] || key, safeLang);
}

function localizeDigits(value, lang) {
  const text = String(value ?? "");
  if (locale(lang) !== "fa") {
    return text;
  }
  return text.replace(/[0-9]/g, (digit) => PERSIAN_DIGITS[Number(digit)]);
}

function formatNumber(lang, value) {
  return localizeDigits(value, lang);
}

function firstLine(value) {
  return String(value || "")
    .split("\n")
    .map((line) => line.replace(/^\d+\.\s*/, "").trim())
    .find(Boolean) || "";
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
