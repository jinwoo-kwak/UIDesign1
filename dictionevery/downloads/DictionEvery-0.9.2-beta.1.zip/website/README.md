# DictionEvery Install Site

이 폴더는 DictionEvery 설치 안내와 다운로드 파일 배포를 위한 정적 웹페이지입니다.

## 로컬 미리보기

```sh
cd website
python3 -m http.server 8770 --bind 127.0.0.1
```

브라우저에서 `http://127.0.0.1:8770/`을 열면 됩니다.

## 포함된 파일

- Chrome Web Store 제출용 패키지
- Samsung Browser for Windows 호환 확인용 Chrome 패키지
- Safari Web Extension 변환 입력 패키지
- DictionEvery 전체 베타 패키지

## 배포

정적 호스팅에는 `website/index.html`, `website/styles.css`, `website/assets`, `website/downloads`를 업로드하면 됩니다.

Sites/Cloudflare Workers 호스팅용 산출물은 `website/dist`에 있습니다.
